from .mini_test import MINI_TEST
from .mini_test import MINI_CHECK
from .mini_test import run_all
from .tolerance import TOLERANCE
from .tolerance import PI


@MINI_TEST("Closest", "Line Point")
def test_closest_line_point():
    from session_py import Closest
    from session_py import Line
    from session_py import Point

    l = Line(0.0, 0.0, 0.0, 10.0, 0.0, 0.0)

    cp1, t1, d1 = Closest.line_point(l, Point(5.0, 5.0, 0.0))

    MINI_CHECK(TOLERANCE.is_close(cp1[0], 5.0))
    MINI_CHECK(TOLERANCE.is_close(cp1[1], 0.0))
    MINI_CHECK(TOLERANCE.is_close(t1, 0.5))
    MINI_CHECK(TOLERANCE.is_close(d1, 5.0))

    cp2, t2, d2 = Closest.line_point(l, Point(-5.0, 0.0, 0.0))
    MINI_CHECK(TOLERANCE.is_close(cp2[0], 0.0))
    MINI_CHECK(TOLERANCE.is_close(t2, 0.0))
    MINI_CHECK(TOLERANCE.is_close(d2, 5.0))

    cp3, t3, d3 = Closest.line_point(l, Point(15.0, 0.0, 0.0))
    MINI_CHECK(TOLERANCE.is_close(cp3[0], 10.0))
    MINI_CHECK(TOLERANCE.is_close(t3, 1.0))
    MINI_CHECK(TOLERANCE.is_close(d3, 5.0))


@MINI_TEST("Closest", "Polyline Point")
def test_closest_polyline_point():
    from session_py import Closest
    from session_py import Polyline
    from session_py import Point

    pl = Polyline([
        Point(0.0, 0.0, 0.0),
        Point(10.0, 0.0, 0.0),
        Point(10.0, 10.0, 0.0),
    ])

    cp1, t1, d1 = Closest.polyline_point(pl, Point(5.0, 5.0, 0.0))

    MINI_CHECK(TOLERANCE.is_close(d1, 5.0))

    cp2, t2, d2 = Closest.polyline_point(pl, Point(10.0, 5.0, 0.0))
    MINI_CHECK(TOLERANCE.is_close(cp2[0], 10.0))
    MINI_CHECK(TOLERANCE.is_close(cp2[1], 5.0))
    MINI_CHECK(TOLERANCE.is_close(d2, 0.0))


@MINI_TEST("Closest", "Curve Point")
def test_closest_curve_point():
    from session_py import Closest
    from session_py import NurbsCurve
    from session_py import Point

    pts = [
        Point(0.0, 0.0, 0.0),
        Point(1.0, 2.0, 0.0),
        Point(3.0, 2.0, 0.0),
        Point(4.0, 0.0, 0.0),
    ]
    crv = NurbsCurve.create(False, 3, pts)

    t, dist = Closest.curve_point(crv, Point(2.0, 3.0, 0.0))

    MINI_CHECK(dist < 1.6)
    cp = crv.point_at(t)
    MINI_CHECK(TOLERANCE.is_close(cp.distance(Point(2.0, 3.0, 0.0)), dist))

    t2, dist2 = Closest.curve_point(crv, Point(0.0, 0.0, 0.0))
    MINI_CHECK(dist2 < 0.01)


@MINI_TEST("Closest", "Surface Point")
def test_closest_surface_point():
    from session_py import Closest
    from session_py import NurbsSurface
    from session_py import Point

    pts = [
        Point(0.0, 0.0, 0.0),
        Point(1.0, 0.0, 0.0),
        Point(2.0, 0.0, 0.0),
        Point(3.0, 0.0, 0.0),
        Point(0.0, 1.0, 0.0),
        Point(1.0, 1.0, 1.0),
        Point(2.0, 1.0, 1.0),
        Point(3.0, 1.0, 0.0),
        Point(0.0, 2.0, 0.0),
        Point(1.0, 2.0, 1.0),
        Point(2.0, 2.0, 1.0),
        Point(3.0, 2.0, 0.0),
        Point(0.0, 3.0, 0.0),
        Point(1.0, 3.0, 0.0),
        Point(2.0, 3.0, 0.0),
        Point(3.0, 3.0, 0.0),
    ]
    srf = NurbsSurface.create(False, False, 3, 3, 4, 4, pts)

    u, v, dist = Closest.surface_point(srf, Point(1.5, 1.5, 2.0))

    MINI_CHECK(dist < 1.5)
    cp = srf.point_at(u, v)
    MINI_CHECK(TOLERANCE.is_close(cp.distance(Point(1.5, 1.5, 2.0)), dist))

    u2, v2, dist2 = Closest.surface_point(srf, Point(0.0, 0.0, 0.0))
    MINI_CHECK(dist2 < 0.01)


@MINI_TEST("Closest", "Surface Curve")
def test_closest_surface_curve():
    import math
    from session_py import Closest
    from session_py import NurbsCurve
    from session_py import Point
    from session_py import Primitives

    cyl = Primitives.cylinder_surface(0.0, 0.0, 0.0, 1.0, 4.0)
    u0, u1 = cyl.domain(0)
    v0, v1 = cyl.domain(1)
    ps = cyl.point_at(u0, 0.5)
    seam_ang = math.atan2(ps[1], ps[0])
    crv_pts = []
    for i in range(21):
        a = seam_ang - 0.8 + 1.6 * i / 20.0
        z = 1.0 + 2.0 * i / 20.0
        crv_pts.append(Point(math.cos(a), math.sin(a), z))
    crv = NurbsCurve.create_interpolated(crv_pts)

    pcurves = Closest.surface_curve(cyl, crv)

    MINI_CHECK(len(pcurves) == 2)
    on_border = 0
    inside = True
    for pcurve in pcurves:
        MINI_CHECK(pcurve.is_valid())
        for e in [0.0, 1.0]:
            p2 = pcurve.point_at(e)
            if abs(p2[0] - u0) < 1e-9 or abs(p2[0] - u1) < 1e-9:
                on_border += 1
        for i in range(17):
            p2 = pcurve.point_at(i / 16.0)
            if p2[0] < u0 - 1e-6 or p2[0] > u1 + 1e-6 or p2[1] < v0 - 1e-6 or p2[1] > v1 + 1e-6:
                inside = False
    MINI_CHECK(on_border == 2)
    MINI_CHECK(inside)

    off = NurbsCurve.create(False, 1, [Point(20.0, 20.0, 20.0), Point(30.0, 30.0, 30.0)])

    MINI_CHECK(len(Closest.surface_curve(cyl, off)) == 0)


@MINI_TEST("Closest", "Mesh Point")
def test_closest_mesh_point():
    from session_py import Closest
    from session_py import Primitives
    from session_py import Point

    m = Primitives.cube(2.0)

    cp1, fk1, d1 = Closest.mesh_point(m, Point(0.0, 0.0, 2.0))

    MINI_CHECK(TOLERANCE.is_close(cp1[2], 1.0))
    MINI_CHECK(TOLERANCE.is_close(d1, 1.0))

    cp2, fk2, d2 = Closest.mesh_point(m, Point(1.0, 1.0, 1.0))
    MINI_CHECK(TOLERANCE.is_close(d2, 0.0))


@MINI_TEST("Closest", "Mesh Point AABB")
def test_closest_mesh_point_aabb():
    from session_py import Closest
    from session_py import Primitives
    from session_py import Point

    m = Primitives.cube(2.0)

    cp1, fk1, d1 = Closest.mesh_point_aabb(m, Point(0.0, 0.0, 2.0))

    MINI_CHECK(TOLERANCE.is_close(cp1[2], 1.0))
    MINI_CHECK(TOLERANCE.is_close(d1, 1.0))

    cp2, fk2, d2 = Closest.mesh_point_aabb(m, Point(1.0, 1.0, 1.0))
    MINI_CHECK(TOLERANCE.is_close(d2, 0.0))


@MINI_TEST("Closest", "Pointcloud Point")
def test_closest_pointcloud_point():
    from session_py import Closest
    from session_py import PointCloud
    from session_py import Point

    pc = PointCloud([
        Point(0.0, 0.0, 0.0),
        Point(5.0, 0.0, 0.0),
        Point(10.0, 0.0, 0.0),
        Point(10.0, 10.0, 0.0),
    ])

    cp1, i1, d1 = Closest.pointcloud_point(pc, Point(4.0, 0.0, 0.0))

    MINI_CHECK(TOLERANCE.is_close(cp1[0], 5.0))
    MINI_CHECK(i1 == 1)
    MINI_CHECK(TOLERANCE.is_close(d1, 1.0))

    cp2, i2, d2 = Closest.pointcloud_point(pc, Point(10.0, 10.0, 0.0))
    MINI_CHECK(TOLERANCE.is_close(d2, 0.0))
    MINI_CHECK(i2 == 3)


@MINI_TEST("Closest", "Pointcloud Point SpatialKDTree")
def test_closest_pointcloud_point_kdtree():
    from session_py import Closest
    from session_py import PointCloud
    from session_py import Point

    # SpatialKDTree variant: same result as linear scan, O(log n) query
    pc = PointCloud([
        Point(0.0, 0.0, 0.0),
        Point(5.0, 0.0, 0.0),
        Point(10.0, 0.0, 0.0),
        Point(10.0, 10.0, 0.0),
    ])

    cp1, i1, d1 = Closest.pointcloud_point_kdtree(pc, Point(4.0, 0.0, 0.0))

    MINI_CHECK(TOLERANCE.is_close(cp1[0], 5.0))
    MINI_CHECK(i1 == 1)
    MINI_CHECK(TOLERANCE.is_close(d1, 1.0))

    cp2, i2, d2 = Closest.pointcloud_point_kdtree(pc, Point(10.0, 10.0, 0.0))
    MINI_CHECK(TOLERANCE.is_close(d2, 0.0))
    MINI_CHECK(i2 == 3)


@MINI_TEST("Closest", "Lines Closest")
def test_closest_lines_closest():
    from session_py import Closest
    from session_py import Line

    # 3 lines: first two sharing an endpoint, third far away
    lines = [
        Line(0.0, 0.0, 0.0, 5.0, 0.0, 0.0),
        Line(5.0, 0.0, 0.0, 10.0, 0.0, 0.0),
        Line(100.0, 0.0, 0.0, 110.0, 0.0, 0.0),
    ]

    pairs = Closest.lines_closest(lines, 0.01)

    MINI_CHECK(len(pairs) == 1)
    MINI_CHECK(pairs[0][0] == 0)
    MINI_CHECK(pairs[0][1] == 1)


@MINI_TEST("Closest", "Polylines Closest")
def test_closest_polylines_closest():
    from session_py import Closest
    from session_py import Polyline
    from session_py import Point

    pls = [
        Polyline([Point(0.0, 0.0, 0.0), Point(5.0, 0.0, 0.0)]),
        Polyline([Point(5.0, 0.0, 0.0), Point(10.0, 0.0, 0.0)]),
        Polyline([Point(100.0, 0.0, 0.0), Point(110.0, 0.0, 0.0)]),
    ]

    pairs = Closest.polylines_closest(pls, 0.01)

    MINI_CHECK(len(pairs) == 1)
    MINI_CHECK(pairs[0][0] == 0)
    MINI_CHECK(pairs[0][1] == 1)


@MINI_TEST("Closest", "Nurbscurves Closest")
def test_closest_nurbscurves_closest():
    from session_py import Closest
    from session_py import NurbsCurve
    from session_py import Point

    curves = [
        NurbsCurve.create(False, 1, [Point(0.0, 0.0, 0.0), Point(5.0, 0.0, 0.0)]),
        NurbsCurve.create(False, 1, [Point(5.0, 0.0, 0.0), Point(10.0, 0.0, 0.0)]),
        NurbsCurve.create(False, 1, [Point(100.0, 0.0, 0.0), Point(110.0, 0.0, 0.0)]),
    ]

    pairs = Closest.nurbscurves_closest(curves, 0.01)

    MINI_CHECK(len(pairs) == 1)
    MINI_CHECK(pairs[0][0] == 0)
    MINI_CHECK(pairs[0][1] == 1)


@MINI_TEST("Closest", "Boxes Closest")
def test_closest_boxes_closest():
    from session_py import AABB
    from session_py import Closest

    # 3 boxes: first two touching faces (shared at x=1), third far away
    boxes = [
        AABB(0.0, 0.0, 0.0, 1.0, 1.0, 1.0),
        AABB(2.0, 0.0, 0.0, 1.0, 1.0, 1.0),
        AABB(20.0, 0.0, 0.0, 1.0, 1.0, 1.0),
    ]

    pairs = Closest.boxes_closest(boxes, 0.01)

    MINI_CHECK(len(pairs) == 1)
    MINI_CHECK(pairs[0][0] == 0)
    MINI_CHECK(pairs[0][1] == 1)


if __name__ == "__main__":
    run_all("python")
