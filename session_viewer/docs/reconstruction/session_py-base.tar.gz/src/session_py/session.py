from __future__ import annotations
from typing import Any
from typing import NamedTuple
from typing import TYPE_CHECKING
import copy
import json
import uuid
from .objects import Objects
from .objects import Component
from .point import Point
from .vector import Vector
from .line import Line
from .plane import Plane
from .obb import OBB
from .polyline import Polyline
from .pointcloud import PointCloud
from .mesh import Mesh
from .nurbscurve import NurbsCurve
from .nurbssurface import NurbsSurface
from .brep import BRep
from .element import Element
from .tree import Tree
from .tree import TreeNode
from .graph import Graph
from .history import History
from .history import AddOp
from .history import RemoveOp
from .history import ReplaceOp
from .history import XformOp
from .history import Tombstone
from .history import clone
from .spatial_bvh import SpatialBVH
from .tolerance import Tolerance
from .xform import Xform
from .intersection import line_line
from .intersection import line_plane
from .intersection import ray_box
from .intersection import ray_mesh_bvh

if TYPE_CHECKING:
    from pathlib import Path


COLLECTIONS = [
    ("points", "point"),
    ("lines", "line"),
    ("planes", "plane"),
    ("bboxes", "bbox"),
    ("polylines", "polyline"),
    ("pointclouds", "pointcloud"),
    ("meshes", "mesh"),
    ("nurbscurves", "nurbscurve"),
    ("nurbssurfaces", "nurbssurface"),
    ("breps", "brep"),
    ("elements", "element"),
    ("components", "component"),
]


class RayHit(NamedTuple):
    """One object a ray touched: which one, where, and how far from the ray origin."""

    guid: str
    hit_point: Point
    distance: float


def _clone_objects(objects: Objects) -> Objects:
    """A deep copy of every list and every object in it, guids included."""

    out = copy.deepcopy(objects)

    for collection, _ in COLLECTIONS:
        for src, dst in zip(getattr(objects, collection), getattr(out, collection)):
            dst.guid = src.guid

    return out


def _bake(items: list, world: dict[str, Xform]) -> None:
    """Transforms every object of a list by its world placement, identity entries untouched."""

    for item in items:
        xform = world.get(item.guid)

        if xform is None or xform.is_identity():
            continue

        item.transform(xform)


def _placed_box(points: list[Point], xform: Xform, inflate: float) -> OBB:
    """Inflated box around the placed points, around the origin when there are none."""

    if len(points) == 0:
        return OBB.from_point(Point(0, 0, 0), inflate)

    placed = []

    for point in points:
        placed.append(xform.transform_point(point))

    return OBB.from_points(placed, inflate)


def _ray_point(ray: Line, point: Point, tolerance: float) -> Point | None:
    """The point on the ray closest to point when it lies ahead and within tolerance."""

    ray_dir = ray.end() - ray.start()
    to_point = point - ray.start()
    t = to_point.dot(ray_dir) / ray_dir.dot(ray_dir)

    if t < 0:
        return None

    closest = ray.start() + ray_dir * t

    if point.distance(closest) > tolerance:
        return None

    return closest


class Session:
    """A session containing geometry objects."""

    def __init__(self, name: str = "my_session"):
        """Construct an empty session whose tree root carries the session name."""

        self._guid = None
        self.name = name  # The name of the session.
        self.objects = Objects()  # Collection of geometry objects.
        self.lookup: dict[str, Any] = {}  # Fast lookup table for geometry by GUID.
        self.tree = Tree(name=f"{name}_tree")  # Tree structure for hierarchy.
        self.graph = Graph(name=f"{name}_graph")  # Graph structure for relationships.
        self.component_lookup: dict[str, Component] = {}  # Components by GUID.
        self.xforms: dict[str, Xform] = {}  # Guid -> LOCAL transform.
        self.history = History()  # Undo/redo buffer, purged by every save.
        self.bvh = SpatialBVH()  # Bounding volume hierarchy for collision detection.
        self.cached_ray_bvh = SpatialBVH()  # Cached SpatialBVH for ray casting.
        self.cached_guids: list[str] = []  # GUID per leaf of cached_ray_bvh.
        self.cached_boxes: list[OBB] = []  # Box per leaf of cached_ray_bvh.
        self.bvh_cache_dirty = True  # Flag to rebuild cached_ray_bvh.

        self.tree.add(TreeNode(name=self.name))

    def __deepcopy__(self, memo):
        """Copy every table and object, guids included; caches are rebuilt on demand and history starts empty."""

        result = Session(self.name)

        if self.has_guid():
            result.guid = self.guid

        result.objects = _clone_objects(self.objects)
        result.tree = copy.deepcopy(self.tree, memo)
        result.graph = copy.deepcopy(self.graph, memo)
        result.xforms = copy.deepcopy(self.xforms, memo)
        result._index_objects()
        memo[id(self)] = result

        return result

    def has_guid(self) -> bool:
        """Return whether the lazy guid has been created."""
        return self._guid is not None

    @property
    def guid(self) -> str:
        """Return the guid, creating it on first access."""
        if self._guid is None:
            self._guid = str(uuid.uuid4())

        return self._guid

    @guid.setter
    def guid(self, value: str) -> None:
        """Set the guid."""
        self._guid = value

    # ═══════════════════════════════════════════════════════════════════════════
    # Accessors
    # ═══════════════════════════════════════════════════════════════════════════

    def get_object(self, guid: str) -> Any | None:
        """Get a geometry object by GUID, None when there is none."""
        return self.lookup.get(guid)

    def select_by_type(self, cls: type) -> list[list]:
        """Select objects of one type, grouped by the top-level nodes of the tree."""

        groups = []
        root = self.tree.root

        if root is None:
            return groups

        for group in root.children:
            items = []

            for node in group.descendants():
                obj = self.get_object(node.name)

                if isinstance(obj, cls):
                    items.append(obj)

            if items:
                groups.append(items)

        return groups

    def find_group(self, group_name: str) -> TreeNode:
        """Find an existing group by name; raises ValueError when there is none."""

        root = self.tree.root

        if root is not None:
            for child in root.children:
                if child is not None and child.name == group_name:
                    return child

        raise ValueError(f"Group '{group_name}' not found")

    def order(self) -> list[str]:
        """Canonical object order: the objects lists walked in one fixed type sequence."""

        order = []

        for point in self.objects.points:
            order.append(point.guid)

        for line in self.objects.lines:
            order.append(line.guid)

        for plane in self.objects.planes:
            order.append(plane.guid)

        for bbox in self.objects.bboxes:
            order.append(bbox.guid)

        for polyline in self.objects.polylines:
            order.append(polyline.guid)

        for pointcloud in self.objects.pointclouds:
            order.append(pointcloud.guid)

        for mesh in self.objects.meshes:
            order.append(mesh.guid)

        for nurbscurve in self.objects.nurbscurves:
            order.append(nurbscurve.guid)

        for nurbssurface in self.objects.nurbssurfaces:
            order.append(nurbssurface.guid)

        for brep in self.objects.breps:
            order.append(brep.guid)

        for element in self.objects.elements:
            order.append(element.guid)

        return order

    def xform(self, guid: str) -> Xform:
        """The LOCAL transform of an object, identity when none was set."""
        return self.xforms.get(guid, Xform.identity())

    def world_xform(self, guid: str) -> Xform:
        """The CUMULATIVE placement of an object: every ancestor's transform multiplied down the tree onto its own."""

        acc = self.xform(guid)
        node = self.tree.get_node_by_name(guid)

        if node is None:
            return acc

        for ancestor in node.ancestors:
            xform = self.xforms.get(ancestor.name)

            if xform is not None:
                acc = xform * acc

        return acc

    def world_xforms(self) -> dict[str, Xform]:
        """Every object's cumulative placement, computed in one downward pass."""

        out: dict[str, Xform] = {}

        if not self.xforms:
            return out

        stack = []

        if self.tree.root is not None:
            stack.append((self.tree.root, Xform.identity()))

        while stack:
            node, parent_xform = stack.pop()
            local = self.xforms.get(node.name)
            current = parent_xform if local is None else parent_xform * local
            out[node.name] = current

            for child in node.children:
                stack.append((child, current))

        for obj_guid, obj_xform in self.xforms.items():
            out.setdefault(obj_guid, obj_xform)

        return out

    def get_children(self, obj_guid: str) -> list[str]:
        """Get the children of a parent GUID."""
        return self.tree.get_children_guids(obj_guid)

    def get_neighbours(self, obj_guid: str) -> list[str]:
        """Get the neighbours of a GUID."""
        return self.graph.neighbors(obj_guid)

    def get_geometry(self) -> Objects:
        """All geometry with its hierarchical placement BAKED into the coordinates."""

        out = _clone_objects(self.objects)
        world = self.world_xforms()
        _bake(out.points, world)
        _bake(out.lines, world)
        _bake(out.planes, world)
        _bake(out.bboxes, world)
        _bake(out.polylines, world)
        _bake(out.pointclouds, world)
        _bake(out.meshes, world)
        _bake(out.nurbscurves, world)
        _bake(out.nurbssurfaces, world)
        _bake(out.breps, world)

        for element in out.elements:
            xform = world.get(element.guid)

            if xform is None or xform.is_identity():
                continue

            element.place(xform)

        return out

    # ═══════════════════════════════════════════════════════════════════════════
    # Geometry management
    # ═══════════════════════════════════════════════════════════════════════════

    def add_point(
        self, point: Point, parent: TreeNode | None = None
    ) -> TreeNode | None:
        """Add a point; None adds nothing and returns None."""
        if point is None:
            return None

        return self._add_object("points", point, "point", parent)

    def add_line(self, line: Line, parent: TreeNode | None = None) -> TreeNode | None:
        """Add a line; None adds nothing and returns None."""
        if line is None:
            return None

        return self._add_object("lines", line, "line", parent)

    def add_plane(
        self, plane: Plane, parent: TreeNode | None = None
    ) -> TreeNode | None:
        """Add a plane; None adds nothing and returns None."""
        if plane is None:
            return None

        return self._add_object("planes", plane, "plane", parent)

    def add_obb(self, bbox: OBB) -> TreeNode | None:
        """Add a bounding box; None adds nothing and returns None."""
        if bbox is None:
            return None

        return self._add_object("bboxes", bbox, "bbox", None)

    def add_polyline(
        self, polyline: Polyline, parent: TreeNode | None = None
    ) -> TreeNode | None:
        """Add a polyline; None, or fewer than two points, adds nothing and returns None."""
        if polyline is None or polyline.point_count() < 2:
            return None

        return self._add_object("polylines", polyline, "polyline", parent)

    def add_pointcloud(
        self, pointcloud: PointCloud, parent: TreeNode | None = None
    ) -> TreeNode | None:
        """Add a point cloud; None, or no points, adds nothing and returns None."""
        if pointcloud is None or pointcloud.is_empty():
            return None

        return self._add_object("pointclouds", pointcloud, "pointcloud", parent)

    def add_mesh(self, mesh: Mesh, parent: TreeNode | None = None) -> TreeNode | None:
        """Add a mesh; None, or no faces, adds nothing and returns None."""
        if mesh is None or mesh.is_empty() or mesh.number_of_faces() == 0:
            return None

        return self._add_object("meshes", mesh, "mesh", parent)

    def add_nurbscurve(
        self, nurbscurve: NurbsCurve, parent: TreeNode | None = None
    ) -> TreeNode | None:
        """Add a curve; None, or fewer than two control vertices, adds nothing and returns None."""
        if nurbscurve is None or nurbscurve.cv_count() < 2:
            return None

        return self._add_object("nurbscurves", nurbscurve, "nurbscurve", parent)

    def add_nurbssurface(
        self, nurbssurface: NurbsSurface, parent: TreeNode | None = None
    ) -> TreeNode | None:
        """Add a surface; None, or no control vertices, adds nothing and returns None."""
        if nurbssurface is None or nurbssurface.cv_count() == 0:
            return None

        return self._add_object("nurbssurfaces", nurbssurface, "nurbssurface", parent)

    def add_brep(self, brep: BRep, parent: TreeNode | None = None) -> TreeNode | None:
        """Add a brep; None, or no faces and no vertices, adds nothing and returns None."""
        if brep is None or (brep.face_count() == 0 and brep.vertex_count() == 0):
            return None

        return self._add_object("breps", brep, "brep", parent)

    def add_element(
        self, element: Element, parent: TreeNode | None = None
    ) -> TreeNode | None:
        """Add an element; only None adds nothing, an Element is a data record kept even without geometry."""
        if element is None:
            return None

        return self._add_object("elements", element, "element", parent)

    def add_component(
        self, component: Component, parent: TreeNode | None = None
    ) -> TreeNode:
        """Add a custom component (any object with type_name/guid/name/extra)."""
        return self._add_object("components", component, "component", parent)

    def add(self, node: TreeNode | None, parent: TreeNode | None = None) -> None:
        """Add a TreeNode to the tree hierarchy, under the root when no parent is given; None is ignored."""

        if node is None:
            return

        if parent is None:
            self.tree.add(node, self.tree.root)
        else:
            self.tree.add(node, parent)

    def add_group(self, group_name: str) -> TreeNode:
        """Create a named group (TreeNode) and add it to the root of the tree."""
        node = TreeNode(name=group_name)
        self.add(node)

        return node

    def add_edge(self, guid1: str, guid2: str, attribute: str = "") -> None:
        """Add an edge between two geometry objects in the graph."""
        self.graph.add_edge(guid1, guid2, attribute)

    def add_hierarchy(self, parent_guid: str, child_guid: str) -> bool:
        """Add a parent-child relationship in the tree."""
        return self.tree.add_child_by_guid(parent_guid, child_guid)

    def add_relationship(
        self, from_guid: str, to_guid: str, relationship_type: str = "default"
    ) -> None:
        """Add a relationship edge in the graph."""
        self.graph.add_edge(from_guid, to_guid, relationship_type)

    def remove_object(self, obj_guid: str) -> bool:
        """Remove an object by its GUID from every live table at once; the removal record is the tombstone undo restores from."""

        op = self._detach(obj_guid)

        if op is None:
            return False

        self.history.record(op)

        return True

    def replace(self, guid: str, obj: Any) -> bool:
        """Swap the object stored under guid for obj, which takes over that guid; the recorded edit undo and redo restore as absolute snapshots."""

        before = self.lookup.get(guid)

        if before is None:
            return False

        obj.guid = guid

        if self.history.current is not None:
            self.history.record(ReplaceOp(guid, clone(before), clone(obj)))

        self._swap(guid, obj)

        return True

    def set_xform(self, guid: str, xform: Xform) -> None:
        """Sets the LOCAL transform of an object, relative to its tree parent."""

        if self.history.current is not None:
            self.history.record(XformOp(guid, self.xforms.get(guid), xform))

        self.xforms[guid] = xform
        self.bvh_cache_dirty = True

    def remove_xform(self, guid: str) -> bool:
        """Removes an object's local transform, returning whether one was present."""

        before = self.xforms.get(guid)

        if before is None:
            return False

        if self.history.current is not None:
            self.history.record(XformOp(guid, before, None))

        del self.xforms[guid]
        self.bvh_cache_dirty = True

        return True

    # ═══════════════════════════════════════════════════════════════════════════
    # History
    # ═══════════════════════════════════════════════════════════════════════════

    def begin(self, label: str) -> None:
        """Open a history transaction: every add, remove, replace and xform change until commit becomes one undo step."""
        self.history.begin(label)

    def commit(self) -> None:
        """Close the open transaction as one undo step."""
        self.history.commit()

    def undo(self) -> bool:
        """Revert the latest committed transaction, returning whether there was one."""
        return self.history.undo(self)

    def redo(self) -> bool:
        """Reapply the latest undone transaction, returning whether there was one."""
        return self.history.redo(self)

    # ═══════════════════════════════════════════════════════════════════════════
    # Collision detection and ray casting
    # ═══════════════════════════════════════════════════════════════════════════

    @staticmethod
    def compute_bounding_box(geometry: Any, xform: Xform) -> OBB:
        """Bounding box of an object in WORLD placement, inflated by tolerance."""

        inflate = Tolerance.APPROXIMATION

        if isinstance(geometry, Point):
            return OBB.from_point(xform.transform_point(geometry), inflate)

        if isinstance(geometry, Plane):
            return OBB.from_point(
                xform.transform_point(geometry.origin), inflate * 10.0
            )

        if isinstance(geometry, OBB):
            inflated = copy.deepcopy(geometry)
            inflated.half_size = inflated.half_size + Vector(inflate, inflate, inflate)
            inflated.transform(xform)

            return inflated

        if isinstance(geometry, Element):
            box = copy.deepcopy(geometry.aabb)
            box.transform(xform)

            return box

        points = []

        if isinstance(geometry, Line):
            points.append(geometry.start())
            points.append(geometry.end())
        elif isinstance(geometry, (Polyline, PointCloud)):
            points = geometry.get_points()
        elif isinstance(geometry, Mesh):
            for vertex in geometry.vertex.values():
                points.append(vertex.position())
        elif isinstance(geometry, BRep):
            for vertex in geometry.m_vertices:
                points.append(vertex.point)

            for surface in geometry.m_surfaces:
                u0, u1 = surface.domain(0)
                v0, v1 = surface.domain(1)

                for i in range(3):
                    for j in range(3):
                        points.append(
                            surface.point_at(
                                u0 + (u1 - u0) * i / 2.0, v0 + (v1 - v0) * j / 2.0
                            )
                        )
        elif isinstance(geometry, NurbsCurve):
            for i in range(geometry.cv_count()):
                points.append(geometry.get_cv(i))
        elif isinstance(geometry, NurbsSurface):
            for i in range(geometry.cv_count(0)):
                for j in range(geometry.cv_count(1)):
                    points.append(geometry.get_cv(i, j))

        return _placed_box(points, xform, inflate)

    def get_collisions(self) -> list[tuple[str, str]]:
        """Get all collision pairs using SpatialBVH and add them as graph edges."""

        guids: list[str] = []
        boxes = self._compute_boxes(guids)

        if len(boxes) == 0:
            return []

        self.bvh = SpatialBVH.from_boxes(boxes, SpatialBVH.compute_world_size(boxes))
        pairs, _colliding, _checks = self.bvh.check_all_collisions(boxes)
        guid_pairs = []

        for i, j in pairs:
            if i < 0 or j < 0 or i >= len(guids) or j >= len(guids):
                continue

            guid_pairs.append((guids[i], guids[j]))
            self.graph.add_edge(guids[i], guids[j], "bvh_collision")

        return guid_pairs

    def ray_cast(
        self, origin: Point, direction: Vector, tolerance: float = 1e-3
    ) -> list[RayHit]:
        """Cast a ray through the scene, returning the hits within tolerance of the closest one."""

        if self.bvh_cache_dirty:
            self._rebuild_ray_bvh_cache()
            self.bvh_cache_dirty = False

        if len(self.cached_guids) == 0:
            return []

        candidates: list[int] = []
        self.cached_ray_bvh.ray_cast(origin, direction, candidates, True)
        ray = Line.from_points(origin, origin + direction * 10000.0)
        world = self.world_xforms()
        hits: list[RayHit] = []
        closest = float("inf")

        for index in candidates:
            guid = self.cached_guids[index]
            geometry = self.lookup.get(guid)

            if geometry is None:
                continue

            placement = world.get(guid, Xform.identity())
            hit = self._ray_intersect_geometry(ray, geometry, tolerance, placement)

            if hit is None:
                continue

            distance = origin.distance(hit)

            if distance >= closest:
                continue

            if distance < closest - tolerance:
                hits.clear()

            hits.append(RayHit(guid, hit, distance))
            closest = distance

        return hits

    # ═══════════════════════════════════════════════════════════════════════════
    # Serialization
    # ═══════════════════════════════════════════════════════════════════════════

    def __jsondump__(self) -> dict:
        """Serialize to a JSON object."""

        xforms = []

        for obj_guid, obj_xform in self._xforms_ordered():
            xforms.append({"guid": obj_guid, "xform": obj_xform.__jsondump__()})

        return {
            "type": "Session",
            "name": self.name,
            "guid": self.guid,
            "objects": self.objects.__jsondump__(),
            "tree": self.tree.__jsondump__(),
            "graph": self.graph.__jsondump__(),
            "xforms": xforms,
        }

    @classmethod
    def __jsonload__(
        cls, data: dict, guid: str | None = None, name: str | None = None
    ) -> Session:
        """Deserialize from a JSON object."""

        from .file_encoders import file_decode_node

        session = cls(name=data.get("name", "my_session"))
        session.guid = guid if guid is not None else data.get("guid", session.guid)

        if data.get("objects"):
            session.objects = file_decode_node(data["objects"])

        if data.get("tree"):
            session.tree = file_decode_node(data["tree"])

        if data.get("graph"):
            session.graph = file_decode_node(data["graph"])

        session._index_objects()

        for entry in data.get("xforms", []):
            session.xforms[entry["guid"]] = Xform.__jsonload__(entry["xform"])

        return session

    def file_json_dumps(self) -> str:
        """Serialize to a JSON string."""
        self.history.clear()

        return json.dumps(self.__jsondump__())

    @classmethod
    def file_json_loads(cls, json_string: str) -> Session:
        """Deserialize from a JSON string."""
        return cls.__jsonload__(json.loads(json_string))

    def file_json_dump(self, filename: str | Path) -> None:
        """Write to a JSON file."""
        self.history.clear()

        with open(filename, "w") as f:
            json.dump(self.__jsondump__(), f, indent=2)

    @classmethod
    def file_json_load(cls, filename: str | Path) -> Session:
        """Read from a JSON file."""
        with open(filename) as f:
            return cls.__jsonload__(json.load(f))

    def pb_dumps(self) -> bytes:
        """Serialize to protobuf bytes."""

        from .proto import session_pb2

        self.history.clear()
        proto = session_pb2.Session()
        proto.name = self.name

        if self.has_guid():
            proto.guid = self.guid

        proto.objects.ParseFromString(self.objects.pb_dumps())
        proto.tree.ParseFromString(self.tree.pb_dumps())
        proto.graph.ParseFromString(self.graph.pb_dumps())

        for obj_guid, obj_xform in self._xforms_ordered():
            entry = proto.xforms.add()
            entry.guid = obj_guid
            entry.xform.ParseFromString(obj_xform.pb_dumps())

        return proto.SerializeToString()

    @classmethod
    def pb_loads(cls, data: bytes) -> Session:
        """Deserialize from protobuf bytes."""

        from .proto import session_pb2

        proto = session_pb2.Session()
        proto.ParseFromString(data)
        session = cls(name=proto.name)

        if proto.guid:
            session.guid = proto.guid

        if proto.HasField("objects"):
            session.objects = Objects.from_proto(proto.objects)

        if proto.HasField("tree"):
            session.tree = Tree.pb_loads(proto.tree.SerializeToString())

        if proto.HasField("graph"):
            session.graph = Graph.pb_loads(proto.graph.SerializeToString())

        session._index_objects()

        for entry in proto.xforms:
            session.xforms[entry.guid] = Xform.pb_loads(entry.xform.SerializeToString())

        return session

    def pb_dump(self, filename: str | Path) -> None:
        """Write to a protobuf file."""
        self.history.clear()

        with open(filename, "wb") as f:
            f.write(self.pb_dumps())

    @classmethod
    def pb_load(cls, filename: str | Path) -> Session:
        """Read from a protobuf file."""
        with open(filename, "rb") as f:
            return cls.pb_loads(f.read())

    def __str__(self) -> str:
        """Return a string representation of the session."""
        return f"Session(name={self.name}, objects={self.objects.to_str()}, tree={self.tree.to_str()}, graph={self.graph.to_str()})"

    def __repr__(self) -> str:
        """Return a string representation of the session for debugging."""
        return self.__str__()

    # ═══════════════════════════════════════════════════════════════════════════
    # Details
    # ═══════════════════════════════════════════════════════════════════════════

    def _add_object(
        self, collection: str, obj: Any, type_prefix: str, parent: TreeNode | None
    ) -> TreeNode:
        """Store an object in its typed list, lookup, graph and tree, recording an AddOp when a transaction is open."""

        guid = obj.guid
        items = getattr(self.objects, collection)
        items.append(obj)
        obj_index = len(items) - 1

        if collection == "components":
            self.component_lookup[guid] = obj
        else:
            self.lookup[guid] = obj

        attribute = f"{type_prefix}_{obj.name}"
        self.graph.add_node(guid, attribute)
        self.bvh_cache_dirty = True
        node = TreeNode(name=guid)
        parent_guid = None
        index = 0

        if parent is not None:
            self.add(node, parent)
            parent_guid = parent.name
            index = len(parent.children) - 1

        if self.history.current is not None:
            self.history.record(
                AddOp(
                    guid,
                    clone(obj),
                    collection,
                    obj_index,
                    None,
                    parent_guid,
                    index,
                    None,
                    attribute,
                    [],
                )
            )

        return node

    def _locate(self, guid: str) -> tuple[str, int]:
        """Which Objects list holds a guid, and where; ("", -1) when none does."""

        for collection, prefix in COLLECTIONS:
            items = getattr(self.objects, collection)

            for i in range(len(items)):
                if items[i].guid == guid:
                    return collection, i

        return "", -1

    def _detach(self, guid: str) -> RemoveOp | None:
        """Take an object out of every live table, unrecorded, returning its tombstone."""

        obj = self.lookup.get(guid)

        if obj is None:
            obj = self.component_lookup.get(guid)

        if obj is None:
            return None

        collection, obj_index = self._locate(guid)

        if obj_index >= 0:
            getattr(self.objects, collection).pop(obj_index)

        self.lookup.pop(guid, None)
        self.component_lookup.pop(guid, None)
        xform = self.xforms.pop(guid, None)
        self.bvh_cache_dirty = True
        parent_guid = None
        index = 0
        node = self.tree.get_node_by_name(guid)

        if node is not None:
            parent = node.parent

            if parent is not None:
                parent_guid = parent.name
                index = parent.children.index(node)

            node = self.tree.remove(node)

        attribute = ""
        edges = []

        if self.graph.has_node(guid):
            attribute = self.graph.node_attribute(guid)
            edges = self.graph.edges_of(guid)
            self.graph.remove_node(guid)

        return RemoveOp(
            guid,
            clone(obj),
            collection,
            obj_index,
            xform,
            parent_guid,
            index,
            node,
            attribute,
            edges,
        )

    def _attach(self, op: Tombstone) -> None:
        """Put an object back from its tombstone, unrecorded: typed list, lookup, xform, tree node with its subtree, graph node and edges."""

        obj = clone(op.obj)
        items = getattr(self.objects, op.collection)
        items.insert(min(op.obj_index, len(items)), obj)

        if op.collection == "components":
            self.component_lookup[op.guid] = obj
        else:
            self.lookup[op.guid] = obj

        if op.xform is not None:
            self.xforms[op.guid] = op.xform

        self.bvh_cache_dirty = True
        node = op.node

        if node is None:
            node = TreeNode(name=op.guid)

        if op.parent_guid is not None:
            parent = self.tree.get_node_by_name(op.parent_guid)

            if parent is not None:
                self.tree.add(node, parent)
                children = list(parent.children)

                for i in range(min(op.index, len(children) - 1), len(children) - 1):
                    parent.add(parent.remove(children[i]))

        self.graph.add_node(op.guid, op.attribute)

        for other, attribute, forward in op.edges:
            if not self.graph.has_node(other):
                continue

            if forward:
                self.graph.add_edge(op.guid, other, attribute)
            else:
                self.graph.add_edge(other, op.guid, attribute)

    def _swap(self, guid: str, obj: Any) -> None:
        """Store obj under guid in its typed list and lookup, unrecorded."""

        collection, obj_index = self._locate(guid)

        if obj_index < 0:
            return

        getattr(self.objects, collection)[obj_index] = obj

        if collection == "components":
            self.component_lookup[guid] = obj
        else:
            self.lookup[guid] = obj

        self.bvh_cache_dirty = True
        attribute = ""

        for name, prefix in COLLECTIONS:
            if name == collection:
                attribute = f"{prefix}_{obj.name}"

        if self.graph.has_node(guid):
            self.graph.node_attribute(guid, attribute)

    def _index_objects(self) -> None:
        """Point lookup and component_lookup at the objects this session currently holds."""

        self.lookup.clear()
        self.component_lookup.clear()

        for point in self.objects.points:
            self.lookup[point.guid] = point

        for line in self.objects.lines:
            self.lookup[line.guid] = line

        for plane in self.objects.planes:
            self.lookup[plane.guid] = plane

        for bbox in self.objects.bboxes:
            self.lookup[bbox.guid] = bbox

        for polyline in self.objects.polylines:
            self.lookup[polyline.guid] = polyline

        for pointcloud in self.objects.pointclouds:
            self.lookup[pointcloud.guid] = pointcloud

        for mesh in self.objects.meshes:
            self.lookup[mesh.guid] = mesh

        for nurbscurve in self.objects.nurbscurves:
            self.lookup[nurbscurve.guid] = nurbscurve

        for nurbssurface in self.objects.nurbssurfaces:
            self.lookup[nurbssurface.guid] = nurbssurface

        for brep in self.objects.breps:
            self.lookup[brep.guid] = brep

        for element in self.objects.elements:
            self.lookup[element.guid] = element

        for component in self.objects.components:
            self.component_lookup[component.guid] = component

    def _place(self, guid: str, xform: Xform | None) -> None:
        """Set or drop (None) the local transform under guid, unrecorded."""

        if xform is not None:
            self.xforms[guid] = xform
        else:
            self.xforms.pop(guid, None)

        self.bvh_cache_dirty = True

    def _xforms_ordered(self) -> list[tuple[str, Xform]]:
        """The xforms in canonical order() sequence, identity entries omitted, the exact sequence __jsondump__ and pb_dumps write."""

        ordered = []
        rest = {}

        for obj_guid, obj_xform in self.xforms.items():
            if not obj_xform.is_identity():
                rest[obj_guid] = obj_xform

        for obj_guid in self.order():
            obj_xform = rest.pop(obj_guid, None)

            if obj_xform is None:
                continue

            ordered.append((obj_guid, obj_xform))

        for obj_guid in sorted(rest):
            ordered.append((obj_guid, rest[obj_guid]))

        return ordered

    def _compute_boxes(self, guids: list[str]) -> list[OBB]:
        """World bounding box of every object in order() sequence, with the guid of each."""

        guids.clear()
        boxes = []
        world = self.world_xforms()

        for guid in self.order():
            geometry = self.lookup.get(guid)

            if geometry is None:
                continue

            boxes.append(
                self.compute_bounding_box(geometry, world.get(guid, Xform.identity()))
            )
            guids.append(guid)

        return boxes

    def _rebuild_ray_bvh_cache(self) -> None:
        """Rebuild the cached SpatialBVH for ray casting."""

        self.cached_boxes = self._compute_boxes(self.cached_guids)

        if len(self.cached_boxes) == 0:
            self.cached_ray_bvh = SpatialBVH()
        else:
            self.cached_ray_bvh = SpatialBVH.from_boxes(
                self.cached_boxes, SpatialBVH.compute_world_size(self.cached_boxes)
            )

    def _ray_intersect_geometry(
        self, ray: Line, geometry: Any, tolerance: float, placement: Xform
    ) -> Point | None:
        """Test ray intersection with a specific geometry object, returning the world hit."""

        if isinstance(geometry, Point):
            return _ray_point(ray, geometry, tolerance)

        if isinstance(geometry, Line):
            return line_line(ray, geometry, tolerance)

        if isinstance(geometry, Plane):
            return line_plane(ray, geometry, True)

        if isinstance(geometry, Polyline):
            closest = None
            min_dist = float("inf")

            for i in range(geometry.segment_count()):
                segment = Line.from_points(
                    geometry.get_point(i), geometry.get_point(i + 1)
                )
                hit = line_line(ray, segment, tolerance)

                if hit is None:
                    continue

                dist = ray.start().distance(hit)

                if dist < min_dist:
                    min_dist = dist
                    closest = hit

            return closest

        if isinstance(geometry, PointCloud):
            closest = None
            min_dist = float("inf")

            for point in geometry.get_points():
                hit = _ray_point(ray, point, tolerance)

                if hit is None:
                    continue

                dist = point.distance(hit)

                if dist < min_dist:
                    min_dist = dist
                    closest = hit

            return closest

        if isinstance(geometry, Mesh):
            inverse = placement.inverse()

            if inverse is None:
                return None

            local_ray = Line.from_points(
                inverse.transform_point(ray.start()), inverse.transform_point(ray.end())
            )
            hits = ray_mesh_bvh(local_ray, geometry, tolerance, True)

            if not hits:
                return None

            return placement.transform_point(hits[0])

        if isinstance(geometry, OBB):
            hits = ray_box(ray, geometry, 0.0, 1.0)

            if not hits:
                return None

            return hits[0]

        return None
