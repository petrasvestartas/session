from __future__ import annotations
from collections.abc import Iterator
from typing import Optional
from typing import Union
from typing import TYPE_CHECKING
import uuid

if TYPE_CHECKING:
    from pathlib import Path


class Vertex:
    """A graph vertex with a unique identifier and attribute string."""

    def __init__(self, name: str = "my_vertex", attribute: str = ""):
        self._guid = None
        self.name = str(name)
        self.attribute = str(attribute)
        self.index = None

    def has_guid(self) -> bool:
        return getattr(self, '_guid', None) is not None

    @property
    def guid(self) -> str:
        if getattr(self, '_guid', None) is None:
            self._guid = str(uuid.uuid4())
        return self._guid

    def has_guid(self) -> bool:
        """Whether this identity has actually been minted.

        A serializer that reads ``guid`` MINTS one for everything it writes, which defeats the
        lazy scheme everywhere it is used on a bulk collection: a drawing sheet with 34,592
        graph vertices generated 34,592 UUIDs at write time and put ~1.3 MB of them in the file
        for a ``Session.pb_loads`` that discards every one. Ask this first, and write nothing
        when the answer is no.
        """
        return getattr(self, "_guid", None) is not None

    @guid.setter
    def guid(self, value: str) -> None:
        self._guid = value

    def __jsondump__(self):
        return {
            "type": f"{self.__class__.__name__}",
            "guid": self.guid,
            "name": self.name,
            "attribute": self.attribute,
            "index": self.index,
        }

    @classmethod
    def __jsonload__(cls, data, guid=None, name=None):
        vertex = cls(data["name"], data.get("attribute", ""))
        vertex.index = data.get("index")
        vertex.guid = guid if guid is not None else data.get("guid", vertex.guid)
        return vertex


class Edge:
    """A graph edge connecting two vertices with an attribute string."""

    def __init__(self, v0: str | int, v1: str | int, attribute: str = ""):
        self._guid = None
        self.name = "my_edge"
        self.v0 = str(v0)
        self.v1 = str(v1)
        self.attribute = str(attribute)
        self.index = None

    def has_guid(self) -> bool:
        return getattr(self, '_guid', None) is not None

    @property
    def guid(self) -> str:
        if getattr(self, '_guid', None) is None:
            self._guid = str(uuid.uuid4())
        return self._guid

    def has_guid(self) -> bool:
        """Whether this identity has actually been minted.

        A serializer that reads ``guid`` MINTS one for everything it writes, which defeats the
        lazy scheme everywhere it is used on a bulk collection: a drawing sheet with 34,592
        graph vertices generated 34,592 UUIDs at write time and put ~1.3 MB of them in the file
        for a ``Session.pb_loads`` that discards every one. Ask this first, and write nothing
        when the answer is no.
        """
        return getattr(self, "_guid", None) is not None

    @guid.setter
    def guid(self, value: str) -> None:
        self._guid = value

    def __jsondump__(self):
        return {
            "type": f"{self.__class__.__name__}",
            "guid": self.guid,
            "name": self.name,
            "v0": self.v0,
            "v1": self.v1,
            "attribute": self.attribute,
            "index": self.index,
        }

    @classmethod
    def __jsonload__(cls, data, guid=None, name=None):
        edge = cls(data["v0"], data["v1"], data.get("attribute", ""))
        edge.index = data.get("index")
        edge.guid = guid if guid is not None else data.get("guid", edge.guid)
        edge.name = name if name is not None else data.get("name", edge.name)
        return edge

    @property
    def vertices(self) -> tuple[str, str]:
        return (self.v0, self.v1)

    def connects(self, vertex_id: str | int) -> bool:
        return str(vertex_id) in self.vertices

    def other_vertex(self, vertex_id: str | int) -> str:
        vertex_id = str(vertex_id)
        if vertex_id == self.v0:
            return self.v1
        elif vertex_id == self.v1:
            return self.v0
        else:
            raise ValueError(f"Vertex {vertex_id} is not connected by this edge")


class Graph:
    """A graph data structure with string-only vertices and attributes.

    Parameters
    ----------
    name : str, optional
        Name of the graph.
    default_node_attributes : dict, optional
        Default attributes for new vertices.
    default_edge_attributes : dict, optional
        Default attributes for new edges.

    """

    def __init__(self, name: str = "my_graph"):
        """Initialize a new Graph."""
        self.name = name
        self._guid = None
        self.vertices = {}  # node_name -> Vertex object
        self.edges = {}  # node_name -> {neighbor_name -> Edge object}
        self.vertex_count = 0  # Track next available vertex index
        self.edge_count = 0  # Track next available edge index

    def has_guid(self) -> bool:
        return getattr(self, '_guid', None) is not None

    @property
    def guid(self) -> str:
        if getattr(self, '_guid', None) is None:
            self._guid = str(uuid.uuid4())
        return self._guid

    def has_guid(self) -> bool:
        """Whether this identity has actually been minted.

        A serializer that reads ``guid`` MINTS one for everything it writes, which defeats the
        lazy scheme everywhere it is used on a bulk collection: a drawing sheet with 34,592
        graph vertices generated 34,592 UUIDs at write time and put ~1.3 MB of them in the file
        for a ``Session.pb_loads`` that discards every one. Ask this first, and write nothing
        when the answer is no.
        """
        return getattr(self, "_guid", None) is not None

    @guid.setter
    def guid(self, value: str) -> None:
        self._guid = value

    def __str__(self):
        """String representation."""
        return f"Graph({self.name}, {len(self.vertices)} vertices, {len(self.edges)} edges)"

    def __repr__(self):
        return f"Graph({self.name}, {len(self.vertices)} vertices, {len(self.edges)} edges)"

    # ═══════════════════════════════════════════════════════════════════════════
    # JSON (polymorphic)
    # ═══════════════════════════════════════════════════════════════════════════

    def __jsondump__(self):
        """Serialize to polymorphic JSON format with type field."""
        # Only store each undirected edge once (u < v)
        seen = set()
        edges_list = []
        for u, neighbors in self.edges.items():
            for v, edge in neighbors.items():
                key = (u, v) if u < v else (v, u)
                if key in seen:
                    continue
                seen.add(key)
                edges_list.append(edge.__jsondump__())

        return {
            "type": f"{self.__class__.__name__}",
            "guid": self.guid,
            "name": self.name,
            "vertices": [vertex.__jsondump__() for vertex in self.vertices.values()],
            "edges": edges_list,
            "vertex_count": self.vertex_count,
            "edge_count": self.edge_count,
        }

    @classmethod
    def __jsonload__(cls, data, guid=None, name=None):
        """Deserialize from polymorphic JSON format."""
        graph = cls(name=data.get("name", "my_graph"))
        graph.guid = guid if guid is not None else data.get("guid", graph.guid)
        graph.vertex_count = data.get("vertex_count", 0)
        graph.edge_count = data.get("edge_count", 0)

        # Restore vertices
        for vertex_data in data.get("vertices", []):
            # When decoding, nested vertices may already be reconstructed objects
            if isinstance(vertex_data, Vertex):
                vtx = vertex_data
            elif isinstance(vertex_data, dict):
                vtx = Vertex.__jsonload__(
                    vertex_data,
                    vertex_data.get("guid"),
                    vertex_data.get("name"),
                )
            else:
                continue
            graph.vertices[str(vtx.name)] = vtx

        # Restore edges
        for edge_data in data.get("edges", []):
            if isinstance(edge_data, Edge):
                e = edge_data
            elif isinstance(edge_data, dict):
                e = Edge.__jsonload__(
                    edge_data,
                    edge_data.get("guid"),
                    edge_data.get("name"),
                )
            else:
                continue
            u, v = str(e.v0), str(e.v1)
            if u not in graph.edges:
                graph.edges[u] = {}
            if v not in graph.edges:
                graph.edges[v] = {}
            graph.edges[u][v] = e
            graph.edges[v][u] = e

        return graph

    # ═══════════════════════════════════════════════════════════════════════════
    # Serialization: file_json_dumps, file_json_loads, file_json_dump, file_json_load
    # ═══════════════════════════════════════════════════════════════════════════

    def file_json_dumps(self) -> str:
        import json
        return json.dumps(self.__jsondump__())

    @classmethod
    def file_json_loads(cls, s: str) -> "Graph":
        import json
        return cls.__jsonload__(json.loads(s))

    def file_json_dump(self, filepath: Union[str, "Path"]) -> None:
        import json
        with open(filepath, 'w') as f:
            json.dump(self.__jsondump__(), f, indent=2)

    @classmethod
    def file_json_load(cls, filepath: Union[str, "Path"]) -> "Graph":
        import json
        with open(filepath) as f:
            return cls.__jsonload__(json.load(f))

    # ═══════════════════════════════════════════════════════════════════════════
    # Serialization: pb_dumps, pb_loads, pb_dump, pb_load
    # ═══════════════════════════════════════════════════════════════════════════

    def pb_dumps(self) -> bytes:
        from .proto import graph_pb2

        proto = graph_pb2.Graph()
        proto.name = self.name
        if self.has_guid():
            proto.guid = self._guid
        proto.vertex_count = self.vertex_count
        proto.edge_count = self.edge_count

        for name, vertex in self.vertices.items():
            v = proto.vertices[name]
            v.name = vertex.name
            if vertex.has_guid():
                v.guid = vertex.guid
            v.attribute = vertex.attribute
            v.index = vertex.index

        seen = set()
        for u, neighbors in self.edges.items():
            for v, edge in neighbors.items():
                key = (u, v) if u < v else (v, u)
                if key in seen:
                    continue
                seen.add(key)
                e = proto.edges.add()
                if edge.has_guid():
                    e.guid = edge.guid
                e.name = edge.name
                e.v0 = edge.v0
                e.v1 = edge.v1
                e.attribute = edge.attribute
                e.index = edge.index

        return proto.SerializeToString()

    @classmethod
    def pb_loads(cls, data: bytes) -> "Graph":
        from .proto import graph_pb2

        proto = graph_pb2.Graph()
        proto.ParseFromString(data)

        graph = cls(name=proto.name)
        if proto.guid:
            graph.guid = proto.guid
        graph.vertex_count = proto.vertex_count
        graph.edge_count = proto.edge_count

        for name, v in proto.vertices.items():
            vertex = Vertex(v.name, v.attribute)
            vertex.guid = v.guid
            vertex.index = v.index
            graph.vertices[name] = vertex

        for e in proto.edges:
            edge = Edge(e.v0, e.v1, e.attribute)
            edge.guid = e.guid
            edge.name = e.name
            edge.index = e.index
            if e.v0 not in graph.edges:
                graph.edges[e.v0] = {}
            if e.v1 not in graph.edges:
                graph.edges[e.v1] = {}
            graph.edges[e.v0][e.v1] = edge
            graph.edges[e.v1][e.v0] = edge

        return graph

    def pb_dump(self, filepath: Union[str, "Path"]) -> None:
        with open(filepath, 'wb') as f:
            f.write(self.pb_dumps())

    @classmethod
    def pb_load(cls, filepath: Union[str, "Path"]) -> "Graph":
        with open(filepath, 'rb') as f:
            return cls.pb_loads(f.read())

    # ═══════════════════════════════════════════════════════════════════════════
    # Details: Essential Graph Methods
    # ═══════════════════════════════════════════════════════════════════════════

    def has_node(self, key: str) -> bool:
        """Check if a node exists in the graph.

        Parameters
        ----------
        key : str
            The node to check for.

        Returns
        -------
        bool
            True if the node exists.

        Examples
        --------
        >>> graph = Graph()
        >>> graph.add_node("node1")
        'node1'
        >>> graph.has_node("node1")
        True
        >>> graph.has_node("node2")
        False
        """
        return key in self.vertices

    def has_edge(self, edge: tuple | str) -> bool:
        """Check if an edge exists in the graph.

        Parameters
        ----------
        edge : tuple or str
            Either a tuple (u, v) or two separate arguments u, v.

        Returns
        -------
        bool
            True if the edge exists, False otherwise.

        Examples
        --------
        >>> graph = Graph()
        >>> graph.add_edge("A", "B", "edge_attr")
        ('A', 'B')
        >>> graph.has_edge(("A", "B"))
        True
        >>> graph.has_edge(("C", "D"))
        False
        """
        if isinstance(edge, tuple):
            u, v = edge
        else:
            raise ValueError("Edge must be a tuple (u, v)")

        return u in self.edges and v in self.edges[u]

    def add_node(self, key: str, attribute: str = "") -> str:
        """Add a node to the graph.

        Parameters
        ----------
        key : str
            The node identifier.
        attribute : str, optional
            Node attribute data.

        Returns
        -------
        str
            The node key that was added.

        Examples
        --------
        >>> graph = Graph()
        >>> graph.add_node("node1", "attribute_data")
        'node1'
        >>> graph.has_node("node1")
        True
        """
        if not isinstance(key, str):
            raise TypeError(f"Node keys must be strings, got {type(key)}")

        if self.has_node(key):
            return self.vertices[key]
        else:
            vertex = Vertex(key, attribute)
            vertex.index = self.vertex_count  # Set index internally
            self.vertices[key] = vertex
            self.vertex_count += 1
            return vertex.name

    def add_edge(self, u: str, v: str, attribute: str = "") -> tuple:
        """Add an edge between u and v.

        Parameters
        ----------
        u : str
            First node (must be string).
        v : str
            Second node (must be string).
        attribute : str, optional
            Single string attribute for the edge.

        Returns
        -------
        tuple
            The edge tuple (u, v).

        Raises
        ------
        TypeError
            If u or v are not strings.

        Examples
        --------
        >>> graph = Graph()
        >>> graph.add_edge("node1", "node2", "edge_data")
        ('node1', 'node2')
        >>> graph.has_edge(("node1", "node2"))
        True
        """
        if not isinstance(u, str) or not isinstance(v, str):
            raise TypeError(f"Node keys must be strings, got {type(u)} and {type(v)}")

        # Add vertices if they don't exist
        if not self.has_node(u):
            self.add_node(u)
        if not self.has_node(v):
            self.add_node(v)

        # Add edge (store in both directions for undirected graph)
        edge = Edge(u, v, attribute)
        edge.index = self.edge_count  # Set index internally
        if u not in self.edges:
            self.edges[u] = {}
        if v not in self.edges:
            self.edges[v] = {}
        self.edges[u][v] = edge
        self.edges[v][u] = edge
        self.edge_count += 1

        return (u, v)

    def remove_node(self, key: str) -> None:
        """Remove a node and all its edges from the graph.

        Parameters
        ----------
        key : str
            The node to remove.

        Raises
        ------
        KeyError
            If the node is not in the graph.

        Examples
        --------
        >>> graph = Graph()
        >>> graph.add_node("node1")
        'node1'
        >>> graph.remove_node("node1")
        >>> graph.has_node("node1")
        False
        """
        if not self.has_node(key):
            raise KeyError(f"Node {key} not in graph")

        # Remove all edges connected to this node
        if key in self.edges:
            for neighbor in list(self.edges[key].keys()):
                if neighbor in self.edges:
                    self.edges[neighbor].pop(key, None)
            del self.edges[key]

        # Remove the node itself
        del self.vertices[key]

        # Reassign indices to maintain contiguous sequence
        self._reassign_indices()

    def remove_edge(self, edge: tuple) -> None:
        """Remove an edge from the graph.

        Parameters
        ----------
        edge : tuple
            A tuple (u, v) representing the edge to remove.

        Examples
        --------
        >>> graph = Graph()
        >>> graph.add_edge("A", "B", "edge_attr")
        ('A', 'B')
        >>> graph.remove_edge(("A", "B"))
        >>> graph.has_edge(("A", "B"))
        False
        """
        u, v = edge
        if self.has_edge((u, v)):
            if u in self.edges and v in self.edges[u]:
                del self.edges[u][v]
            if v in self.edges and u in self.edges[v]:
                del self.edges[v][u]

            # Reassign edge indices to maintain contiguous sequence
            self._reassign_edge_indices()

    def _reassign_indices(self):
        """Reassign vertex indices to maintain contiguous sequence 0, 1, 2, ..."""
        vertices = list(self.vertices.values())
        # Sort by current index to maintain relative order
        vertices.sort(key=lambda v: v.index if v.index is not None else float("inf"))

        for i, vertex in enumerate(vertices):
            vertex.index = i

        self.vertex_count = len(vertices)

    def _reassign_edge_indices(self):
        """Reassign edge indices to maintain contiguous sequence 0, 1, 2, ..."""
        edges = []
        seen = set()

        # Collect all unique edges
        for u, neighbors in self.edges.items():
            for v, edge in neighbors.items():
                edge_tuple = (u, v) if u < v else (v, u)
                if edge_tuple not in seen:
                    seen.add(edge_tuple)
                    edges.append(edge)

        # Sort by current index to maintain relative order
        edges.sort(key=lambda e: e.index if e.index is not None else float("inf"))

        # Reassign indices
        for i, edge in enumerate(edges):
            edge.index = i

        self.edge_count = len(edges)

    def get_vertices(self) -> list["Vertex"]:
        """Return a list of all vertices in the graph.

        Returns
        -------
        list[:class:`Vertex`]
            A list of all vertex objects in the graph.
        """
        return list(self.vertices.values())

    def get_edges(self) -> Iterator[tuple[str, str]]:
        """Iterate over all edges in the graph.

        Yields
        ------
        tuple
            Edge identifier (u, v)

        Examples
        --------
        >>> graph = Graph()
        >>> graph.add_edge("node1", "node2", "edge_data")
        ('node1', 'node2')
        >>> edges = list(graph.edges())
        >>> assert ("node1", "node2") in edges
        >>> assert len(edges) == 1
        """
        seen = set()
        for u, neighbors in self.edges.items():
            for v, edge in neighbors.items():
                edge_tuple = (u, v) if u < v else (v, u)
                if edge_tuple not in seen:
                    seen.add(edge_tuple)
                    yield edge_tuple

    def neighbors(self, node: str) -> Iterator[str]:
        """Get all neighbors of a node.

        Parameters
        ----------
        node : str
            The node to get neighbors for.

        Returns
        -------
        iterator
            Iterator over neighbor vertices.

        Examples
        --------
        >>> graph = Graph()
        >>> graph.add_edge("A", "B", "edge1")
        ('A', 'B')
        >>> graph.add_edge("A", "C", "edge2")
        ('A', 'C')
        >>> sorted(list(graph.neighbors("A")))
        ['B', 'C']
        """
        return iter(self.edges.get(node, {}).keys())

    def get_neighbors(self, node: str) -> list[str]:
        return list(self.neighbors(node))

    def number_of_vertices(self) -> int:
        """Get the number of vertices in the graph.

        Returns
        -------
        int
            Number of vertices.

        Examples
        --------
        >>> graph = Graph()
        >>> graph.add_node("node1")
        'node1'
        >>> graph.number_of_vertices()
        1
        """
        return len(self.vertices)

    def number_of_edges(self) -> int:
        """Get the number of edges in the graph.

        Returns
        -------
        int
            Number of edges.

        Examples
        --------
        >>> graph = Graph()
        >>> graph.add_edge("node1", "node2")
        ('node1', 'node2')
        >>> graph.number_of_edges()
        1
        """
        return sum(len(neighbors) for neighbors in self.edges.values()) // 2

    def clear(self) -> None:
        """Remove all vertices and edges from the graph.

        Examples
        --------
        >>> graph = Graph()
        >>> graph.add_node("node1")
        'node1'
        >>> graph.clear()
        >>> graph.number_of_vertices()
        0
        """
        self.vertices.clear()
        self.edges.clear()
        self.vertex_count = 0
        self.edge_count = 0

    def node_attribute(self, node: str, value: str | None = None) -> str:
        """Get or set node attribute.

        Parameters
        ----------
        node : str
            The node identifier.
        value : str, optional
            If provided, set the attribute to this value.

        Returns
        -------
        str
            The attribute value as string.

        Raises
        ------
        KeyError
            If the node does not exist.

        Examples
        --------
        >>> graph = Graph()
        >>> graph.add_node("node1", "initial_data")
        'node1'
        >>> assert graph.node_attribute("node1") == "initial_data"
        >>> graph.node_attribute("node1", "new_data")
        >>> assert graph.node_attribute("node1") == "new_data"
        """
        if not self.has_node(node):
            raise KeyError(f"Node {node} not in graph")

        node_obj = self.vertices[node]
        if value is not None:
            node_obj.attribute = str(value)
            return value
        else:
            return node_obj.attribute

    def edge_attribute(self, u: str, v: str, value: str | None = None) -> str:
        """Get or set edge attribute.

        Parameters
        ----------
        u : hashable
            First vertex of the edge.
        v : hashable
            Second vertex of the edge.
        value : str, optional
            If provided, set the attribute to this value.

        Returns
        -------
        str
            The attribute value as string.

        Raises
        ------
        KeyError
            If the edge does not exist.

        Examples
        --------
        >>> graph = Graph()
        >>> graph.add_edge("node1", "node2", "edge_data")
        ('node1', 'node2')
        >>> graph.edge_attribute("node1", "node2")
        'edge_data'
        >>> graph.edge_attribute("node1", "node2", "new_data")
        'new_data'
        >>> graph.edge_attribute("node1", "node2")
        'new_data'
        """
        if not self.has_edge((u, v)):
            raise KeyError(f"Edge {(u, v)} not in graph")

        if u in self.edges and v in self.edges[u]:
            edge_obj = self.edges[u][v]
        else:
            raise KeyError(f"Edge {(u, v)} not in graph")

        if value is not None:
            edge_obj.attribute = str(value)
            # Update both directions
            if v in self.edges and u in self.edges[v]:
                self.edges[v][u].attribute = str(value)
            return str(value)
        else:
            return edge_obj.attribute

    # ═══════════════════════════════════════════════════════════════════════════
    # Algorithms
    # ═══════════════════════════════════════════════════════════════════════════

    def bfs(self, start: str) -> list[str]:
        if not self.has_node(start):
            return []
        visited = set()
        queue = [start]
        visited.add(start)
        result = []
        while queue:
            node = queue.pop(0)
            result.append(node)
            for neighbor in sorted(self.edges.get(node, {}).keys()):
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append(neighbor)
        return result

    def dfs(self, start: str) -> list[str]:
        if not self.has_node(start):
            return []
        visited = set()
        result = []
        stack = [start]
        while stack:
            node = stack.pop()
            if node in visited:
                continue
            visited.add(node)
            result.append(node)
            for neighbor in reversed(sorted(self.edges.get(node, {}).keys())):
                if neighbor not in visited:
                    stack.append(neighbor)
        return result

    def connected_components(self) -> list[list[str]]:
        visited = set()
        components = []
        for start in sorted(self.vertices.keys()):
            if start in visited:
                continue
            comp = self.bfs(start)
            visited.update(comp)
            components.append(sorted(comp))
        return components

    def is_connected(self) -> bool:
        return len(self.connected_components()) <= 1

    def number_connected_components(self) -> int:
        return len(self.connected_components())

    def shortest_path(self, u: str, v: str) -> list[str]:
        if not self.has_node(u) or not self.has_node(v):
            return []
        if u == v:
            return [u]
        parent = {u: None}
        queue = [u]
        while queue:
            node = queue.pop(0)
            for neighbor in sorted(self.edges.get(node, {}).keys()):
                if neighbor not in parent:
                    parent[neighbor] = node
                    if neighbor == v:
                        path = []
                        cur = v
                        while cur is not None:
                            path.append(cur)
                            cur = parent[cur]
                        return list(reversed(path))
                    queue.append(neighbor)
        return []

    def shortest_path_length(self, u: str, v: str) -> int:
        path = self.shortest_path(u, v)
        if not path:
            return -1
        return len(path) - 1

    def has_cycle(self) -> bool:
        visited = set()
        for start in sorted(self.vertices.keys()):
            if start in visited:
                continue
            parent = {start: None}
            queue = [start]
            visited.add(start)
            while queue:
                node = queue.pop(0)
                for neighbor in self.edges.get(node, {}).keys():
                    if neighbor not in visited:
                        visited.add(neighbor)
                        parent[neighbor] = node
                        queue.append(neighbor)
                    elif parent[node] != neighbor:
                        return True
        return False

    def cycle_basis(self) -> list[list[str]]:
        result = []
        disc = {}
        par = {}
        timer = [0]
        for start in sorted(self.vertices.keys()):
            if start in disc:
                continue
            par[start] = None
            disc[start] = timer[0]
            timer[0] += 1
            nbrs = sorted(self.edges.get(start, {}).keys())
            stk = [(start, None, nbrs, 0)]
            while stk:
                u, p, nbrs_u, idx = stk[-1]
                if idx < len(nbrs_u):
                    v = nbrs_u[idx]
                    stk[-1] = (u, p, nbrs_u, idx + 1)
                    if v not in disc:
                        par[v] = u
                        disc[v] = timer[0]
                        timer[0] += 1
                        v_nbrs = sorted(self.edges.get(v, {}).keys())
                        stk.append((v, u, v_nbrs, 0))
                    elif v != p and disc[v] < disc[u]:
                        cycle = []
                        node = u
                        while node != v:
                            cycle.append(node)
                            node = par[node]
                        cycle.append(v)
                        result.append(cycle)
                else:
                    stk.pop()
        return result
