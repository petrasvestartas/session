from __future__ import annotations
from collections.abc import Iterator
from typing import Optional
from collections.abc import Sequence
import math
from contextlib import contextmanager


# Mathematical constants
PI = math.pi
TWO_PI = 2 * math.pi
HALF_PI = math.pi / 2
TO_DEGREES = 180.0 / math.pi
TO_RADIANS = math.pi / 180.0

# Scale factor
SCALE = 1e6


class Tolerance:
    """Tolerance settings for geometric operations.

    Parameters
    ----------
    unit : {"M", "MM"}, optional
        The unit of the tolerance settings.
    name : str, optional
        The name of the tolerance settings.
    """

    _instance = None
    _is_inited = False

    SUPPORTED_UNITS = ["M", "MM"]

    # Mathematical constants
    PI = math.pi
    TWO_PI = 2 * math.pi
    HALF_PI = math.pi / 2
    TO_DEGREES = 180.0 / math.pi
    TO_RADIANS = math.pi / 180.0

    # Default tolerance values (f32 only)
    ABSOLUTE = 1e-9
    RELATIVE = 1e-6
    ANGULAR = 1e-6
    APPROXIMATION = 1e-3
    PRECISION = 3
    LINEARDEFLECTION = 1e-3
    ANGULARDEFLECTION = 1e-1
    ANGLE_TOLERANCE_DEGREES = 0.11
    ZERO_TOLERANCE = 1e-12
    ROUNDING = 6

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = object.__new__(cls)
            cls._is_inited = False
        return cls._instance

    def __init__(
        self,
        unit: str = "M",
        absolute: float | None = None,
        relative: float | None = None,
        angular: float | None = None,
        approximation: float | None = None,
        precision: int | None = None,
        lineardeflection: float | None = None,
        angulardeflection: float | None = None,
        name: str | None=None,
    ):
        if not self._is_inited:
            self._unit = None
            self._absolute = None
            self._relative = None
            self._angular = None
            self._approximation = None
            self._precision = None
            self._lineardeflection = None
            self._angulardeflection = None

        self._is_inited = True

        if unit is not None:
            self.unit = unit
        if absolute is not None:
            self.absolute = absolute
        if relative is not None:
            self.relative = relative
        if angular is not None:
            self.angular = angular
        if approximation is not None:
            self.approximation = approximation
        if precision is not None:
            self.precision = precision
        if lineardeflection is not None:
            self.lineardeflection = lineardeflection
        if angulardeflection is not None:
            self.angulardeflection = angulardeflection

    def reset(self) -> None:
        """Reset all precision settings to their default values."""
        self._absolute = None
        self._relative = None
        self._angular = None
        self._approximation = None
        self._precision = None
        self._lineardeflection = None
        self._angulardeflection = None

    @property
    def unit(self) -> str:
        return self._unit or "M"

    @unit.setter
    def unit(self, value: str) -> None:
        if value not in ["M", "MM"]:
            raise ValueError(f"Invalid unit: {value}")
        self._unit = value

    @property
    def units(self) -> str:
        return self._unit or "M"

    @units.setter
    def units(self, value: str) -> None:
        if value not in ["M", "MM"]:
            raise ValueError(f"Invalid unit: {value}")
        self._unit = value

    @property
    def absolute(self) -> float:
        return self._absolute if self._absolute is not None else self.ABSOLUTE

    @absolute.setter
    def absolute(self, value: float) -> None:
        self._absolute = value

    @property
    def relative(self) -> float:
        return self._relative if self._relative is not None else self.RELATIVE

    @relative.setter
    def relative(self, value: float) -> None:
        self._relative = value

    @property
    def angular(self) -> float:
        return self._angular if self._angular is not None else self.ANGULAR

    @angular.setter
    def angular(self, value: float) -> None:
        self._angular = value

    @property
    def approximation(self) -> float:
        return (
            self._approximation
            if self._approximation is not None
            else self.APPROXIMATION
        )

    @approximation.setter
    def approximation(self, value: float) -> None:
        self._approximation = value

    @property
    def precision(self) -> int:
        return self._precision if self._precision is not None else self.PRECISION

    @precision.setter
    def precision(self, value: int) -> None:
        if value == 0:
            raise ValueError("Precision cannot be zero.")
        self._precision = value

    @property
    def lineardeflection(self) -> float:
        return (
            self._lineardeflection
            if self._lineardeflection is not None
            else self.LINEARDEFLECTION
        )

    @lineardeflection.setter
    def lineardeflection(self, value: float) -> None:
        self._lineardeflection = value

    @property
    def angulardeflection(self) -> float:
        return (
            self._angulardeflection
            if self._angulardeflection is not None
            else self.ANGULARDEFLECTION
        )

    @angulardeflection.setter
    def angulardeflection(self, value: float) -> None:
        self._angulardeflection = value

    def tolerance(self, truevalue: float, rtol: float, atol: float) -> float:
        """Compute the tolerance for a comparison."""
        return rtol * abs(truevalue) + atol

    def compare(self, a: float, b: float, rtol: float, atol: float) -> bool:
        """Compare two values."""
        return abs(a - b) <= self.tolerance(b, rtol, atol)

    def is_zero(self, a: float) -> bool:
        """Check if a value is close enough to zero to be considered zero."""
        return abs(a) <= self.absolute

    def is_positive(self, a: float) -> bool:
        """Check if a value can be considered a strictly positive number."""
        return a > self.absolute

    def is_negative(self, a: float) -> bool:
        """Check if a value can be considered a strictly negative number."""
        return a < -self.absolute

    def is_between(self, value: float, minval: float, maxval: float) -> bool:
        """Check if a value is between two other values."""
        atol = self.absolute
        return minval - atol <= value <= maxval + atol

    def is_close(self, a: float, b: float) -> bool:
        """Check if two values are close enough to be considered equal."""
        return self.compare(a, b, self.relative, self.absolute)

    def is_allclose(self, A: Sequence, B: Sequence) -> bool:
        """Check if two lists of values are element-wise close enough to be considered equal."""
        rtol = self.relative
        atol = self.absolute
        return all(
            (
                self.is_allclose(a, b)
                if hasattr(a, "__iter__")
                else self.compare(a, b, rtol, atol)
            )
            for a, b in zip(A, B)
        )

    def is_angle_zero(self, a: float) -> bool:
        """Check if an angle is close enough to zero to be considered zero."""
        return abs(a) <= self.angular

    def is_angles_close(self, a: float, b: float) -> bool:
        """Check if two angles are close enough to be considered equal."""
        return abs(a - b) <= self.angular

    def is_point_close(self, a: Sequence[float], b: Sequence[float]) -> bool:
        """Check if two 3D points are equal within absolute tolerance."""
        dx = b.x - a.x
        dy = b.y - a.y
        dz = b.z - a.z
        return (dx * dx + dy * dy + dz * dz) <= self.absolute * self.absolute

    def is_vector_close(self, a: Sequence[float], b: Sequence[float]) -> bool:
        """Check if two 3D vectors are equal within absolute tolerance."""
        dx = b.x - a.x
        dy = b.y - a.y
        dz = b.z - a.z
        return (dx * dx + dy * dy + dz * dz) <= self.absolute * self.absolute

    def key(self, xyz: Sequence[float], precision: int | None = None, sanitize: bool = True) -> str:
        """Compute the geometric key of a point."""
        x, y, z = xyz
        if not precision:
            precision = self.precision

        if precision == 0:
            raise ValueError("Precision cannot be zero.")

        if precision == -1:
            return f"{int(x)},{int(y)},{int(z)}"

        if precision < -1:
            precision = -precision - 1
            factor = 10**precision
            return f"{int(round(x / factor) * factor)},{int(round(y / factor) * factor)},{int(round(z / factor) * factor)}"

        if sanitize:
            minzero = f"-{0.0:.{precision}f}"
            if f"{x:.{precision}f}" == minzero:
                x = 0.0
            if f"{y:.{precision}f}" == minzero:
                y = 0.0
            if f"{z:.{precision}f}" == minzero:
                z = 0.0

        return f"{x:.{precision}f},{y:.{precision}f},{z:.{precision}f}"

    def key_xy(self, xy: Sequence[float], precision: int | None = None, sanitize: bool = True) -> str:
        """Compute the geometric key of a point in the XY plane."""
        x, y = xy
        if not precision:
            precision = self.precision

        if precision == 0:
            raise ValueError("Precision cannot be zero.")

        if precision == -1:
            return f"{int(x)},{int(y)}"

        if precision < -1:
            precision = -precision - 1
            factor = 10**precision
            return (
                f"{int(round(x / factor) * factor)},{int(round(y / factor) * factor)}"
            )

        if sanitize:
            minzero = f"-{0.0:.{precision}f}"
            if f"{x:.{precision}f}" == minzero:
                x = 0.0
            if f"{y:.{precision}f}" == minzero:
                y = 0.0

        return f"{x:.{precision}f},{y:.{precision}f}"

    def format_number(self, number: float, precision: int | None = None) -> str:
        """Format a number as a string."""
        if not precision:
            precision = self.precision

        if precision == 0:
            raise ValueError("Precision cannot be zero.")

        if precision == -1:
            return f"{int(round(number))}"

        if precision < -1:
            precision = -precision - 1
            factor = 10**precision
            return f"{int(round(number / factor) * factor)}"

        return f"{number:.{precision}f}"

    def precision_from_tolerance(self, tol: float | None = None) -> int:
        """Compute the precision from a given tolerance."""
        tol = tol or self.absolute
        if tol < 1:
            import decimal

            return abs(int(decimal.Decimal(str(tol)).as_tuple().exponent))
        raise NotImplementedError

    @contextmanager
    def temporary(self, **kwargs: float) -> Iterator[None]:
        """Context manager for temporarily changing tolerance settings."""
        saved = {
            "_unit": self._unit,
            "_absolute": self._absolute,
            "_relative": self._relative,
            "_angular": self._angular,
            "_approximation": self._approximation,
            "_precision": self._precision,
            "_lineardeflection": self._lineardeflection,
            "_angulardeflection": self._angulardeflection,
        }
        try:
            for k, v in kwargs.items():
                setattr(self, k, v)
            yield self
        finally:
            for k, v in saved.items():
                setattr(self, k, v)

    @staticmethod
    def to_radians(degrees: float) -> float:
        return degrees * (math.pi / 180.0)

    @staticmethod
    def to_degrees(radians: float) -> float:
        return radians * (180.0 / math.pi)

    @staticmethod
    def round_to(value: float, ndigits: int) -> float:
        factor = 10 ** ndigits
        return round(value * factor) / factor

    def __repr__(self):
        return f"Tolerance(unit='{self.unit}', absolute={self.absolute}, relative={self.relative}, angular={self.angular}, approximation={self.approximation}, precision={self.precision}, lineardeflection={self.lineardeflection}, angulardeflection={self.angulardeflection})"


def is_finite(x: float) -> bool:
    """Test if a number is finite (equivalent to C++ IS_FINITE function)."""
    return math.isfinite(x)


# Global tolerance instance
TOLERANCE = Tolerance()


# ── Math utilities (ported from cgal_math_util) ────────────────────────────

def unique_from_two_int(a: int, b: int) -> int:
    """Cantor-style hash: order-independent key from two ints.

    The larger value goes into the high 32 bits; the smaller into the
    low 32 bits.  Mirrors the C++ / Rust implementations exactly.
    """
    lo, hi = (a, b) if b >= a else (b, a)
    return (hi << 32) | (lo & 0xFFFFFFFF)


def wrap_index(index: int, n: int) -> int:
    """Signed modulo returning a value in [0, n-1].  Returns 0 when n == 0."""
    if n == 0:
        return 0
    return ((index % n) + n) % n


def triangle_edge_by_angle(edge_length: float, angle_deg: float) -> float:
    """Length of the opposite side in a right triangle.

    = edge_length * tan(angle_deg)
    Used in joint taper geometry.
    """
    return edge_length * math.tan(angle_deg * TO_RADIANS)


def rad_to_deg(radians: float) -> float:
    """Convert radians to degrees."""
    return radians * TO_DEGREES


def deg_to_rad(degrees: float) -> float:
    """Convert degrees to radians."""
    return degrees * TO_RADIANS


def count_digits(n: float) -> int:
    """Number of decimal digits of the integer part of |n|.  Returns 0 for n == 0."""
    v = int(abs(n))
    if v == 0:
        return 0
    count = 0
    while v != 0:
        v //= 10
        count += 1
    return count
