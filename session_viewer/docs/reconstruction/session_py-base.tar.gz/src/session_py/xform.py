from __future__ import annotations
from typing import Optional
from typing import TYPE_CHECKING
from typing import Union
import uuid
import math

if TYPE_CHECKING:
    from .point import Point
    from .line import Line
    from pathlib import Path
    from .plane import Plane
    from .polyline import Polyline

from .tolerance import PI
from .vector import Vector


class Xform:

    # ═══════════════════════════════════════════════════════════════════════════
    # Constructors
    # ═══════════════════════════════════════════════════════════════════════════

    def __init__(self, m: list[float] | None = None):
        self._guid = None
        self.name = "my_xform"
        if m is None:
            self.m = [
                1.0,
                0.0,
                0.0,
                0.0,
                0.0,
                1.0,
                0.0,
                0.0,
                0.0,
                0.0,
                1.0,
                0.0,
                0.0,
                0.0,
                0.0,
                1.0,
            ]
        else:
            self.m = list(m)

    def has_guid(self) -> bool:
        return getattr(self, '_guid', None) is not None

    @property
    def guid(self) -> str:
        if getattr(self, '_guid', None) is None:
            self._guid = str(uuid.uuid4())
        return self._guid

    @guid.setter
    def guid(self, value: str) -> None:
        self._guid = value

    def __eq__(self, other):
        if not isinstance(other, Xform):
            return False
        return self.m == other.m

    def __ne__(self, other):
        return not self.__eq__(other)

    def __str__(self):
        """Compact matrix representation as 4x4 rows."""
        # Format as 4 rows for readability
        rows = []
        for i in range(4):
            row_vals = [f"{self.m[i*4 + j]:f}" for j in range(4)]
            rows.append(f"[{', '.join(row_vals)}]")
        return '\n'.join(rows)

    def __repr__(self):
        """Full representation (name, guid prefix)."""
        return f"Xform({self.name}, {self.guid[:8]})"

    def duplicate(self) -> "Xform":
        """Create a copy with a new GUID."""
        copy = Xform(self.m)
        copy.name = self.name
        return copy

    @staticmethod
    def identity() -> "Xform":
        return Xform()

    @staticmethod
    def from_matrix(m: list[float]) -> "Xform":
        return Xform(m)

    # ═══════════════════════════════════════════════════════════════════════════
    # Transformations
    # ═══════════════════════════════════════════════════════════════════════════

    @staticmethod
    def translation(x: float, y: float, z: float) -> "Xform":
        xform = Xform()
        xform.m[12] = x
        xform.m[13] = y
        xform.m[14] = z
        return xform

    @staticmethod
    def rotation_x(angle: float, degrees: bool = False) -> "Xform":
        if degrees:
            angle = angle * (PI / 180.0)
        xform = Xform()
        cos_angle = math.cos(angle)
        sin_angle = math.sin(angle)
        xform.m[5] = cos_angle
        xform.m[6] = sin_angle
        xform.m[9] = -sin_angle
        xform.m[10] = cos_angle
        return xform

    @staticmethod
    def rotation_y(angle: float, degrees: bool = False) -> "Xform":
        if degrees:
            angle = angle * (PI / 180.0)
        xform = Xform()
        cos_angle = math.cos(angle)
        sin_angle = math.sin(angle)
        xform.m[0] = cos_angle
        xform.m[2] = -sin_angle
        xform.m[8] = sin_angle
        xform.m[10] = cos_angle
        return xform

    @staticmethod
    def rotation_z(angle: float, degrees: bool = False) -> "Xform":
        if degrees:
            angle = angle * (PI / 180.0)
        xform = Xform()
        cos_angle = math.cos(angle)
        sin_angle = math.sin(angle)
        xform.m[0] = cos_angle
        xform.m[1] = sin_angle
        xform.m[4] = -sin_angle
        xform.m[5] = cos_angle
        return xform

    @staticmethod
    def rotation(axis: "Vector", angle: float, degrees: bool = False) -> "Xform":
        if degrees:
            angle = angle * (PI / 180.0)
        xform = Xform()
        axis = axis.normalized()
        cos_angle = math.cos(angle)
        sin_angle = math.sin(angle)
        one_minus_cos = 1.0 - cos_angle
        xx = axis[0] * axis[0]
        xy = axis[0] * axis[1]
        xz = axis[0] * axis[2]
        yy = axis[1] * axis[1]
        yz = axis[1] * axis[2]
        zz = axis[2] * axis[2]
        xform.m[0] = cos_angle + xx * one_minus_cos
        xform.m[1] = xy * one_minus_cos + axis[2] * sin_angle
        xform.m[2] = xz * one_minus_cos - axis[1] * sin_angle
        xform.m[4] = xy * one_minus_cos - axis[2] * sin_angle
        xform.m[5] = cos_angle + yy * one_minus_cos
        xform.m[6] = yz * one_minus_cos + axis[0] * sin_angle
        xform.m[8] = xz * one_minus_cos + axis[1] * sin_angle
        xform.m[9] = yz * one_minus_cos - axis[0] * sin_angle
        xform.m[10] = cos_angle + zz * one_minus_cos
        return xform

    @staticmethod
    def rotation_around_line(line: "Line", angle: float, degrees: bool = False) -> "Xform":
        p = line.start()
        d = line.to_direction()
        t0 = Xform.translation(-p[0], -p[1], -p[2])
        r = Xform.rotation(d, angle, degrees)
        t1 = Xform.translation(p[0], p[1], p[2])
        return t1 * (r * t0)

    @staticmethod
    def change_basis(
        origin_1: "Point", x_axis_1: "Vector", y_axis_1: "Vector", z_axis_1: "Vector", origin_0: "Point", x_axis_0: "Vector", y_axis_0: "Vector", z_axis_0: "Vector"
    ) -> "Xform":
        a = x_axis_1.dot(y_axis_1)
        b = x_axis_1.dot(z_axis_1)
        c = y_axis_1.dot(z_axis_1)
        r = [
            [
                x_axis_1.dot(x_axis_1),
                a,
                b,
                x_axis_1.dot(x_axis_0),
                x_axis_1.dot(y_axis_0),
                x_axis_1.dot(z_axis_0),
            ],
            [
                a,
                y_axis_1.dot(y_axis_1),
                c,
                y_axis_1.dot(x_axis_0),
                y_axis_1.dot(y_axis_0),
                y_axis_1.dot(z_axis_0),
            ],
            [
                b,
                c,
                z_axis_1.dot(z_axis_1),
                z_axis_1.dot(x_axis_0),
                z_axis_1.dot(y_axis_0),
                z_axis_1.dot(z_axis_0),
            ],
        ]
        i0 = 0 if r[0][0] >= r[1][1] else 1
        if r[2][2] > r[i0][i0]:
            i0 = 2
        i1 = (i0 + 1) % 3
        i2 = (i1 + 1) % 3
        if r[i0][i0] == 0.0:
            return Xform.identity()
        d = 1.0 / r[i0][i0]
        for j in range(6):
            r[i0][j] *= d
        r[i0][i0] = 1.0
        if r[i1][i0] != 0.0:
            d = -r[i1][i0]
            for j in range(6):
                r[i1][j] += d * r[i0][j]
            r[i1][i0] = 0.0
        if r[i2][i0] != 0.0:
            d = -r[i2][i0]
            for j in range(6):
                r[i2][j] += d * r[i0][j]
            r[i2][i0] = 0.0
        if abs(r[i1][i1]) < abs(r[i2][i2]):
            i1, i2 = i2, i1
        if r[i1][i1] == 0.0:
            return Xform.identity()
        d = 1.0 / r[i1][i1]
        for j in range(6):
            r[i1][j] *= d
        r[i1][i1] = 1.0
        if r[i0][i1] != 0.0:
            d = -r[i0][i1]
            for j in range(6):
                r[i0][j] += d * r[i1][j]
            r[i0][i1] = 0.0
        if r[i2][i1] != 0.0:
            d = -r[i2][i1]
            for j in range(6):
                r[i2][j] += d * r[i1][j]
            r[i2][i1] = 0.0
        if r[i2][i2] == 0.0:
            return Xform.identity()
        d = 1.0 / r[i2][i2]
        for j in range(6):
            r[i2][j] *= d
        r[i2][i2] = 1.0
        if r[i0][i2] != 0.0:
            d = -r[i0][i2]
            for j in range(6):
                r[i0][j] += d * r[i2][j]
            r[i0][i2] = 0.0
        if r[i1][i2] != 0.0:
            d = -r[i1][i2]
            for j in range(6):
                r[i1][j] += d * r[i2][j]
            r[i1][i2] = 0.0
        m_xform = Xform()
        m_xform.m[0] = r[0][3]
        m_xform.m[4] = r[0][4]
        m_xform.m[8] = r[0][5]
        m_xform.m[1] = r[1][3]
        m_xform.m[5] = r[1][4]
        m_xform.m[9] = r[1][5]
        m_xform.m[2] = r[2][3]
        m_xform.m[6] = r[2][4]
        m_xform.m[10] = r[2][5]
        t0 = Xform.translation(-origin_1[0], -origin_1[1], -origin_1[2])
        t2 = Xform.translation(origin_0[0], origin_0[1], origin_0[2])
        return t2 * (m_xform * t0)

    @staticmethod
    def from_axes(col_x: Vector, col_y: Vector, col_z: Vector) -> "Xform":
        """Build a pure rotation (no translation) from three column axis vectors.

        Parameters
        ----------
        col_x, col_y, col_z : :class:`Vector`

        Returns
        -------
        :class:`Xform`
        """
        xf = Xform()
        xf.m[0]  = col_x[0]; xf.m[1]  = col_x[1]; xf.m[2]  = col_x[2]
        xf.m[4]  = col_y[0]; xf.m[5]  = col_y[1]; xf.m[6]  = col_y[2]
        xf.m[8]  = col_z[0]; xf.m[9]  = col_z[1]; xf.m[10] = col_z[2]
        return xf

    @staticmethod
    def from_change_of_basis(rect0: "Polyline", rect1: "Polyline") -> "Xform":
        """Build the change-of-basis xform from two 4-point joint volume rectangles.

        Maps the unit cube ``[-0.5, +0.5]^3`` to the world frame defined by
        the two rectangles. Verbatim port of the inline ``change_basis``
        helper from main_5.cpp:782, which mirrored wood ``wood_joint.cpp:103``.

        Parameters
        ----------
        rect0 : :class:`Polyline`
            4-point quad whose first point is the origin and whose
            ``[1] - [0]`` / ``[3] - [0]`` are the X / Y axes of the target
            frame.
        rect1 : :class:`Polyline`
            Polyline whose first point is the Z anchor (``[0] - rect0[0]``
            is the Z axis of the target frame).

        Returns
        -------
        :class:`Xform`
            Identity if the rectangle is degenerate.
        """
        if rect0.point_count() < 4 or rect1.point_count() < 1:
            return Xform.identity()

        O1x, O1y, O1z = -0.5, -0.5, -0.5
        # X1=(1,0,0), Y1=(0,1,0), Z1=(0,0,1)

        O0 = rect0.get_point(0)
        r01 = rect0.get_point(1)
        r03 = rect0.get_point(3)
        r10 = rect1.get_point(0)
        X0 = Vector(r01[0] - O0[0], r01[1] - O0[1], r01[2] - O0[2])
        Y0 = Vector(r03[0] - O0[0], r03[1] - O0[1], r03[2] - O0[2])
        Z0 = Vector(r10[0] - O0[0], r10[1] - O0[1], r10[2] - O0[2])

        # Augmented matrix [Gram(X1,Y1,Z1) | dot(Xi,X0j)] (X1/Y1/Z1 are
        # orthonormal so the Gram is the identity).
        R = [
            [1.0, 0.0, 0.0, X0[0], Y0[0], Z0[0]],
            [0.0, 1.0, 0.0, X0[1], Y0[1], Z0[1]],
            [0.0, 0.0, 1.0, X0[2], Y0[2], Z0[2]],
        ]

        i0 = 0 if R[0][0] >= R[1][1] else 1
        if R[2][2] > R[i0][i0]:
            i0 = 2
        i1 = (i0 + 1) % 3
        i2 = (i1 + 1) % 3
        if R[i0][i0] == 0.0:
            return Xform.identity()

        def elim(pivot, target):
            if R[target][pivot] == 0.0:
                return
            dd = -R[target][pivot]
            for k in range(6):
                R[target][k] += dd * R[pivot][k]
            R[target][pivot] = 0.0

        def norm_row(row):
            dd = 1.0 / R[row][row]
            for k in range(6):
                R[row][k] *= dd
            R[row][row] = 1.0

        norm_row(i0); elim(i0, i1); elim(i0, i2)
        if abs(R[i1][i1]) < abs(R[i2][i2]):
            i1, i2 = i2, i1
        if R[i1][i1] == 0.0:
            return Xform.identity()
        norm_row(i1); elim(i1, i0); elim(i1, i2)
        if R[i2][i2] == 0.0:
            return Xform.identity()
        norm_row(i2); elim(i2, i0); elim(i2, i1)

        tx = O0[0] - (R[0][3]*O1x + R[0][4]*O1y + R[0][5]*O1z)
        ty = O0[1] - (R[1][3]*O1x + R[1][4]*O1y + R[1][5]*O1z)
        tz = O0[2] - (R[2][3]*O1x + R[2][4]*O1y + R[2][5]*O1z)
        mat = [
            R[0][3], R[1][3], R[2][3], 0.0,
            R[0][4], R[1][4], R[2][4], 0.0,
            R[0][5], R[1][5], R[2][5], 0.0,
            tx,      ty,      tz,      1.0,
        ]
        return Xform(mat)

    @staticmethod
    def plane_to_plane(plane_from: "Plane", plane_to: "Plane") -> "Xform":
        """Create transformation from one plane to another.

        Parameters
        ----------
        plane_from : Plane
            Source plane.
        plane_to : Plane
            Target plane.

        Returns
        -------
        :class:`Xform`
            Transformation matrix.
        """
        x0 = plane_from.x_axis.normalized()
        y0 = plane_from.y_axis.normalized()
        z0 = plane_from.z_axis.normalized()
        x1 = plane_to.x_axis.normalized()
        y1 = plane_to.y_axis.normalized()
        z1 = plane_to.z_axis.normalized()
        origin_0 = plane_from.origin
        origin_1 = plane_to.origin
        t0 = Xform.translation(-origin_0[0], -origin_0[1], -origin_0[2])
        f0 = Xform()
        f0.m[0] = x0[0]
        f0.m[1] = x0[1]
        f0.m[2] = x0[2]
        f0.m[4] = y0[0]
        f0.m[5] = y0[1]
        f0.m[6] = y0[2]
        f0.m[8] = z0[0]
        f0.m[9] = z0[1]
        f0.m[10] = z0[2]
        f1 = Xform()
        f1.m[0] = x1[0]
        f1.m[4] = x1[1]
        f1.m[8] = x1[2]
        f1.m[1] = y1[0]
        f1.m[5] = y1[1]
        f1.m[9] = y1[2]
        f1.m[2] = z1[0]
        f1.m[6] = z1[1]
        f1.m[10] = z1[2]
        r = f1 * f0
        t1 = Xform.translation(origin_1[0], origin_1[1], origin_1[2])
        return t1 * (r * t0)

    @staticmethod
    def plane_to_xy(origin: "Point", x_axis: "Vector", y_axis: "Vector", z_axis: "Vector") -> "Xform":
        x = x_axis.normalized()
        y = y_axis.normalized()
        z = z_axis.normalized()
        t = Xform.translation(-origin[0], -origin[1], -origin[2])
        f = Xform()
        f.m[0] = x[0]
        f.m[1] = x[1]
        f.m[2] = x[2]
        f.m[4] = y[0]
        f.m[5] = y[1]
        f.m[6] = y[2]
        f.m[8] = z[0]
        f.m[9] = z[1]
        f.m[10] = z[2]
        return f * t

    @staticmethod
    def xy_to_plane(origin: "Point", x_axis: "Vector", y_axis: "Vector", z_axis: "Vector") -> "Xform":
        x = x_axis.normalized()
        y = y_axis.normalized()
        z = z_axis.normalized()
        f = Xform()
        f.m[0] = x[0]
        f.m[4] = y[0]
        f.m[8] = z[0]
        f.m[1] = x[1]
        f.m[5] = y[1]
        f.m[9] = z[1]
        f.m[2] = x[2]
        f.m[6] = y[2]
        f.m[10] = z[2]
        t = Xform.translation(origin[0], origin[1], origin[2])
        return t * f

    @staticmethod
    def world_to_frame(origin: "Point", x_axis: "Vector", y_axis: "Vector", z_axis: "Vector") -> "Xform":
        # Correct world→local rotation + translation. Stores basis as matrix
        # ROWS — for world point p the result is f*(p - origin) where f is the
        # rotation whose rows are the unit basis vectors. Unlike plane_to_xy
        # (which stores basis as columns and is actually local-to-world),
        # world_to_frame is a faithful 3D projection — needed when the input
        # geometry's normal aligns with one of the basis axes. See
        # wood_main.cpp type-13 branch.
        x = x_axis.normalized()
        y = y_axis.normalized()
        z = z_axis.normalized()
        f = Xform()
        f.m[0] = x[0]; f.m[4] = x[1]; f.m[8]  = x[2]
        f.m[1] = y[0]; f.m[5] = y[1]; f.m[9]  = y[2]
        f.m[2] = z[0]; f.m[6] = z[1]; f.m[10] = z[2]
        t = Xform.translation(-origin[0], -origin[1], -origin[2])
        return f * t

    @staticmethod
    def frame_to_world(origin: "Point", x_axis: "Vector", y_axis: "Vector", z_axis: "Vector") -> "Xform":
        # Inverse of world_to_frame: local (u, v, w) -> world point at
        # origin + u*x_hat + v*y_hat + w*z_hat. Stores basis as matrix COLUMNS.
        x = x_axis.normalized()
        y = y_axis.normalized()
        z = z_axis.normalized()
        f = Xform()
        f.m[0] = x[0]; f.m[1] = x[1]; f.m[2]  = x[2]
        f.m[4] = y[0]; f.m[5] = y[1]; f.m[6]  = y[2]
        f.m[8] = z[0]; f.m[9] = z[1]; f.m[10] = z[2]
        t = Xform.translation(origin[0], origin[1], origin[2])
        return t * f

    @staticmethod
    def to_frame(frame: "Plane") -> "Xform":
        """Transform from world XY to target frame/plane (same as COMPAS from_frame).

        Parameters
        ----------
        frame : Plane
            Target frame/plane.

        Returns
        -------
        :class:`Xform`
            Transformation matrix.
        """
        x = frame.x_axis.normalized()
        y = frame.y_axis.normalized()
        z = frame.z_axis.normalized()
        o = frame.origin
        xf = Xform()
        xf.m[0] = x[0]; xf.m[4] = y[0]; xf.m[8]  = z[0]; xf.m[12] = o[0]
        xf.m[1] = x[1]; xf.m[5] = y[1]; xf.m[9]  = z[1]; xf.m[13] = o[1]
        xf.m[2] = x[2]; xf.m[6] = y[2]; xf.m[10] = z[2]; xf.m[14] = o[2]
        xf.m[3] = 0.0;  xf.m[7] = 0.0;  xf.m[11] = 0.0;  xf.m[15] = 1.0
        return xf

    @staticmethod
    def scale_xyz(scale_x: float, scale_y: float, scale_z: float) -> "Xform":
        xform = Xform()
        xform.m[0] = scale_x
        xform.m[5] = scale_y
        xform.m[10] = scale_z
        return xform

    @staticmethod
    def scale_uniform(origin: "Point", scale_value: float) -> "Xform":
        t0 = Xform.translation(-origin[0], -origin[1], -origin[2])
        t1 = Xform.scale_xyz(scale_value, scale_value, scale_value)
        t2 = Xform.translation(origin[0], origin[1], origin[2])
        return t2 * (t1 * t0)

    @staticmethod
    def scale_non_uniform(origin: "Point", scale_x: float, scale_y: float, scale_z: float) -> "Xform":
        t0 = Xform.translation(-origin[0], -origin[1], -origin[2])
        t1 = Xform.scale_xyz(scale_x, scale_y, scale_z)
        t2 = Xform.translation(origin[0], origin[1], origin[2])
        return t2 * (t1 * t0)

    @staticmethod
    def axis_rotation(angle: float, axis: "Vector", degrees: bool = False) -> "Xform":
        if degrees:
            angle = angle * (PI / 180.0)
        c = math.cos(angle)
        s = math.sin(angle)
        ux = axis[0]
        uy = axis[1]
        uz = axis[2]
        t = 1.0 - c
        xform = Xform()
        xform.m[0] = t * ux * ux + c
        xform.m[4] = t * ux * uy - uz * s
        xform.m[8] = t * ux * uz + uy * s
        xform.m[1] = t * ux * uy + uz * s
        xform.m[5] = t * uy * uy + c
        xform.m[9] = t * uy * uz - ux * s
        xform.m[2] = t * ux * uz - uy * s
        xform.m[6] = t * uy * uz + ux * s
        xform.m[10] = t * uz * uz + c
        return xform

    @staticmethod
    def look_at_right_handed(eye: "Point", target: "Point", up: "Vector") -> "Xform":
        from .vector import Vector

        f = (target - eye).normalized()
        s = f.cross(up.normalized()).normalized()
        u = s.cross(f)
        xform = Xform()
        xform.m[0] = s[0]
        xform.m[4] = s[1]
        xform.m[8] = s[2]
        xform.m[1] = u[0]
        xform.m[5] = u[1]
        xform.m[9] = u[2]
        xform.m[2] = -f[0]
        xform.m[6] = -f[1]
        xform.m[10] = -f[2]
        eye_vec = Vector(eye[0], eye[1], eye[2])
        xform.m[12] = -s.dot(eye_vec)
        xform.m[13] = -u.dot(eye_vec)
        xform.m[14] = f.dot(eye_vec)
        return xform

    @staticmethod
    def look_to_right_handed(eye: "Point", direction: "Vector", up: "Vector") -> "Xform":
        from .vector import Vector

        f = direction.normalized()
        s = f.cross(up.normalized()).normalized()
        u = s.cross(f)
        xform = Xform()
        xform.m[0] = s[0]
        xform.m[4] = s[1]
        xform.m[8] = s[2]
        xform.m[1] = u[0]
        xform.m[5] = u[1]
        xform.m[9] = u[2]
        xform.m[2] = -f[0]
        xform.m[6] = -f[1]
        xform.m[10] = -f[2]
        eye_vec = Vector(eye[0], eye[1], eye[2])
        xform.m[12] = -s.dot(eye_vec)
        xform.m[13] = -u.dot(eye_vec)
        xform.m[14] = f.dot(eye_vec)
        return xform

    @staticmethod
    def perspective(fov_y: float, aspect: float, near: float, far: float) -> "Xform":
        f = 1.0 / math.tan(fov_y / 2.0)
        nf = near - far
        xform = Xform([0.0] * 16)
        xform.m[0] = f / aspect
        xform.m[5] = f
        xform.m[10] = far / nf
        xform.m[11] = -1.0
        xform.m[14] = (near * far) / nf
        return xform

    @staticmethod
    def orthographic(left: float, right: float, bottom: float, top: float, near: float, far: float) -> "Xform":
        rl = right - left
        tb = top - bottom
        nf = near - far
        xform = Xform([0.0] * 16)
        xform.m[0] = 2.0 / rl
        xform.m[5] = 2.0 / tb
        xform.m[10] = 1.0 / nf
        xform.m[12] = (left + right) / (left - right)
        xform.m[13] = (bottom + top) / (bottom - top)
        xform.m[14] = near / nf
        xform.m[15] = 1.0
        return xform

    @staticmethod
    def project_to_plane(plane: "Plane") -> "Xform":
        n = plane.z_axis
        o = plane.origin
        nx, ny, nz = n[0], n[1], n[2]
        d = o[0] * nx + o[1] * ny + o[2] * nz
        xform = Xform()
        xform.m[0]  = 1.0 - nx * nx;  xform.m[4]  = -nx * ny;        xform.m[8]  = -nx * nz;        xform.m[12] = nx * d
        xform.m[1]  = -ny * nx;       xform.m[5]  = 1.0 - ny * ny;   xform.m[9]  = -ny * nz;        xform.m[13] = ny * d
        xform.m[2]  = -nz * nx;       xform.m[6]  = -nz * ny;        xform.m[10] = 1.0 - nz * nz;   xform.m[14] = nz * d
        xform.m[3]  = 0.0;            xform.m[7]  = 0.0;             xform.m[11] = 0.0;              xform.m[15] = 1.0
        return xform

    @staticmethod
    def project_to_plane_by_axis(plane: "Plane", direction: "Vector") -> "Xform":
        n = plane.z_axis
        o = plane.origin
        nx, ny, nz = n[0], n[1], n[2]
        dx, dy, dz = direction[0], direction[1], direction[2]
        dot_nd = nx * dx + ny * dy + nz * dz
        s = 1.0 / dot_nd
        d = o[0] * nx + o[1] * ny + o[2] * nz
        xform = Xform()
        xform.m[0]  = 1.0 - dx*s*nx;  xform.m[4]  = -dx*s*ny;        xform.m[8]  = -dx*s*nz;        xform.m[12] = dx*s*d
        xform.m[1]  = -dy*s*nx;       xform.m[5]  = 1.0 - dy*s*ny;   xform.m[9]  = -dy*s*nz;        xform.m[13] = dy*s*d
        xform.m[2]  = -dz*s*nx;       xform.m[6]  = -dz*s*ny;        xform.m[10] = 1.0 - dz*s*nz;   xform.m[14] = dz*s*d
        xform.m[3]  = 0.0;            xform.m[7]  = 0.0;             xform.m[11] = 0.0;              xform.m[15] = 1.0
        return xform

    # ═══════════════════════════════════════════════════════════════════════════
    # Apply Transformations
    # ═══════════════════════════════════════════════════════════════════════════

    def transform_point(self, p: "Point") -> "Point":
        x = self.m[0] * p[0] + self.m[4] * p[1] + self.m[8] * p[2] + self.m[12]
        y = self.m[1] * p[0] + self.m[5] * p[1] + self.m[9] * p[2] + self.m[13]
        z = self.m[2] * p[0] + self.m[6] * p[1] + self.m[10] * p[2] + self.m[14]
        w = self.m[3] * p[0] + self.m[7] * p[1] + self.m[11] * p[2] + self.m[15]
        from .point import Point
        if abs(w) < 1e-12:
            return Point(x, y, z)
        return Point(x / w, y / w, z / w)

    def transform_vector(self, v: "Vector") -> "Vector":
        x = self.m[0] * v[0] + self.m[4] * v[1] + self.m[8] * v[2]
        y = self.m[1] * v[0] + self.m[5] * v[1] + self.m[9] * v[2]
        z = self.m[2] * v[0] + self.m[6] * v[1] + self.m[10] * v[2]
        return Vector(x, y, z)

    # ═══════════════════════════════════════════════════════════════════════════
    # Details
    # ═══════════════════════════════════════════════════════════════════════════

    def inverse(self) -> Optional["Xform"]:
        s0 = self.m[0] * self.m[5] - self.m[1] * self.m[4]
        s1 = self.m[0] * self.m[9] - self.m[1] * self.m[8]
        s2 = self.m[0] * self.m[13] - self.m[1] * self.m[12]
        s3 = self.m[4] * self.m[9] - self.m[5] * self.m[8]
        s4 = self.m[4] * self.m[13] - self.m[5] * self.m[12]
        s5 = self.m[8] * self.m[13] - self.m[9] * self.m[12]
        c5 = self.m[10] * self.m[15] - self.m[11] * self.m[14]
        c4 = self.m[6] * self.m[15] - self.m[7] * self.m[14]
        c3 = self.m[6] * self.m[11] - self.m[7] * self.m[10]
        c2 = self.m[2] * self.m[15] - self.m[3] * self.m[14]
        c1 = self.m[2] * self.m[11] - self.m[3] * self.m[10]
        c0 = self.m[2] * self.m[7] - self.m[3] * self.m[6]
        det = s0 * c5 - s1 * c4 + s2 * c3 + s3 * c2 - s4 * c1 + s5 * c0
        if abs(det) < 1e-12:
            return None
        inv_det = 1.0 / det
        res = Xform()
        res.guid = ""
        res.name = ""
        res.m[0] = (self.m[5] * c5 - self.m[9] * c4 + self.m[13] * c3) * inv_det
        res.m[4] = (-self.m[4] * c5 + self.m[8] * c4 - self.m[12] * c3) * inv_det
        res.m[8] = (self.m[7] * s5 - self.m[11] * s4 + self.m[15] * s3) * inv_det
        res.m[12] = (-self.m[6] * s5 + self.m[10] * s4 - self.m[14] * s3) * inv_det
        res.m[1] = (-self.m[1] * c5 + self.m[9] * c2 - self.m[13] * c1) * inv_det
        res.m[5] = (self.m[0] * c5 - self.m[8] * c2 + self.m[12] * c1) * inv_det
        res.m[9] = (-self.m[3] * s5 + self.m[11] * s2 - self.m[15] * s1) * inv_det
        res.m[13] = (self.m[2] * s5 - self.m[10] * s2 + self.m[14] * s1) * inv_det
        res.m[2] = (self.m[1] * c4 - self.m[5] * c2 + self.m[13] * c0) * inv_det
        res.m[6] = (-self.m[0] * c4 + self.m[4] * c2 - self.m[12] * c0) * inv_det
        res.m[10] = (self.m[3] * s4 - self.m[7] * s2 + self.m[15] * s0) * inv_det
        res.m[14] = (-self.m[2] * s4 + self.m[6] * s2 - self.m[14] * s0) * inv_det
        res.m[3] = (-self.m[1] * c3 + self.m[5] * c1 - self.m[9] * c0) * inv_det
        res.m[7] = (self.m[0] * c3 - self.m[4] * c1 + self.m[8] * c0) * inv_det
        res.m[11] = (-self.m[3] * s3 + self.m[7] * s1 - self.m[11] * s0) * inv_det
        res.m[15] = (self.m[2] * s3 - self.m[6] * s1 + self.m[10] * s0) * inv_det
        return res

    def is_identity(self) -> bool:
        identity = Xform.identity()
        for i in range(16):
            if abs(self.m[i] - identity.m[i]) > 1e-10:
                return False
        return True

    def to_cols(self) -> list[list[float]]:
        return [
            [self.m[0],  self.m[1],  self.m[2],  self.m[3] ],
            [self.m[4],  self.m[5],  self.m[6],  self.m[7] ],
            [self.m[8],  self.m[9],  self.m[10], self.m[11]],
            [self.m[12], self.m[13], self.m[14], self.m[15]],
        ]

    # ═══════════════════════════════════════════════════════════════════════════
    # Operators
    # ═══════════════════════════════════════════════════════════════════════════

    def __mul__(self, other):
        result = Xform()
        result.m = [0.0] * 16
        for i in range(4):
            for j in range(4):
                sum_val = 0.0
                for k in range(4):
                    sum_val += self.m[k * 4 + i] * other.m[j * 4 + k]
                result.m[j * 4 + i] = sum_val
        return result

    def __imul__(self, other):
        temp = self * other
        self.m = temp.m
        return self

    def __getitem__(self, idx):
        if isinstance(idx, tuple) and len(idx) == 2:
            row, col = idx
            if not (0 <= row < 4 and 0 <= col < 4):
                raise IndexError(f"Index out of bounds: ({row}, {col})")
            return self.m[col * 4 + row]
        raise TypeError("Index must be a tuple of (row, col)")

    def __setitem__(self, idx, value):
        if isinstance(idx, tuple) and len(idx) == 2:
            row, col = idx
            if not (0 <= row < 4 and 0 <= col < 4):
                raise IndexError(f"Index out of bounds: ({row}, {col})")
            self.m[col * 4 + row] = value
        else:
            raise TypeError("Index must be a tuple of (row, col)")

    # ═══════════════════════════════════════════════════════════════════════════
    # JSON
    # ═══════════════════════════════════════════════════════════════════════════

    def __jsondump__(self):
        """Serialize to polymorphic JSON format with type field.

        Returns
        -------
        dict
            Dictionary with 'type', 'guid', 'name', and object fields.

        """
        # Alphabetical order to match Rust's serde_json
        return {
            "guid": self.guid,
            "m": self.m,
            "name": self.name,
            "type": f"{self.__class__.__name__}",
        }

    @classmethod
    def __jsonload__(cls, data, guid=None, name=None):
        """Deserialize from polymorphic JSON format.

        Parameters
        ----------
        data : dict
            Dictionary containing xform data.
        guid : str, optional
            GUID for the xform.
        name : str, optional
            Name for the xform.

        Returns
        -------
        :class:`Xform`
            Reconstructed xform instance.

        """
        xform = cls.from_matrix(data["m"])
        xform.guid = guid
        xform.name = name
        return xform

    def file_json_dump(self, filepath: Union[str, "Path"]) -> None:
        """Write JSON to file.

        Parameters
        ----------
        filepath : str or Path
            Path to the output file.

        """
        import json
        with open(filepath, 'w') as f:
            json.dump(self.__jsondump__(), f, indent=2)

    @classmethod
    def file_json_load(cls, filepath: Union[str, "Path"]) -> "Xform":
        """Read JSON from file.

        Parameters
        ----------
        filepath : str or Path
            Path to the JSON file.

        Returns
        -------
        :class:`Xform`
            The deserialized Xform.

        """
        import json
        with open(filepath) as f:
            data = json.load(f)
        return cls.__jsonload__(data, data.get("guid"), data.get("name"))

    def file_json_dumps(self) -> str:
        """Convert to JSON string."""
        import json
        return json.dumps(self.__jsondump__())

    @classmethod
    def file_json_loads(cls, json_string: str) -> "Xform":
        """Load from JSON string."""
        import json
        return cls.__jsonload__(json.loads(json_string))

    # ═══════════════════════════════════════════════════════════════════════════
    # Protobuf
    # ═══════════════════════════════════════════════════════════════════════════

    def pb_dumps(self) -> bytes:
        """Convert to protobuf binary format.

        Returns
        -------
        bytes
            Serialized protobuf data.

        """
        from .proto import xform_pb2

        proto = xform_pb2.Xform()
        if self.has_guid():
            proto.guid = self._guid
        proto.name = self.name
        proto.matrix.extend(self.m)
        return proto.SerializeToString()

    @classmethod
    def pb_loads(cls, data: bytes) -> "Xform":
        """Create Xform from protobuf binary data.

        Parameters
        ----------
        data : bytes
            Protobuf-encoded xform data.

        Returns
        -------
        :class:`Xform`
            The deserialized Xform.

        """
        from .proto import xform_pb2

        proto = xform_pb2.Xform()
        proto.ParseFromString(data)
        xform = cls.from_matrix(list(proto.matrix))
        if proto.guid:
            xform.guid = proto.guid
        xform.name = proto.name
        return xform

    def pb_dump(self, filepath: Union[str, "Path"]) -> None:
        """Write protobuf to file.

        Parameters
        ----------
        filepath : str
            Path to the output file.

        """
        data = self.pb_dumps()
        with open(filepath, 'wb') as f:
            f.write(data)

    @classmethod
    def pb_load(cls, filepath: Union[str, "Path"]) -> "Xform":
        """Read protobuf from file.

        Parameters
        ----------
        filepath : str
            Path to the protobuf file.

        Returns
        -------
        :class:`Xform`
            The deserialized Xform.

        """
        with open(filepath, 'rb') as f:
            data = f.read()
        return cls.pb_loads(data)
