from .mini_test import MINI_TEST
from .mini_test import MINI_CHECK
from .mini_test import run_all
from .tolerance import TOLERANCE
import os
from pathlib import Path


@MINI_TEST("FileObj", "Read Bunny")
def test_read_bunny():
    from session_py import read_file_obj

    bunny_path = Path(__file__).resolve().parents[3] / "session_data" / "bunny.obj"

    if not bunny_path.exists():
        return

    mesh = read_file_obj(str(bunny_path))

    MINI_CHECK(mesh.number_of_vertices() == 2503)
    MINI_CHECK(mesh.number_of_faces() == 4968)
    vertices, faces = mesh.to_vertices_and_faces()
    MINI_CHECK(len(vertices) == 2503)
    MINI_CHECK(len(faces) == 4968)
    has_non_zero = False

    for v in vertices:
        if v[0] != 0.0 or v[1] != 0.0 or v[2] != 0.0:
            has_non_zero = True

    MINI_CHECK(has_non_zero)
    all_polygons = True

    for f in faces:
        if len(f) < 3:
            all_polygons = False

    MINI_CHECK(all_polygons)


@MINI_TEST("FileObj", "Write Read Roundtrip")
def test_write_read_roundtrip():
    from session_py import Mesh
    from session_py import Point
    from session_py import read_file_obj
    from session_py import write_file_obj

    os.makedirs(Path(__file__).resolve().parents[2] / "serialization", exist_ok=True)
    original_mesh = Mesh()
    v0 = original_mesh.add_vertex(Point(0.0, 0.0, 0.0))
    v1 = original_mesh.add_vertex(Point(1.0, 0.0, 0.0))
    v2 = original_mesh.add_vertex(Point(0.0, 1.0, 0.0))
    v3 = original_mesh.add_vertex(Point(0.0, 0.0, 1.0))
    original_mesh.add_face([v0, v1, v2])
    original_mesh.add_face([v0, v1, v3])

    MINI_CHECK(original_mesh.number_of_vertices() == 4)
    MINI_CHECK(original_mesh.number_of_faces() == 2)
    temp_file = str(
        Path(__file__).resolve().parents[2]
        / "serialization"
        / "test_temp_roundtrip.obj"
    )
    write_file_obj(original_mesh, temp_file)
    MINI_CHECK(os.path.exists(temp_file))
    loaded_mesh = read_file_obj(temp_file)
    MINI_CHECK(loaded_mesh.number_of_vertices() == original_mesh.number_of_vertices())
    MINI_CHECK(loaded_mesh.number_of_faces() == original_mesh.number_of_faces())
    os.remove(temp_file)


@MINI_TEST("FileObj", "String Roundtrip")
def test_string_roundtrip():
    from session_py import Mesh
    from session_py import Point
    from session_py import read_file_obj_from_str
    from session_py import write_file_obj_to_string

    original_mesh = Mesh()
    v0 = original_mesh.add_vertex(Point(0.0, 0.0, 0.0))
    v1 = original_mesh.add_vertex(Point(1.0, 0.0, 0.0))
    v2 = original_mesh.add_vertex(Point(0.0, 1.0, 0.0))
    v3 = original_mesh.add_vertex(Point(0.0, 0.0, 1.0))
    original_mesh.add_face([v0, v1, v2])
    original_mesh.add_face([v0, v1, v3])
    s = write_file_obj_to_string(original_mesh)
    loaded_mesh = read_file_obj_from_str(s)

    MINI_CHECK(loaded_mesh.number_of_vertices() == original_mesh.number_of_vertices())
    MINI_CHECK(loaded_mesh.number_of_faces() == original_mesh.number_of_faces())
    MINI_CHECK(TOLERANCE.is_close(loaded_mesh.area(), original_mesh.area()))


if __name__ == "__main__":
    run_all("python")
