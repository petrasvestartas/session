use crate::mini_test::TestResult;
use crate::{MINI_CHECK, MINI_TEST, REGISTER_MINI_TEST};

pub fn run_rtree_constructor() -> TestResult {
    MINI_TEST!("Constructor", {
        use crate::SpatialRTree;
        let mut t = SpatialRTree::new();
        t.insert([0.0, 0.0, 0.0], [1.0, 1.0, 1.0], 0);
        t.insert([5.0, 0.0, 0.0], [6.0, 1.0, 1.0], 1);
        t.insert([10.0, 0.0, 0.0], [11.0, 1.0, 1.0], 2);
        let mut found: i32 = -1;
        t.search([0.0, 0.0, 0.0], [1.0, 1.0, 1.0], |id| {
            found = id;
            true
        });

        MINI_CHECK!(found == 0);
    })
}

pub fn run_rtree_creation() -> TestResult {
    MINI_TEST!("Creation", {
        use crate::SpatialRTree;
        let t = SpatialRTree::default();

        MINI_CHECK!(t.count() == 0);
    })
}

pub fn run_rtree_insert() -> TestResult {
    MINI_TEST!("Insert", {
        use crate::SpatialRTree;
        let mut t = SpatialRTree::new();
        t.insert([0.0, 0.0, 0.0], [1.0, 1.0, 1.0], 42);

        MINI_CHECK!(t.count() == 1);
    })
}

pub fn run_rtree_insert_multiple() -> TestResult {
    MINI_TEST!("Insert Multiple", {
        use crate::SpatialRTree;
        let mut t = SpatialRTree::new();
        t.insert([0.0, 0.0, 0.0], [1.0, 1.0, 1.0], 0);
        t.insert([2.0, 2.0, 2.0], [3.0, 3.0, 3.0], 1);
        t.insert([4.0, 4.0, 4.0], [5.0, 5.0, 5.0], 2);

        MINI_CHECK!(t.count() == 3);
    })
}

pub fn run_rtree_search_hit() -> TestResult {
    MINI_TEST!("Search Hit", {
        use crate::SpatialRTree;
        let mut t = SpatialRTree::new();
        t.insert([0.0, 0.0, 0.0], [2.0, 2.0, 2.0], 0);
        let mut found: i32 = -1;
        let hits = t.search([1.0, 1.0, 1.0], [3.0, 3.0, 3.0], |data| {
            found = data;
            true
        });

        MINI_CHECK!(hits == 1);
        MINI_CHECK!(found == 0);
    })
}

pub fn run_rtree_search_miss() -> TestResult {
    MINI_TEST!("Search Miss", {
        use crate::SpatialRTree;
        let mut t = SpatialRTree::new();
        t.insert([0.0, 0.0, 0.0], [1.0, 1.0, 1.0], 7);
        let hits = t.search([2.0, 2.0, 2.0], [3.0, 3.0, 3.0], |_| true);

        MINI_CHECK!(hits == 0);
    })
}

pub fn run_rtree_remove() -> TestResult {
    MINI_TEST!("Remove", {
        use crate::SpatialRTree;
        let mut t = SpatialRTree::new();
        t.insert([0.0, 0.0, 0.0], [1.0, 1.0, 1.0], 5);
        t.remove([0.0, 0.0, 0.0], [1.0, 1.0, 1.0], 5);

        MINI_CHECK!(t.count() == 0);
    })
}

pub fn run_rtree_remove_all() -> TestResult {
    MINI_TEST!("Remove All", {
        use crate::SpatialRTree;
        let mut t = SpatialRTree::new();
        t.insert([0.0, 0.0, 0.0], [1.0, 1.0, 1.0], 0);
        t.insert([2.0, 2.0, 2.0], [3.0, 3.0, 3.0], 1);
        t.insert([4.0, 4.0, 4.0], [5.0, 5.0, 5.0], 2);
        t.remove_all();

        MINI_CHECK!(t.count() == 0);
    })
}

pub fn run_rtree_search_count() -> TestResult {
    MINI_TEST!("Search Count", {
        use crate::SpatialRTree;
        let mut t = SpatialRTree::new();
        t.insert([0.0, 0.0, 0.0], [1.0, 1.0, 1.0], 0);
        t.insert([2.0, 2.0, 2.0], [3.0, 3.0, 3.0], 1);
        t.insert([3.0, 3.0, 3.0], [4.0, 4.0, 4.0], 2);
        t.insert([10.0, 0.0, 0.0], [11.0, 1.0, 1.0], 3);
        t.insert([0.0, 10.0, 0.0], [1.0, 11.0, 1.0], 4);
        let hits = t.search([0.0, 0.0, 0.0], [4.0, 4.0, 4.0], |_| true);

        MINI_CHECK!(hits == 3);
    })
}

pub fn run_rtree_search_stop() -> TestResult {
    MINI_TEST!("Search Stop", {
        use crate::SpatialRTree;
        let mut t = SpatialRTree::new();
        t.insert([0.0, 0.0, 0.0], [1.0, 1.0, 1.0], 0);
        t.insert([0.0, 0.0, 0.0], [1.0, 1.0, 1.0], 1);
        t.insert([0.0, 0.0, 0.0], [1.0, 1.0, 1.0], 2);
        let hits = t.search([0.0, 0.0, 0.0], [1.0, 1.0, 1.0], |_| false);

        MINI_CHECK!(hits == 1);
    })
}

pub fn run_rtree_normalizes_reversed_bounds() -> TestResult {
    MINI_TEST!("Normalizes Reversed Bounds", {
        use crate::SpatialRTree;
        let mut t = SpatialRTree::new();
        t.insert([1.0, 2.0, 3.0], [-1.0, -2.0, -3.0], 9);
        let mut found = Vec::new();
        let hits = t.search([2.0, 3.0, 4.0], [-2.0, -3.0, -4.0], |data| {
            found.push(data);
            true
        });

        MINI_CHECK!(hits == 1);
        MINI_CHECK!(found == vec![9]);
        MINI_CHECK!(t.remove([2.0, 3.0, 4.0], [-2.0, -3.0, -4.0], 9));
        MINI_CHECK!(t.count() == 0);
    })
}

pub fn run_rtree_search_100_boxes() -> TestResult {
    MINI_TEST!("Search 100 Boxes", {
        use crate::SpatialRTree;
        let mut t = SpatialRTree::new();
        let mut id: i32 = 0;
        let mut add = |x0: f64, y0: f64, z0: f64, x1: f64, y1: f64, z1: f64| {
            t.insert([x0, y0, z0], [x1, y1, z1], id);
            id += 1;
        };
        add(-53.1254, -0.98185, 20.5516, -46.8089, 5.89927, 26.5331);
        add(44.4446, -1.5359, -1.49382, 50.7301, 3.99953, 7.58362);
        add(36.9359, -7.76782, -28.7694, 43.173, -1.82645, -22.1528);
        add(-44.2654, 26.3949, 0.745263, -35.0431, 35.0799, 6.13693);
        add(0.239448, -40.5791, 32.6275, 7.56243, -33.2192, 39.8776);
        add(-31.6363, -53.5568, -52.162, -21.6687, -43.9796, -43.2328);
        add(3.72143, 23.485, 9.18924, 10.4425, 30.3631, 15.5248);
        add(-17.4583, 10.2729, -16.5162, -12.1943, 17.9162, -10.7277);
        add(-7.27998, -22.0384, -34.5872, -1.95631, -12.1058, -26.8567);
        add(-45.341, 46.3634, -10.4862, -36.8332, 52.2971, -2.76774);
        add(46.0445, -34.6013, 14.0587, 53.0414, -27.4064, 22.7938);
        add(-34.9367, 28.5039, 27.7749, -29.4494, 33.6524, 33.4448);
        add(9.97675, -15.7696, -27.8198, 17.5104, -8.16385, -22.3021);
        add(45.1965, -19.307, 22.0449, 51.5233, -10.9748, 31.6205);
        add(-7.03031, -10.8607, 38.8429, 0.306212, -0.974567, 45.443);
        add(25.5248, 31.9848, 20.436, 33.3122, 41.1186, 28.0921);
        add(-22.8772, -19.5722, -22.9988, -15.6443, -11.7384, -14.7361);
        add(-46.2318, -5.27625, -7.84674, -41.1843, 3.22896, -0.905452);
        add(-8.8814, 40.3852, -41.0122, -1.73994, 46.8478, -33.9574);
        add(-30.4719, -15.9782, 17.3287, -20.7941, -10.8891, 24.7185);
        add(28.6586, 0.44821, -41.9327, 35.6602, 6.09223, -32.8706);
        add(-14.173, -45.5086, 6.29666, -7.48969, -39.2406, 13.229);
        add(-21.8039, 6.68129, -32.5692, -15.3816, 16.6269, -26.5873);
        add(13.3659, -1.97758, 25.4002, 19.0017, 4.81311, 31.5121);
        add(-24.433, -37.1532, 41.849, -15.8042, -29.2066, 49.4371);
        add(-4.54629, -16.9216, -24.2439, 2.40272, -9.87919, -17.0974);
        add(-22.1316, -18.2577, -41.6624, -13.4863, -11.2109, -36.6118);
        add(-19.5562, -1.13082, -35.7364, -10.2048, 8.43363, -25.912);
        add(26.4514, -31.3635, -3.53901, 32.4376, -22.007, 5.52268);
        add(44.2805, -20.3072, 10.0337, 52.6535, -10.845, 15.6482);
        add(15.1756, 46.2379, 44.9662, 20.8272, 53.0835, 50.1683);
        add(1.39766, -37.0106, -2.59787, 7.17823, -28.0455, 3.65286);
        add(-31.882, -21.1354, 20.6053, -24.8106, -11.3482, 28.4804);
        add(-8.54435, 10.0787, 41.0063, -1.08096, 17.3793, 46.4334);
        add(21.317, -38.2325, 3.71512, 29.3482, -31.5114, 10.6611);
        add(-31.9136, 27.8033, -4.48008, -23.6666, 35.3487, 0.804813);
        add(8.52067, 14.4157, -37.4169, 17.5301, 20.4823, -32.1696);
        add(-7.88355, 21.208, 42.2586, -0.205483, 26.4206, 50.4889);
        add(-15.322, -4.75221, -17.9083, -8.4181, 4.47693, -8.67731);
        add(37.1268, 2.17059, -48.8049, 45.7917, 8.4744, -40.7264);
        add(-52.3809, -6.49423, 8.92399, -42.9845, 0.188961, 18.343);
        add(41.5732, -7.42366, -4.54156, 51.0067, -2.29871, 0.643029);
        add(-5.78252, 0.645065, -13.4131, 1.93946, 8.96885, -5.49512);
        add(7.58556, -41.9641, 23.8841, 16.6142, -32.1089, 31.049);
        add(-46.102, -9.30967, 44.8527, -36.2572, -2.2869, 51.5056);
        add(45.8031, 27.0115, -17.4386, 52.3382, 32.367, -7.79126);
        add(8.21008, 39.3673, 20.643, 17.4628, 45.1004, 28.0194);
        add(-47.9111, -24.7374, -29.2773, -40.7686, -16.0819, -20.6671);
        add(-29.8193, -10.8358, 24.5871, -21.6958, -3.36907, 33.5925);
        add(26.9713, -26.2038, -31.9261, 35.2619, -20.0422, -25.0245);
        add(-29.7903, 8.92347, -40.826, -21.7701, 15.776, -35.2006);
        add(-1.39845, -13.7028, -13.4383, 8.26331, -8.56298, -7.95241);
        add(-27.3862, 17.0337, 30.1216, -19.7585, 22.0732, 39.076);
        add(-15.102, -39.6467, -37.4648, -8.16651, -34.4574, -31.1032);
        add(14.1428, -34.4961, -47.6358, 22.6478, -25.6985, -42.1577);
        add(32.7187, -0.0187469, -2.54834, 41.5605, 9.91946, 3.89622);
        add(18.869, -24.3319, -0.588445, 27.1926, -18.2572, 6.42131);
        add(4.33372, 6.78191, -26.4923, 12.7318, 13.5283, -19.058);
        add(-3.88995, -20.8689, 18.4182, 4.99471, -11.484, 25.6025);
        add(-10.2896, -22.7252, -40.4815, -3.08794, -13.9661, -30.6919);
        add(30.2898, 7.94805, -2.19314, 35.3154, 17.6367, 5.55489);
        add(-33.8415, 21.4915, -16.5747, -26.6066, 27.2365, -10.8669);
        add(-22.4042, 38.4298, 21.7984, -13.9447, 47.0733, 28.4925);
        add(-6.87762, 2.83366, 10.2831, -0.784998, 11.5311, 18.5943);
        add(-34.4398, -36.757, 27.0559, -27.6572, -27.51, 36.7491);
        add(35.4006, -17.8502, -21.4524, 41.7323, -10.0449, -12.5719);
        add(28.1073, 31.8896, -16.4485, 33.4307, 37.9012, -9.80763);
        add(13.5936, 25.9705, 8.3269, 22.4543, 32.3162, 16.4279);
        add(28.2281, -51.9913, -14.7078, 35.0256, -42.5897, -6.77297);
        add(-27.4511, -21.3243, 42.9791, -18.7936, -14.3339, 50.3538);
        add(-42.0679, -47.6033, -33.2027, -32.8703, -38.8405, -26.6373);
        add(-52.2085, -52.5573, -33.0963, -45.8755, -44.5128, -23.5496);
        add(-11.2779, -9.99167, 24.9689, -5.92983, -0.191222, 31.1336);
        add(33.121, 2.70727, -33.8816, 38.3024, 10.367, -26.2656);
        add(-5.30061, -39.8595, 33.6105, 4.23731, -31.0826, 42.5769);
        add(-0.704829, -26.0593, -30.9797, 4.64116, -16.105, -24.9783);
        add(37.3045, 34.9896, 2.13491, 46.4151, 40.7296, 10.6969);
        add(-27.6823, 41.9125, -36.4809, -17.7935, 47.2728, -26.7252);
        add(34.666, 27.0233, 23.9605, 44.5308, 33.3, 30.9151);
        add(-37.3694, -40.3928, -6.27422, -28.0124, -31.5777, -0.670845);
        add(-34.1601, 33.6584, -28.8227, -27.286, 42.4497, -22.2408);
        add(-30.329, -4.34317, -43.1085, -23.815, 5.64745, -35.7657);
        add(-31.824, 8.78623, 25.1597, -24.1868, 17.2063, 31.7098);
        add(8.9247, -12.5921, 35.2262, 16.9325, -5.38381, 44.3014);
        add(-11.6258, 44.3936, -29.2716, -3.07673, 49.3977, -20.2529);
        add(-27.9412, 32.9874, -20.8262, -22.5216, 39.9326, -12.0579);
        add(39.7539, -22.0106, 31.131, 46.0297, -14.2677, 40.1578);
        add(-10.4385, 20.3835, 5.16852, -5.23064, 28.6092, 14.2703);
        add(19.9106, -32.364, 8.76233, 25.9003, -24.1348, 16.1047);
        add(-0.62887, 18.0559, 41.0991, 5.37937, 23.5869, 49.7166);
        add(20.6713, -12.7322, -19.7395, 28.0693, -3.71518, -11.0217);
        add(42.2797, -30.3842, 8.4357, 51.5113, -24.6986, 15.3918);
        add(-18.9658, -26.1333, -9.25188, -12.9283, -17.8373, -3.68668);
        add(32.8414, -44.7499, -3.96548, 41.3729, -35.5501, 1.88547);
        add(-12.0107, -43.9043, 15.2958, -6.24849, -38.452, 21.6608);
        add(-28.9449, 35.0651, -45.8908, -23.5524, 42.0763, -39.3406);
        add(25.2023, -12.4615, 8.84863, 30.8803, -6.57652, 18.4333);
        add(31.7285, 31.0991, -7.73725, 39.8767, 38.2288, 0.932107);
        add(-35.1346, -8.00369, 14.4611, -27.1614, -1.58541, 21.4893);
        add(13.9228, -49.9973, -2.77406, 23.104, -41.5596, 4.89623);
        let mut found: Vec<i32> = Vec::new();
        let hits = t.search([-60.0, -60.0, -60.0], [60.0, 60.0, 60.0], |data| {
            found.push(data);
            true
        });

        MINI_CHECK!(hits > 0);
        MINI_CHECK!(hits <= 100);
        for d in &found {
            MINI_CHECK!(*d >= 0);
            MINI_CHECK!(*d < 100);
        }
    })
}

REGISTER_MINI_TEST!(
    "SpatialRTree",
    "Constructor",
    crate::spatial_rtree_test::run_rtree_constructor
);
REGISTER_MINI_TEST!(
    "SpatialRTree",
    "Creation",
    crate::spatial_rtree_test::run_rtree_creation
);
REGISTER_MINI_TEST!(
    "SpatialRTree",
    "Insert",
    crate::spatial_rtree_test::run_rtree_insert
);
REGISTER_MINI_TEST!(
    "SpatialRTree",
    "Insert Multiple",
    crate::spatial_rtree_test::run_rtree_insert_multiple
);
REGISTER_MINI_TEST!(
    "SpatialRTree",
    "Search Hit",
    crate::spatial_rtree_test::run_rtree_search_hit
);
REGISTER_MINI_TEST!(
    "SpatialRTree",
    "Search Miss",
    crate::spatial_rtree_test::run_rtree_search_miss
);
REGISTER_MINI_TEST!(
    "SpatialRTree",
    "Remove",
    crate::spatial_rtree_test::run_rtree_remove
);
REGISTER_MINI_TEST!(
    "SpatialRTree",
    "Remove All",
    crate::spatial_rtree_test::run_rtree_remove_all
);
REGISTER_MINI_TEST!(
    "SpatialRTree",
    "Search Count",
    crate::spatial_rtree_test::run_rtree_search_count
);
REGISTER_MINI_TEST!(
    "SpatialRTree",
    "Search Stop",
    crate::spatial_rtree_test::run_rtree_search_stop
);
REGISTER_MINI_TEST!(
    "SpatialRTree",
    "Normalizes Reversed Bounds",
    crate::spatial_rtree_test::run_rtree_normalizes_reversed_bounds
);
REGISTER_MINI_TEST!(
    "SpatialRTree",
    "Search 100 Boxes",
    crate::spatial_rtree_test::run_rtree_search_100_boxes
);
