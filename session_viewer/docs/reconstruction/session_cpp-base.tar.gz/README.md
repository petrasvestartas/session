# session_cpp

## Fast Local Development

```bash
./bash/run_cpp_main.sh      # Build + run main.cpp (~6 sec)
./bash/test_cpp.sh          # Build + run tests (~8 sec)
./bash/test_cpp.sh --clean  # Force cmake reconfigure (after CMakeLists.txt changes)
```

**Note:** Scripts skip cmake configure if `build/` exists. Use `--clean` after modifying CMakeLists.txt.

## Build

```bash
cd session_cpp
cmake -B build
cmake --build build --config Release --parallel
```

## Build Speed Optimizations

Two optimizations are enabled by default: **Unity Build** and **Precompiled Headers (PCH)**.

### Unity Build

Combines multiple `.cpp` files into single compilation units. Headers are parsed once per batch instead of once per file.

### Precompiled Headers

Stable STL headers are pre-parsed once and reused. Defined in `src/pch.h`.

### Active Development Workflow

Files under active development should be **excluded from Unity Build** for faster single-file iteration.

| Task | Action |
|------|--------|
| Start developing a class | Add `.cpp` to `UNITY_BUILD_EXCLUDE` in CMakeLists.txt |
| Finish developing a class | Remove from `UNITY_BUILD_EXCLUDE` |
| Modify `src/pch.h` | Delete `build/CMakeFiles` to force PCH rebuild |

### Disable Optimizations

```bash
cmake -B build -DENABLE_UNITY_BUILD=OFF -DENABLE_PCH=OFF
```

### PCH Guidelines

- Only add stable STL/external headers to `src/pch.h`
- Do NOT add project headers under active development
- Do NOT add headers that change frequently
