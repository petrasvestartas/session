#pragma once

#include "nurbssurface.h"
#include "nurbscurve.h"
#include "xform.h"
#include "color.h"
#include "mesh.h"
#include "guid.h"
#include "json.h"
#include <vector>
#include <string>
#include <utility>
#include <array>

namespace session_cpp {

/**
 * @class NurbsSurfaceTrimmed
 * @brief A NURBS surface bounded by a closed outer loop and optional inner loops (holes).
 *
 * Represents a face of a boundary representation: the underlying surface provides
 * the parametric geometry, while 2D trim curves define the visible region.
 * Meshing respects both outer boundary and inner hole loops.
 */
class NurbsSurfaceTrimmed {
public:
    bool has_guid() const { return !_guid.empty(); }
    const std::string& guid() const { if (_guid.empty()) _guid = ::guid(); return _guid; }
    std::string& guid() { if (_guid.empty()) _guid = ::guid(); return _guid; }
    std::string name = "my_nurbssurface_trimmed";
    double width = 1.0;
    Color surfacecolor = Color::black();

    NurbsSurface m_surface;
    NurbsCurve m_outer_loop;
    std::vector<NurbsCurve> m_inner_loops;


public:
    // ═══════════════════════════════════════════════════════════════════════════
    // Static Factory Methods
    // ═══════════════════════════════════════════════════════════════════════════

    /// Create trimmed surface from a NURBS surface and a 2D outer boundary loop.
    /// The outer_loop must be a closed curve in the surface's UV parameter space.
    static NurbsSurfaceTrimmed create(const NurbsSurface& surface, const NurbsCurve& outer_loop);

    /// Create a planar trimmed surface from a closed 3D boundary curve.
    /// Fits a plane to the curve, projects it to 2D, and builds the trim loop automatically.
    static NurbsSurfaceTrimmed create_planar(const NurbsCurve& boundary);

    /// Split a surface into trimmed faces by UV pcurves.
    /// Builds a planar arrangement of the UV domain rectangle and the given
    /// pcurves (NurbsCurves with x=u, y=v, z=0), extracts faces, and emits one
    /// NurbsSurfaceTrimmed per face. Loops are exact trims of the input
    /// pcurves joined with straight border segments. Dangling open cutters
    /// that do not reach the border or another cutter are discarded.
    static std::vector<NurbsSurfaceTrimmed> split_by_uv_curves(const NurbsSurface& srf, const std::vector<NurbsCurve>& pcurves, double tolerance = 0.0);

    // ═══════════════════════════════════════════════════════════════════════════
    // Constructors & Destructor
    // ═══════════════════════════════════════════════════════════════════════════

    NurbsSurfaceTrimmed();
    NurbsSurfaceTrimmed(const NurbsSurfaceTrimmed& other);
    /// Move constructor and assignment: identity SURVIVES a move.
    ///
    /// A copy is a new object and mints a new guid; a move is the SAME object in a new place, so
    /// `_guid` transfers. Declaring these is also what keeps `return x;` safe: the copy below is
    /// user-declared, which suppresses the implicit move, so a `pb_loads` that missed NRVO fell back
    /// to the COPY and silently dropped the guid it had just deserialized - every other field
    /// survived, so the object looked right and only its identity was wrong. That is what broke Line
    /// on MSVC when its pb_loads changed shape; see line.h.
    NurbsSurfaceTrimmed(NurbsSurfaceTrimmed&& other) noexcept = default;
    NurbsSurfaceTrimmed& operator=(NurbsSurfaceTrimmed&& other) noexcept = default;

    NurbsSurfaceTrimmed& operator=(const NurbsSurfaceTrimmed& other);
    bool operator==(const NurbsSurfaceTrimmed& other) const;
    bool operator!=(const NurbsSurfaceTrimmed& other) const;
    ~NurbsSurfaceTrimmed();

    // ═══════════════════════════════════════════════════════════════════════════
    // Accessors
    // ═══════════════════════════════════════════════════════════════════════════

    /// Get the underlying NURBS surface.
    NurbsSurface surface() const;

    /// Get the outer boundary loop (closed 2D curve in UV space).
    NurbsCurve get_outer_loop() const;

    /// Replace the outer boundary loop with a new closed 2D curve.
    void set_outer_loop(const NurbsCurve& loop);

    /// Return true if the surface has a non-trivial outer loop (not the full domain).
    bool is_trimmed() const;

    /// Return true if the surface, outer loop, and all inner loops are valid.
    bool is_valid() const;

    // ═══════════════════════════════════════════════════════════════════════════
    // Inner Loops
    // ═══════════════════════════════════════════════════════════════════════════

    /// Add a pre-built 2D hole loop directly in UV parameter space.
    void add_inner_loop(const NurbsCurve& loop_2d);

    /// Add a hole from a 3D curve by projecting it onto the surface's UV domain.
    void add_hole(const NurbsCurve& curve_3d);

    /// Add multiple holes from 3D curves, projecting each onto the surface.
    void add_holes(const std::vector<NurbsCurve>& curves_3d);

    /// Get the inner loop at the given index (0-based).
    NurbsCurve get_inner_loop(int index) const;

    /// Return the number of inner (hole) loops.
    int inner_loop_count() const;

    /// Remove all inner loops.
    void clear_inner_loops();

    // ═══════════════════════════════════════════════════════════════════════════
    // Evaluation
    // ═══════════════════════════════════════════════════════════════════════════

    /// Evaluate a 3D point on the underlying surface at parameters (u, v).
    Point point_at(double u, double v) const;

    /// Evaluate the surface normal at parameters (u, v).
    Vector normal_at(double u, double v) const;

    // ═══════════════════════════════════════════════════════════════════════════
    // Meshing
    // ═══════════════════════════════════════════════════════════════════════════

    /// Generate a triangle mesh respecting outer and inner trim loops.
    /// Uses adaptive subdivision based on surface curvature and chord-height tolerance.
    Mesh mesh() const;

    /// Mesh at a chosen tessellation quality: angular bound (degrees, normal turn across a
    /// triangle) and chord factor (deflection tolerance as a fraction of the 3D bbox diagonal).
    /// Unified deflection-refined constrained-Delaunay pipeline (BRepMesh / OpenNURBS style).
    Mesh mesh_q(double max_angle_deg, double chord_factor) const;

    /// Mesh the surface trimmed by a plane (q0, normal), keeping the half where (S-q0).n <= 0.
    /// OCCT path-A algorithm: span-adaptive UV grid + marching-squares clip where the signed
    /// distance field f(u,v)=(S(u,v)-q0).n changes sign, with every boundary crossing
    /// Newton-refined onto the plane (so the cut curve lies exactly on it), then coincident-3D
    /// vertices welded so periodic seams (cylinder/torus/sphere) close watertight.
    Mesh mesh_by_plane(const Point& q0, const Vector& normal, double max_angle_deg, double chord_factor) const;

    /// Multi-plane half-space clip: keep the region inside ALL half-spaces { (S-q).n <= 0 }.
    /// Planes are passed in (no persisted cut state). Same span-adaptive UV grid + per-plane
    /// Sutherland-Hodgman clip + Newton-onto-plane + 3D weld as mesh_by_plane, generalised to K planes.
    Mesh mesh_by_planes(const std::vector<std::pair<Point, Vector>>& planes, double max_angle_deg, double chord_factor) const;

    /// Split a surface into every non-empty region carved by `planes` (all 2^K sign
    /// combinations). Each region comes back as a first-class multi-plane trimmed surface.
    static std::vector<NurbsSurfaceTrimmed> split_by_planes(const NurbsSurface& srf, const std::vector<std::pair<Point, Vector>>& planes);

    // ═══════════════════════════════════════════════════════════════════════════
    // Transformation
    // ═══════════════════════════════════════════════════════════════════════════

    /// Apply a transformation to the surface geometry (in-place).
    void transform(const Xform& xform);

    /// Return a copy with the transformation applied.
    NurbsSurfaceTrimmed transformed(const Xform& xform) const;

    // ═══════════════════════════════════════════════════════════════════════════
    // JSON Serialization
    // ═══════════════════════════════════════════════════════════════════════════

    /// Convert to JSON object with fields in alphabetical order.
    nlohmann::ordered_json jsondump() const;

    /// Construct from a JSON object.
    static NurbsSurfaceTrimmed jsonload(const nlohmann::json& data);

    /// Write JSON to a file.
    void file_json_dump(const std::string& filename) const;

    /// Read from a JSON file.
    static NurbsSurfaceTrimmed file_json_load(const std::string& filename);

    /// Serialize to a JSON string.
    std::string file_json_dumps() const;

    /// Deserialize from a JSON string.
    static NurbsSurfaceTrimmed file_json_loads(const std::string& json_string);

    // ═══════════════════════════════════════════════════════════════════════════
    // Protobuf Serialization
    // ═══════════════════════════════════════════════════════════════════════════

    /// Serialize to a protobuf binary string.
    std::string pb_dumps() const;

    /// Deserialize from a protobuf binary string.
    static NurbsSurfaceTrimmed pb_loads(const std::string& data);

    /// Write protobuf to a file.
    void pb_dump(const std::string& filename) const;

    /// Read from a protobuf file.
    static NurbsSurfaceTrimmed pb_load(const std::string& filename);

    // ═══════════════════════════════════════════════════════════════════════════
    // String Representation
    // ═══════════════════════════════════════════════════════════════════════════

    /// Simple string (type, surface degree, trim loop counts).
    std::string str() const;

    /// Detailed string with surface domain and CV counts.
    std::string repr() const;

    /// Stream output operator (calls str()).
    friend std::ostream& operator<<(std::ostream& os, const NurbsSurfaceTrimmed& ts);

private:
    mutable std::string _guid;

    // ═══════════════════════════════════════════════════════════════════════════
    // Internal Helpers
    // ═══════════════════════════════════════════════════════════════════════════

    void deep_copy_from(const NurbsSurfaceTrimmed& src);
};

} // namespace session_cpp
