#pragma once
#include <string>
#include "pointcloud.h"

namespace session_cpp { namespace io_xyz {

/// Return the cloud points as "x y z" lines at full double precision.
std::string write_xyz_to_string(const PointCloud& cloud);

/// Write the cloud points as "x y z" lines to filepath.
void write_xyz(const PointCloud& cloud, const std::string& filepath);

/// Return the cloud read from "x y z" lines; blank and # lines skipped.
PointCloud read_xyz_from_str(const std::string& content);

/// Return the cloud read from an .xyz file.
PointCloud read_xyz(const std::string& filepath);

} } // namespace session_cpp::io_xyz
