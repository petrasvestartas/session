#include "mini_test.h"
#include "pointcloud.h"
#include "color.h"
#include "point.h"
#include "tolerance.h"
#include "vector.h"
#include "xform.h"
#include <vector>

using namespace session_cpp::mini_test;

namespace session_cpp {

    MINI_TEST("PointCloud", "Constructor") {

        PointCloud pc0;

        Point p0(0.0, 0.0, 0.0);
        Point p1(1.0, 0.0, 0.0);
        Point p2(0.0, 1.0, 0.0);
        Vector n0(0.0, 0.0, 1.0);
        Vector n1(0.0, 0.0, 1.0);
        Vector n2(0.0, 0.0, 1.0);
        Color c0(1.0f, 0.0f, 0.0f, 1.0f);
        Color c1(0.0f, 1.0f, 0.0f, 1.0f);
        Color c2(0.0f, 0.0f, 1.0f, 1.0f);
        PointCloud pc({p0, p1, p2}, {n0, n1, n2}, {c0, c1, c2});

        std::string pcstr = pc.str();
        std::string pcrepr = pc.repr();

        PointCloud pccopy = pc;
        PointCloud pcother;

        Vector offset(10.0, 20.0, 30.0);
        PointCloud pc_iadd({Point(1.0, 2.0, 3.0)}, {}, {});
        pc_iadd += offset;
        PointCloud pc_isub({Point(1.0, 2.0, 3.0)}, {}, {});
        pc_isub -= offset;
        PointCloud pc3({Point(1.0, 2.0, 3.0)}, {}, {});
        PointCloud pc_add = pc3 + offset;
        PointCloud pc_sub = pc3 - offset;

        MINI_CHECK(pc0.name == "my_pointcloud");
        MINI_CHECK(!pc0.guid().empty());
        MINI_CHECK(pc0.is_empty());
        MINI_CHECK(pc.len() == 3);
        MINI_CHECK(pcstr == "3 points");
        MINI_CHECK(pcrepr == "PointCloud(my_pointcloud, 3 points, 3 colors, 3 normals)");
        MINI_CHECK(pccopy == pc && pccopy.guid() != pc.guid());
        MINI_CHECK(pcother != pc);
        MINI_CHECK(TOLERANCE.is_close(pc_iadd.get_point(0)[0], 11.0) && TOLERANCE.is_close(pc_iadd.get_point(0)[1], 22.0) && TOLERANCE.is_close(pc_iadd.get_point(0)[2], 33.0));
        MINI_CHECK(TOLERANCE.is_close(pc_isub.get_point(0)[0], -9.0) && TOLERANCE.is_close(pc_isub.get_point(0)[1], -18.0) && TOLERANCE.is_close(pc_isub.get_point(0)[2], -27.0));
        MINI_CHECK(TOLERANCE.is_close(pc_add.get_point(0)[0], 11.0) && TOLERANCE.is_close(pc_add.get_point(0)[1], 22.0) && TOLERANCE.is_close(pc_add.get_point(0)[2], 33.0));
        MINI_CHECK(TOLERANCE.is_close(pc_sub.get_point(0)[0], -9.0) && TOLERANCE.is_close(pc_sub.get_point(0)[1], -18.0) && TOLERANCE.is_close(pc_sub.get_point(0)[2], -27.0));
    }

    MINI_TEST("PointCloud", "From Coords") {

        std::vector<double> coords = {0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0};
        std::vector<int> colors = {255, 0, 0, 255, 0, 255, 0, 255, 0, 0, 255, 255};
        std::vector<double> normals = {0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0};
        PointCloud pc = PointCloud::from_coords(coords, colors, normals);

        MINI_CHECK(pc.len() == 3 && pc.color_count() == 3 && pc.normal_count() == 3);
        MINI_CHECK(TOLERANCE.is_close(pc.get_point(1)[0], 1.0));
        MINI_CHECK(pc.get_color(1).g == 1.0f);
        MINI_CHECK(TOLERANCE.is_close(pc.get_normal(1)[2], 1.0));
    }

    MINI_TEST("PointCloud", "Point Count") {
        PointCloud pc({Point(0.0, 0.0, 0.0), Point(1.0, 0.0, 0.0), Point(0.0, 1.0, 0.0)}, {}, {});

        MINI_CHECK(pc.point_count() == 3);
    }

    MINI_TEST("PointCloud", "Len") {
        PointCloud pc({Point(0.0, 0.0, 0.0), Point(1.0, 0.0, 0.0)}, {}, {});

        MINI_CHECK(pc.len() == 2);
    }

    MINI_TEST("PointCloud", "Is Empty") {

        PointCloud pc0;
        PointCloud pc1({Point(0.0, 0.0, 0.0)}, {}, {});

        MINI_CHECK(pc0.is_empty());
        MINI_CHECK(!pc1.is_empty());
    }

    MINI_TEST("PointCloud", "Get Point") {

        PointCloud pc({Point(1.0, 2.0, 3.0), Point(4.0, 5.0, 6.0)}, {}, {});
        Point pt = pc.get_point(1);

        MINI_CHECK(TOLERANCE.is_close(pt[0], 4.0));
        MINI_CHECK(TOLERANCE.is_close(pt[1], 5.0));
        MINI_CHECK(TOLERANCE.is_close(pt[2], 6.0));
    }

    MINI_TEST("PointCloud", "Set Point") {

        PointCloud pc({Point(0.0, 0.0, 0.0)}, {}, {});
        pc.set_point(0, Point(4.0, 5.0, 6.0));

        MINI_CHECK(TOLERANCE.is_close(pc.get_point(0)[0], 4.0));
        MINI_CHECK(TOLERANCE.is_close(pc.get_point(0)[1], 5.0));
        MINI_CHECK(TOLERANCE.is_close(pc.get_point(0)[2], 6.0));
    }

    MINI_TEST("PointCloud", "Add Point") {

        PointCloud pc;
        pc.add_point(Point(1.0, 2.0, 3.0));

        MINI_CHECK(pc.len() == 1);
        MINI_CHECK(TOLERANCE.is_close(pc.get_point(0)[0], 1.0));
        MINI_CHECK(TOLERANCE.is_close(pc.get_point(0)[1], 2.0));
        MINI_CHECK(TOLERANCE.is_close(pc.get_point(0)[2], 3.0));
    }

    MINI_TEST("PointCloud", "Get Points") {

        PointCloud pc({Point(1.0, 2.0, 3.0), Point(4.0, 5.0, 6.0)}, {}, {});
        std::vector<Point> points = pc.get_points();

        MINI_CHECK(points.size() == 2);
        MINI_CHECK(TOLERANCE.is_close(points[0][0], 1.0));
        MINI_CHECK(TOLERANCE.is_close(points[1][2], 6.0));
    }

    MINI_TEST("PointCloud", "Color Count") {
        PointCloud pc({}, {}, {Color(1.0f, 0.0f, 0.0f, 1.0f), Color(0.0f, 1.0f, 0.0f, 1.0f)});

        MINI_CHECK(pc.color_count() == 2);
    }

    MINI_TEST("PointCloud", "Get Color") {
        PointCloud pc({}, {}, {Color(1.0f, 0.0f, 0.0f, 1.0f), Color(0.0f, 1.0f, 0.0f, 1.0f)});
        Color c = pc.get_color(1);

        MINI_CHECK(c.r == 0.0f && c.g == 1.0f && c.b == 0.0f && c.a == 1.0f);
    }

    MINI_TEST("PointCloud", "Set Color") {
        PointCloud pc({}, {}, {Color(0.0f, 0.0f, 0.0f, 0.0f)});
        pc.set_color(0, Color(1.0f, 0.0f, 0.0f, 1.0f));

        MINI_CHECK(pc.get_color(0).r == 1.0f && pc.get_color(0).g == 0.0f && pc.get_color(0).b == 0.0f && pc.get_color(0).a == 1.0f);
    }

    MINI_TEST("PointCloud", "Add Color") {

        PointCloud pc;
        pc.add_color(Color(1.0f, 0.0f, 1.0f, 1.0f));

        MINI_CHECK(pc.color_count() == 1);
        MINI_CHECK(pc.get_color(0).r == 1.0f && pc.get_color(0).g == 0.0f && pc.get_color(0).b == 1.0f);
    }

    MINI_TEST("PointCloud", "Coords") {

        PointCloud pc({Point(1.0, 2.0, 3.0), Point(4.0, 5.0, 6.0)}, {}, {});
        const std::vector<double>& coords = pc.coords();

        MINI_CHECK(coords.size() == 6);
        MINI_CHECK(TOLERANCE.is_close(coords[0], 1.0));
        MINI_CHECK(TOLERANCE.is_close(coords[5], 6.0));
    }

    MINI_TEST("PointCloud", "Colors") {

        PointCloud pc({}, {}, {Color(1.0f, 0.0f, 0.0f, 1.0f)});
        const std::vector<int>& colors = pc.colors();

        MINI_CHECK(colors.size() == 4);
        MINI_CHECK(colors[0] == 255 && colors[1] == 0 && colors[2] == 0 && colors[3] == 255);
    }

    MINI_TEST("PointCloud", "Get Colors") {

        PointCloud pc({}, {}, {Color(1.0f, 0.0f, 0.0f, 1.0f), Color(0.0f, 1.0f, 0.0f, 1.0f)});
        std::vector<Color> colors = pc.get_colors();

        MINI_CHECK(colors.size() == 2);
        MINI_CHECK(colors[0].r == 1.0f);
        MINI_CHECK(colors[1].g == 1.0f);
    }

    MINI_TEST("PointCloud", "Normal Count") {
        PointCloud pc({}, {Vector(0.0, 0.0, 1.0), Vector(0.0, 0.0, 1.0)}, {});

        MINI_CHECK(pc.normal_count() == 2);
    }

    MINI_TEST("PointCloud", "Get Normal") {

        PointCloud pc({}, {Vector(0.0, 0.0, 1.0), Vector(1.0, 0.0, 0.0)}, {});
        Vector n = pc.get_normal(1);

        MINI_CHECK(TOLERANCE.is_close(n[0], 1.0));
        MINI_CHECK(TOLERANCE.is_close(n[1], 0.0));
        MINI_CHECK(TOLERANCE.is_close(n[2], 0.0));
    }

    MINI_TEST("PointCloud", "Set Normal") {

        PointCloud pc({}, {Vector(0.0, 0.0, 1.0)}, {});
        pc.set_normal(0, Vector(0.0, 1.0, 0.0));

        MINI_CHECK(TOLERANCE.is_close(pc.get_normal(0)[0], 0.0));
        MINI_CHECK(TOLERANCE.is_close(pc.get_normal(0)[1], 1.0));
        MINI_CHECK(TOLERANCE.is_close(pc.get_normal(0)[2], 0.0));
    }

    MINI_TEST("PointCloud", "Add Normal") {

        PointCloud pc;
        pc.add_normal(Vector(1.0, 0.0, 0.0));

        MINI_CHECK(pc.normal_count() == 1);
        MINI_CHECK(TOLERANCE.is_close(pc.get_normal(0)[0], 1.0));
    }

    MINI_TEST("PointCloud", "Get Normals") {

        PointCloud pc({}, {Vector(0.0, 0.0, 1.0), Vector(1.0, 0.0, 0.0)}, {});
        std::vector<Vector> normals = pc.get_normals();

        MINI_CHECK(normals.size() == 2);
        MINI_CHECK(TOLERANCE.is_close(normals[0][2], 1.0));
        MINI_CHECK(TOLERANCE.is_close(normals[1][0], 1.0));
    }

    MINI_TEST("PointCloud", "Point Ids") {

        std::vector<double> coords = {0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 1.0, 1.0, 0.0, 0.0, 0.0, 1.0, 1.0, 0.0, 1.0, 0.0, 1.0, 1.0, 1.0, 1.0, 1.0};
        PointCloud pc = PointCloud::from_coords(coords, {}, {});
        Point before = pc.get_point(5);
        pc.build_lod(1.0, 2);

        MINI_CHECK(pc.point_ids().size() == 8);
        MINI_CHECK(pc.index_of_id(5) >= 0);
        MINI_CHECK(pc.get_point(pc.index_of_id(5)) == before);
    }

    MINI_TEST("PointCloud", "Build Lod") {

        std::vector<double> coords = {0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 1.0, 1.0, 0.0, 0.0, 0.0, 1.0, 1.0, 0.0, 1.0, 0.0, 1.0, 1.0, 1.0, 1.0, 1.0};
        PointCloud pc = PointCloud::from_coords(coords, {}, {});
        pc.build_lod(1.0, 2);

        MINI_CHECK(pc.has_lod());
        MINI_CHECK(pc.lod_node_count() == 8);
        MINI_CHECK(pc.lod_range(0).first == 0 && pc.lod_range(0).second == 1);
        MINI_CHECK(pc.coords().size() == 24);
    }

    MINI_TEST("PointCloud", "Transform") {

        PointCloud pc({Point(1.0, 2.0, 3.0)}, {}, {});
        Xform pc_xf = Xform::translation(10.0, 20.0, 30.0);
        pc.transform(pc_xf);

        MINI_CHECK(TOLERANCE.is_close(pc.get_point(0)[0], 11.0));
        MINI_CHECK(TOLERANCE.is_close(pc.get_point(0)[1], 22.0));
        MINI_CHECK(TOLERANCE.is_close(pc.get_point(0)[2], 33.0));
    }

    MINI_TEST("PointCloud", "Transformed") {

        PointCloud pc({Point(1.0, 2.0, 3.0)}, {}, {});
        Xform pc_xf = Xform::translation(10.0, 20.0, 30.0);
        PointCloud pc2 = pc.transformed(pc_xf);

        MINI_CHECK(TOLERANCE.is_close(pc2.get_point(0)[0], 11.0));
        MINI_CHECK(TOLERANCE.is_close(pc2.get_point(0)[1], 22.0));
        MINI_CHECK(TOLERANCE.is_close(pc2.get_point(0)[2], 33.0));
        MINI_CHECK(TOLERANCE.is_close(pc.get_point(0)[0], 1.0));
    }

    MINI_TEST("PointCloud", "Json Roundtrip") {

        PointCloud pc(
            {Point(1.0, 2.0, 3.0), Point(4.0, 5.0, 6.0)},
            {Vector(0.0, 0.0, 1.0), Vector(0.0, 0.0, 1.0)},
            {Color(1.0f, 0.0f, 0.0f, 1.0f), Color(0.0f, 1.0f, 0.0f, 1.0f)}
        );
        pc.name = "test_pointcloud";

        std::string fname = "serialization/test_pointcloud.json";
        pc.file_json_dump(fname);
        PointCloud loaded = PointCloud::file_json_load(fname);

        MINI_CHECK(loaded.name == "test_pointcloud");
        MINI_CHECK(loaded.len() == 2);
        MINI_CHECK(TOLERANCE.is_close(loaded.get_point(0)[0], 1.0));
        MINI_CHECK(loaded.get_color(0).r == 1.0f);
        MINI_CHECK(TOLERANCE.is_close(loaded.get_normal(0)[2], 1.0));
    }

    MINI_TEST("PointCloud", "Protobuf Roundtrip") {

        PointCloud pc(
            {Point(1.0, 2.0, 3.0), Point(4.0, 5.0, 6.0)},
            {Vector(0.0, 0.0, 1.0), Vector(0.0, 0.0, 1.0)},
            {Color(1.0f, 0.0f, 0.0f, 1.0f), Color(0.0f, 1.0f, 0.0f, 1.0f)}
        );
        pc.name = "test_pointcloud";

        std::string fname = "serialization/test_pointcloud.bin";
        pc.pb_dump(fname);
        PointCloud loaded = PointCloud::pb_load(fname);

        MINI_CHECK(loaded.name == "test_pointcloud");
        MINI_CHECK(loaded.len() == 2);
        MINI_CHECK(TOLERANCE.is_close(loaded.get_point(0)[0], 1.0));
        MINI_CHECK(loaded.get_color(0).r == 1.0f);
        MINI_CHECK(TOLERANCE.is_close(loaded.get_normal(0)[2], 1.0));
    }

} // namespace session_cpp
