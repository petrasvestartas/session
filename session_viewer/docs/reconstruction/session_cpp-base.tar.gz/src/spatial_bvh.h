// SpatialBVH — binary tree with OBB leaves, Morton-code (LBVH) construction.
// Use for: collision detection and closest-point between many dynamic objects.
//   Handles oriented boxes via their tight world-space AABBs (half-axes projected).
// Prefer over SpatialAABBTree when objects rotate or you need OBB tightness.
// Prefer over SpatialRTree  when all queries are nearest-object, not region overlap.
// Prefer over SpatialKDTree when objects are volumetric (not point clouds).
#pragma once

#include "point.h"
#include "vector.h"
#include "obb.h"
#include "aabb.h"
#include "guid.h"
#include <string>
#include <vector>
#include <memory>
#include <tuple>

namespace session_cpp {

/**
 * @brief A node in the Bounding Volume Hierarchy tree
 * 
 * Represents a single node in the SpatialBVH structure, containing either
 * child nodes or a reference to a geometry object.
 */
class SpatialBVHNode {
public:
    SpatialBVHNode* left;
    SpatialBVHNode* right;
    int object_id;
    AABB aabb;

    SpatialBVHNode();
    bool is_leaf() const;
};

/**
 * @brief Bounding Volume Hierarchy for efficient spatial queries and collision detection
 * 
 * A spatial data structure that organizes bounding boxes in a binary tree
 * for fast collision detection and spatial queries using Morton codes.
 */
class SpatialBVH {
public:
    bool has_guid() const { return !_guid.empty(); }
    const std::string& guid() const { if (_guid.empty()) _guid = ::guid(); return _guid; }
    std::string& guid() { if (_guid.empty()) _guid = ::guid(); return _guid; }
    std::string name;
    SpatialBVHNode* root;
    double world_size;
    std::vector<std::string> object_guids;

    // Node arena to store all nodes contiguously (no per-node heap allocations)
    std::vector<SpatialBVHNode> node_arena;

    SpatialBVH(double world_size = 1000.0);

    // Compute world size from bounding boxes
    static double compute_world_size(const std::vector<OBB>& bounding_boxes);

    static SpatialBVH from_boxes(const std::vector<OBB>& bounding_boxes, double world_size);

    // Fast build accepting continuous array of boxes (no copies)
    void build_from_boxes(const OBB* boxes, size_t count, double ws);
    // Fast build accepting continuous array of lightweight AABBs (no OBB construction)
    void build_from_aabbs(const AABB* aabbs, size_t count, double ws);
    // Build from bounding boxes with GUIDs; world size auto-computed
    void build_with_guids(const std::vector<std::pair<OBB, std::string>>& boxes_with_guids);

    void build(const std::vector<OBB>& bounding_boxes);
    std::tuple<std::vector<std::pair<int, int>>, std::vector<int>, int> check_all_collisions(const std::vector<OBB>& bounding_boxes);
    std::vector<std::pair<std::string, std::string>> check_all_collisions_guids(const std::vector<OBB>& bounding_boxes);

    // Collisions of one object against the tree, excluding self; returns (object_ids, check_count)
    std::pair<std::vector<int>, int> find_collisions(int object_id, const OBB& query_bbox, const std::vector<OBB>& bounding_boxes) const;

    // Public helper methods for testing
    OBB merge_aabb(const OBB& aabb1, const OBB& aabb2);
    bool aabb_intersect(const OBB& aabb1, const OBB& aabb2) const;
    bool aabb_intersect(const AABB& aabb1, const AABB& aabb2) const;

    // Find all leaf object_ids whose AABB overlaps the query box.
    std::vector<int> query_aabb(const AABB& query) const;
    std::vector<int> query_aabb(const OBB& query) const;

    // Convenience: find leaf object_ids near `object_id`, excluding self.
    // Inflates the half-extents of the object's AABB by `inflate` and queries.
    std::vector<int> nearest_neighbors(int object_id,
                                       const std::vector<OBB>& bounding_boxes,
                                       double inflate = 1.2) const;

    // Ray cast traversal over SpatialBVH nodes returning candidate leaf indices ordered by AABB entry t.
    bool ray_cast(const Point& origin,
                  const Vector& direction,
                  std::vector<int>& candidate_leaf_ids,
                  bool find_all = false) const;

private:
    mutable std::string _guid;

    struct ObjectInfo {
        int id;
        uint32_t morton_code;
    };

    // Allocates a node in the arena and returns a raw pointer to it
    SpatialBVHNode* alloc_node();

    // Subtree creation using sorted object keys and read-only boxes array
};

// Morton code functions
uint32_t expand_bits(uint32_t v);
uint32_t calculate_morton_code(double x, double y, double z, double world_size = 100.0);

}
