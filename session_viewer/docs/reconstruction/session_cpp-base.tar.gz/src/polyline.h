#pragma once
#include "plane.h"
#include "point.h"
#include "vector.h"
#include "color.h"
#include "xform.h"
#include "line.h"
#include "guid.h"
#include "json.h"
#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <optional>
#include <tuple>

namespace session_cpp {


/**
 * @class Polyline
 * @brief A polyline defined by a collection of coordinates with an associated plane.
 *
 * Internally stores coordinates as a flat array [x0, y0, z0, x1, y1, z1, ...] for
 * efficient serialization. Provides Point-based API for compatibility.
 */
class Polyline {
public:
    std::string name = "my_polyline";
    bool has_guid() const { return !_guid.empty(); }
    const std::string& guid() const { if (_guid.empty()) _guid = ::guid(); return _guid; }
    std::string& guid() { if (_guid.empty()) _guid = ::guid(); return _guid; }
    /// Clear the guid so a FRESH one mints lazily on next read — the duplicate/copy enabler.
    void refresh_guid() { _guid.clear(); }
    std::vector<double> _coords;  // Flat array [x0, y0, z0, x1, y1, z1, ...]
    mutable Plane plane;
    mutable bool _plane_dirty = true;
    double width = 1.0;
    std::vector<double> dash;   ///< Dash pattern: on/off lengths in mm, repeating; empty = solid
    Color linecolor = Color::black();


    /// Get plane (lazy — computed on first access from first 3 points)
    const Plane& get_plane() const;

    /// Default constructor
    Polyline();

    /// Copy constructor (creates a new guid while copying data)
    Polyline(const Polyline& other);

    /// Move constructor and assignment: identity SURVIVES a move.
    ///
    /// A copy is a new object and mints a new guid; a move is the SAME object in a new place, so
    /// `_guid` transfers. Declaring these is also what keeps `return x;` safe: the copy below is
    /// user-declared, which suppresses the implicit move, so a `pb_loads` that missed NRVO fell back
    /// to the COPY and silently dropped the guid it had just deserialized - every other field
    /// survived, so the object looked right and only its identity was wrong. That is what broke Line
    /// on MSVC when its pb_loads changed shape; see line.h.
    Polyline(Polyline&& other) noexcept = default;
    Polyline& operator=(Polyline&& other) noexcept = default;

    /// Copy assignment (creates a new guid while copying data)
    Polyline& operator=(const Polyline& other);

    /// Constructor with points (converts to flat coords internally)
    explicit Polyline(const std::vector<Point>& pts);

    /// Constructor with flat coords
    static Polyline from_coords(const std::vector<double>& coords);

    /// Create a regular polygon with given number of sides and radius.
    static Polyline from_sides(int sides, double radius = 1.0, bool close = false);

    /// Create a rectangle with its corner at origin, sides along x_axis and y_axis.
    static Polyline rectangle(const Point& origin, const Vector& x_axis, const Vector& y_axis,
                              double width, double height, bool close = true);

    // ═══════════════════════════════════════════════════════════════════════════
    // Core Methods (str, repr, duplicate, eq)
    // ═══════════════════════════════════════════════════════════════════════════

    /// Returns minimal string representation
    std::string str() const;

    /// Returns detailed string representation
    std::string repr() const;

    /// Equality operator (compares values, ignores GUIDs)
    bool operator==(const Polyline& other) const;
    bool operator!=(const Polyline& other) const;

    /// Index operator (returns point at index)
    Point operator[](size_t index) const;

    // ═══════════════════════════════════════════════════════════════════════════
    // Point Access
    // ═══════════════════════════════════════════════════════════════════════════

    /// Returns the number of points in the polyline
    size_t point_count() const;

    /// Returns the number of points (alias for point_count)
    size_t len() const;

    /// Returns all points as Point objects
    std::vector<Point> get_points() const;

    /// Returns true if the polyline has no points
    bool is_empty() const;

    /// Returns the number of segments (n-1 for n points)
    size_t segment_count() const;

    /// Returns all segments as Line objects
    std::vector<Line> get_lines() const;

    /// Calculates the total length of the polyline
    double length() const;

    /// Returns the point at the given index
    Point get_point(size_t index) const;

    /// Sets the point at the given index
    void set_point(size_t index, const Point& point);

    /// Adds a point to the end of the polyline
    void add_point(const Point& point);

    /// Inserts a point at the specified index
    void insert_point(size_t index, const Point& point);

    /// Removes and returns the point at the specified index
    bool remove_point(size_t index, Point& out_point);

    /// Reverses the order of points in the polyline
    void reverse();

    /// Returns a new polyline with reversed point order
    Polyline reversed() const;

    // ═══════════════════════════════════════════════════════════════════════════
    // Operators
    // ═══════════════════════════════════════════════════════════════════════════

    /// Translates all points by a vector (in-place)
    Polyline& operator+=(const Vector& v);

    /// Translates all points by a vector (returns new polyline)
    Polyline operator+(const Vector& v) const;

    /// Translates all points by negative vector (in-place)
    Polyline& operator-=(const Vector& v);

    /// Translates all points by negative vector (returns new polyline)
    Polyline operator-(const Vector& v) const;

    /// Multiply all coordinates by scalar (in-place)
    Polyline& operator*=(double factor);

    /// Multiply polyline by scalar (returns new polyline)
    Polyline operator*(double factor) const;

    /// Divide all coordinates by scalar (in-place)
    Polyline& operator/=(double factor);

    /// Divide polyline by scalar (returns new polyline)
    Polyline operator/(double factor) const;

    /// Negate polyline (reverse point order)
    Polyline operator-() const;

    // ═══════════════════════════════════════════════════════════════════════════
    // Transformation
    // ═══════════════════════════════════════════════════════════════════════════

    void transform(const Xform& xform);
    Polyline transformed(const Xform& xform) const;

    /**
     * @brief Translate every point of this polyline by `v` (in place).
     *
     * Mirrors the free function `move(std::vector<Point>&, const Vector&)`
     * in this header — promoted to a class method for ergonomics.
     *
     * Named `translate` (not `move`) for cross-language parity: Rust's
     * `move` is a keyword, and `translate` is more descriptive.
     *
     * @param v Translation vector.
     */
    void translate(const Vector& v);

    /// Non-mutating translate: returns a new Polyline offset by v.
    Polyline translated(const Vector& v) const;

    /**
     * @brief Slide both endpoints of edge `edge_idx` outward (or inward
     *        for negative `distance`) along the edge tangent.
     *
     * For closed polylines, the closing-duplicate vertex is kept in sync
     * (i.e. modifying point 0 also modifies point n-1 if they coincide).
     * Wood's `merge_joints` calls this in opposite-edge pairs (0+2, 1+3)
     * to scale rectangle joint volumes uniformly along their two
     * principal axes.
     *
     * @param edge_idx Index of the first vertex of the edge.
     * @param distance Signed distance to extend each endpoint by.
     */
    void extend_edge_equally(size_t edge_idx, double distance);

    // ═══════════════════════════════════════════════════════════════════════════
    // JSON Serialization
    // ═══════════════════════════════════════════════════════════════════════════

    /// Convert to JSON-serializable object (uses compact coords format)
    nlohmann::ordered_json jsondump() const;

    /// Create polyline from JSON data (supports both coords and legacy points format)
    static Polyline jsonload(const nlohmann::json& data);

    /// Serialize to JSON file
    void file_json_dump(const std::string& filename) const;

    /// Deserialize from JSON file
    static Polyline file_json_load(const std::string& filename);

    /// Convert to JSON string
    std::string file_json_dumps() const;

    /// Load from JSON string
    static Polyline file_json_loads(const std::string& json_string);

    // ═══════════════════════════════════════════════════════════════════════════
    // Protobuf Serialization
    // ═══════════════════════════════════════════════════════════════════════════

    /// Convert to protobuf binary string
    std::string pb_dumps() const;

    /// Load from protobuf binary string
    static Polyline pb_loads(const std::string& data);

    /// Write protobuf to file
    void pb_dump(const std::string& filename) const;

    /// Read protobuf from file
    static Polyline pb_load(const std::string& filename);

    // ═══════════════════════════════════════════════════════════════════════════
    // Geometric Utilities
    // ═══════════════════════════════════════════════════════════════════════════

    /// Shift polyline points by specified number of positions
    void shift(int times);

    /// Calculate squared length of polyline (faster, no sqrt)
    double length_squared() const;

    /// Get point at parameter t along a line segment (t=0 is start, t=1 is end)
    static Point point_at(const Point& start, const Point& end, double t);

    /// Generate a polyline along a quadratic Bezier curve defined by three points.
    ///
    /// Evaluates B(t) = (1-t)²·p0 + 2(1-t)t·p1 + t²·p2 for ``divisions``
    /// uniformly-spaced values of t in [0, 1].
    ///
    /// @param p0        Start point.
    /// @param p1        Control point (the parabola apex direction).
    /// @param p2        End point.
    /// @param divisions Number of points along the curve (minimum 2).
    /// @return          Polyline of ``divisions`` sampled points.
    static Polyline quadratic_points(const Point& p0, const Point& p1, const Point& p2,
                                     int divisions = 7);

    /// Find closest point on line segment to given point, returns parameter t
    static void closest_point_to_line(const Point& point, const Point& line_start, 
                                     const Point& line_end, double& t);

    /// Check if two line segments overlap and return the overlapping segment
    static bool line_line_overlap(const Point& line0_start, const Point& line0_end,
                                 const Point& line1_start, const Point& line1_end,
                                 Point& overlap_start, Point& overlap_end);

    /// Calculate average of two line segments
    static void line_line_average(const Point& line0_start, const Point& line0_end,
                                 const Point& line1_start, const Point& line1_end,
                                 Point& output_start, Point& output_end);

    /// Calculate overlap average of two line segments
    static void line_line_overlap_average(const Point& line0_start, const Point& line0_end,
                                         const Point& line1_start, const Point& line1_end,
                                         Point& output_start, Point& output_end);

    /// Create line from projected points onto a base line
    static bool line_from_projected_points(const Point& line_start, const Point& line_end,
                                          const std::vector<Point>& points,
                                          Point& output_start, Point& output_end);

    /// Find closest distance and point from a point to this polyline
    double closest_distance_and_point(const Point& point, size_t& edge_id, Point& closest_point) const;

    /// Check if polyline is closed (first and last points are the same)
    bool is_closed() const;
    Polyline closed() const;

    /// Cut polyline by plane, returning the portion on one side.
    ///
    /// By default (flip has no value) the side containing the arc-length
    /// midpoint is kept.  Pass flip=false to keep the side opposite to the
    /// plane normal, or flip=true to keep the side aligned with the normal.
    ///
    /// Segment-plane intersections are inserted as new vertices.
    /// Consecutive near-duplicate points (within 1e-6) are removed.
    Polyline cut_by_plane(const Plane& plane,
                          std::optional<bool> flip = std::nullopt) const;

    /// Calculate center point of polyline
    Point center() const;

    /// Get average plane from polyline points
    void get_average_plane(Point& origin, Vector& x_axis, Vector& y_axis, Vector& z_axis) const;

    /// Winding-number point-in-polygon test. p.x/y tested; polygon vertex z ignored.
    bool point_in_polygon_2d(const Point& p) const;

    /// Get fast plane calculation from polyline
    void get_fast_plane(Point& origin, Plane& pln) const;

    /// Extend polyline segment
    void extend_segment(int segment_id, double dist0, double dist1, 
                       double proportion0 = 0.0, double proportion1 = 0.0);

    /// Extend segment equally on both ends (static utility)
    static void extend_segment_equally(Point& segment_start, Point& segment_end,
                                      double dist, double proportion = 0.0);

    /// Extend a line segment independently at each end by a real (normalized) distance
    static void extend_line_segment(Point& start, Point& end, double d0, double d1);

    /// Shrink a line segment equally from both ends by a fraction of its length (not normalized)
    static void shrink_line_segment(Point& start, Point& end, double dist);

    /// Extend polyline segment equally
    void extend_segment_equally(int segment_id, double dist, double proportion = 0.0);

    /// Check if polyline is clockwise oriented
    bool is_clockwise(const Plane& pln) const;

    /// Get convex/concave corners of polyline
    void get_convex_corners(std::vector<bool>& convex_or_concave) const;

    /// Interpolate between two polylines
    static Polyline tween_two_polylines(const Polyline& polyline0, const Polyline& polyline1,
                                       double weight);

    /// Linear interpolation between two points.
    /// kind: 0=no endpoints, 1=both endpoints, 2=start only
    static std::vector<Point> interpolate_points(const Point& from, const Point& to, int steps, int kind = 0);

    /// 2D convex hull (quickhull) in the polygon's local plane.
    static Polyline quick_hull(const Polyline& polygon);

    /// Minimum-area bounding rectangle via rotating calipers; returns closed 5-pt Polyline.
    static std::optional<Polyline> bounding_rectangle(const Polyline& polygon);

    /// Grid of interior points; offset_dist insets (-) or outsets (+) polygon via miter
    /// offset before sampling (0 = skip); div_dist = grid spacing.
    static std::vector<Point> grid_of_points_in_polygon(const Polyline& polygon,
                                                        double offset_dist, double div_dist,
                                                        size_t max_pts = 100);

    /// Largest inscribed circle via mapbox polylabel (quadtree subdivision).
    /// polylines[0] is the outer boundary; polylines[1..] are holes.
    /// Returns (center, plane, radius).
    static std::tuple<Point, Plane, double> polylabel(const std::vector<Polyline>& polylines,
                                                      double precision = 1.0);

    /// Points on the polylabel inscribed circle, scaled by `scale`.
    /// If `orient_to_closest_edge`, the circle is rotated so its first division
    /// aligns with the polygon edge closest to the center.
    static std::vector<Point> polylabel_circle_division_points(
        const Vector& division_direction_in_3d,
        const std::vector<Polyline>& polylines,
        int division = 4,
        double scale = 0.75,
        double precision = 1.0,
        bool orient_to_closest_edge = true);

    /// Boolean operation on two closed planar polylines (2D, uses x,y only).
    /// clip_type: 0=intersection, 1=union, 2=difference (a minus b).
    /// Returns 0+ result polygons. Uses Vatti scanline algorithm.
    static std::vector<Polyline> boolean_op(const Polyline& a, const Polyline& b, int clip_type);

    /// Boolean operation on two 3D coplanar polylines.
    /// Projects to plane's local 2D, runs boolean, inverse-transforms back to 3D.
    static std::vector<Polyline> boolean_op(const Polyline& a, const Polyline& b, const Plane& plane, int clip_type);

    /// Merge consecutive collinear segments (in-place); closed polyline wraps around
    void merge_collinear(double tol = Tolerance::APPROXIMATION);

    /// Simplify a point list using Ramer-Douglas-Peucker
    static std::vector<Point> simplify_points(const std::vector<Point>& points, double tolerance);

    /// Simplify this polyline using Ramer-Douglas-Peucker
    Polyline simplify(double tolerance) const;

    /// Remove consecutive near-duplicate points in place
    void remove_consecutive_duplicates(double tol = Tolerance::APPROXIMATION);

    /// Build two oriented rectangular cross-section polylines (male rect0, female rect1)
    /// from a local frame: center point p, tangent direction segment_vector, and zaxis.
    /// radius controls the half-width; length is the extent along segment_vector.
    /// middle=true: symmetric about p; flip_male: +1/-1/0 for corner order.
    static void two_rects_from_frame(
        const Point&  p,
        const Vector& segment_vector,
        const Vector& zaxis,
        bool          middle,
        double        radius,
        double        length,
        int           flip_male,
        Polyline&     rect0,
        Polyline&     rect1);

private:
    mutable std::string _guid; ///< Lazily generated unique identifier

    /// Helper to recompute plane when points change
    void recompute_plane_if_needed();

    /// Calculate average normal from polyline points
    void average_normal(Vector& average_normal) const;

    static double simplify_perp_dist(const Point& pt, const Point& line_start, const Point& line_end);
    static void simplify_rdp(const std::vector<Point>& points, int start, int end, double tolerance, std::vector<bool>& keep);
};

// ═══════════════════════════════════════════════════════════════════════════
// Stream operator
// ═══════════════════════════════════════════════════════════════════════════

std::ostream& operator<<(std::ostream& os, const Polyline& polyline);

} // namespace session_cpp

// fmt formatter specialization for Polyline
template <> struct fmt::formatter<session_cpp::Polyline> {
    constexpr auto parse(fmt::format_parse_context& ctx) { return ctx.begin(); }

    auto format(const session_cpp::Polyline& polyline, fmt::format_context& ctx) const {
        return fmt::format_to(ctx.out(), "Polyline(guid={}, name={}, points={})",
                            polyline.guid(), polyline.name, polyline.point_count());
    }
};
