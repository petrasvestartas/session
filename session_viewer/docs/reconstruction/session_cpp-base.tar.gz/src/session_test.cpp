#include "mini_test.h"
#include "session.h"
#include "file_encoders.h"
#include "tolerance.h"
#include <filesystem>
#include <fstream>

namespace session_cpp {
using namespace session_cpp::mini_test;

MINI_TEST("Session", "Constructor") {

    Session session;
    Session named("my_named_session");

    MINI_CHECK(session.name == "my_session");
    MINI_CHECK(!session.guid().empty());
    MINI_CHECK(named.name == "my_named_session");
}

MINI_TEST("Session", "Copy") {

    Session session("original");
    std::shared_ptr<Point> point = std::make_shared<Point>(1.0, 2.0, 3.0);
    std::shared_ptr<Element> element = std::make_shared<Element>("plate");
    std::shared_ptr<TreeNode> group = session.add_group("Group");
    session.add_point(point, group);
    session.add_element(element, group);
    session.add_edge(point->guid(), element->guid(), "touching");
    session.set_xform(point->guid(), Xform::translation(1.0, 0.0, 0.0));
    const std::string guid = session.guid();

    Session copy = session;

    MINI_CHECK(copy.name == session.name);
    MINI_CHECK(copy.guid() == guid);
    MINI_CHECK(copy.objects.points->size() == 1);
    MINI_CHECK(copy.objects.elements->size() == 1);
    MINI_CHECK(copy.lookup.size() == session.lookup.size());
    MINI_CHECK(copy.graph.number_of_edges() == 1);
    MINI_CHECK(copy.xforms.size() == 1);
    MINI_CHECK(copy.tree.root()->descendants().size() == session.tree.root()->descendants().size());

    MINI_CHECK(copy.objects.points != session.objects.points);
    MINI_CHECK(copy.objects.elements != session.objects.elements);
    MINI_CHECK(copy.tree.root() != session.tree.root());
    MINI_CHECK(copy.objects.points->at(0) != session.objects.points->at(0));
    MINI_CHECK(copy.objects.points->at(0)->guid() == point->guid());
    MINI_CHECK(copy.objects.elements->at(0)->guid() == element->guid());
    MINI_CHECK(copy.lookup.count(point->guid()) == 1);

    copy.objects.points->clear();
    const std::vector<std::shared_ptr<TreeNode>> copied_nodes = copy.tree.nodes();

    MINI_CHECK(copied_nodes.size() > 1);
    copy.tree.remove(copied_nodes[1]);

    MINI_CHECK(session.objects.points->size() == 1);
    MINI_CHECK(copy.objects.points->size() == 0);
    MINI_CHECK(!session.tree.root()->descendants().empty());
    MINI_CHECK(copy.tree.root()->descendants().empty());
}

MINI_TEST("Session", "Add Point") {

    Session session;
    std::shared_ptr<Point> point = std::make_shared<Point>(1.0, 2.0, 3.0);
    session.add_point(point);

    MINI_CHECK(session.objects.points->size() == 1);
    MINI_CHECK(session.lookup.count(point->guid()) == 1);
    MINI_CHECK(session.graph.has_node(point->guid()));
}

MINI_TEST("Session", "Add Line") {

    Session session;
    std::shared_ptr<Line> line = std::make_shared<Line>(0.0, 0.0, 0.0, 1.0, 0.0, 0.0);
    session.add_line(line);

    MINI_CHECK(session.objects.lines->size() == 1);
    MINI_CHECK(session.lookup.count(line->guid()) == 1);
}

MINI_TEST("Session", "Add Plane") {

    Session session;
    std::shared_ptr<Plane> plane = std::make_shared<Plane>(Plane::xy_plane());
    session.add_plane(plane);

    MINI_CHECK(session.objects.planes->size() == 1);
    MINI_CHECK(session.lookup.count(plane->guid()) == 1);
}

MINI_TEST("Session", "Add OBB") {

    Session session;
    std::shared_ptr<OBB> obb = std::make_shared<OBB>(
        Point(0.0, 0.0, 0.0),
        Vector(1.0, 0.0, 0.0),
        Vector(0.0, 1.0, 0.0),
        Vector(0.0, 0.0, 1.0),
        Vector(1.0, 1.0, 1.0)
    );
    session.add_obb(obb);

    MINI_CHECK(session.objects.bboxes->size() == 1);
    MINI_CHECK(session.lookup.count(obb->guid()) == 1);
}

MINI_TEST("Session", "Add Polyline") {

    Session session;
    std::shared_ptr<Polyline> pl =
        std::make_shared<Polyline>(std::vector<Point>{Point(0, 0, 0), Point(1, 0, 0), Point(1, 1, 0)});

    session.add_polyline(pl);

    MINI_CHECK(session.objects.polylines->size() == 1);
    MINI_CHECK(session.lookup.count(pl->guid()) == 1);
}

MINI_TEST("Session", "Select By Type") {

    Session session;
    std::shared_ptr<TreeNode> g0 = session.add_group("g0");
    std::shared_ptr<TreeNode> g1 = session.add_group("g1");
    std::shared_ptr<TreeNode> g2 = session.add_group("g2");

    session.add_polyline(std::make_shared<Polyline>(std::vector<Point>{Point(0, 0, 0), Point(1, 0, 0)}), g0);
    session.add_polyline(std::make_shared<Polyline>(std::vector<Point>{Point(0, 1, 0), Point(1, 1, 0)}), g0);
    session.add_polyline(std::make_shared<Polyline>(std::vector<Point>{Point(0, 2, 0), Point(1, 2, 0)}), g1);
    session.add_point(std::make_shared<Point>(9, 9, 9), g2);

    std::vector<std::vector<Polyline>> groups = session.select_by_type<Polyline>();

    MINI_CHECK(groups.size() == 2);
    MINI_CHECK(groups[0].size() == 2);
    MINI_CHECK(groups[1].size() == 1);
    MINI_CHECK(TOLERANCE.is_close(groups[1][0].get_point(0)[1], 2.0));

    MINI_CHECK(session.select_by_type<Mesh>().empty());
}

MINI_TEST("Session", "Add Pointcloud") {

    Session session;
    std::shared_ptr<PointCloud> pc = std::make_shared<PointCloud>(
        std::vector<Point>{Point(0, 0, 0), Point(1, 0, 0)},
        std::vector<Vector>{},
        std::vector<Color>{}
    );
    session.add_pointcloud(pc);

    MINI_CHECK(session.objects.pointclouds->size() == 1);
    MINI_CHECK(session.lookup.count(pc->guid()) == 1);
}

MINI_TEST("Session", "Add Mesh") {

    Session session;
    std::shared_ptr<Mesh> mesh = std::make_shared<Mesh>();
    mesh->add_vertex(Point(0, 0, 0), 0);
    mesh->add_vertex(Point(1, 0, 0), 1);
    mesh->add_vertex(Point(0, 1, 0), 2);
    mesh->add_face(std::vector<size_t>{0, 1, 2});
    session.add_mesh(mesh);

    MINI_CHECK(session.objects.meshes->size() == 1);
    MINI_CHECK(session.lookup.count(mesh->guid()) == 1);
}

MINI_TEST("Session", "Add Nurbscurve") {

    Session session;
    std::vector<Point> pts = {Point(0, 0, 0), Point(1, 1, 0), Point(2, 0, 0), Point(3, 1, 0)};
    std::shared_ptr<NurbsCurve> nc = std::make_shared<NurbsCurve>(NurbsCurve::create(false, 2, pts));
    session.add_nurbscurve(nc);

    MINI_CHECK(session.objects.nurbscurves->size() == 1);
    MINI_CHECK(session.lookup.count(nc->guid()) == 1);
}

MINI_TEST("Session", "Add Nurbssurface") {

    Session session;
    std::vector<Point> pts = {
        Point(0, 0, 0),
        Point(0, 1, 0),
        Point(0, 2, 0),
        Point(0, 3, 0),
        Point(1, 0, 0),
        Point(1, 1, 0),
        Point(1, 2, 0),
        Point(1, 3, 0),
        Point(2, 0, 0),
        Point(2, 1, 0),
        Point(2, 2, 0),
        Point(2, 3, 0),
        Point(3, 0, 0),
        Point(3, 1, 0),
        Point(3, 2, 0),
        Point(3, 3, 0),
    };
    std::shared_ptr<NurbsSurface> ns =
        std::make_shared<NurbsSurface>(NurbsSurface::create(false, false, 3, 3, 4, 4, pts));

    session.add_nurbssurface(ns);

    MINI_CHECK(session.objects.nurbssurfaces->size() == 1);
    MINI_CHECK(session.lookup.count(ns->guid()) == 1);
}

MINI_TEST("Session", "Add Brep") {

    Session session;
    std::shared_ptr<BRep> brep = std::make_shared<BRep>(BRep::create_box(1.0, 1.0, 1.0));
    session.add_brep(brep);

    MINI_CHECK(session.objects.breps->size() == 1);
    MINI_CHECK(session.lookup.count(brep->guid()) == 1);
}

MINI_TEST("Session", "Add Element") {

    Session session;
    std::shared_ptr<Element> plate = std::make_shared<Element>("p1");
    session.add_element(plate);

    MINI_CHECK(session.objects.elements->size() == 1);
    MINI_CHECK(session.lookup.count(plate->guid()) == 1);
    MINI_CHECK(session.graph.has_node(plate->guid()));
}

MINI_TEST("Session", "Add Empty Geometry") {

    Session session;
    std::shared_ptr<TreeNode> group = session.add_group("empty");

    MINI_CHECK(session.add_point(nullptr, group) == nullptr);
    MINI_CHECK(session.add_polyline(std::make_shared<Polyline>(std::vector<Point>{Point(0, 0, 0)}), group) == nullptr);
    MINI_CHECK(session.add_pointcloud(std::make_shared<PointCloud>(), group) == nullptr);
    MINI_CHECK(session.add_mesh(std::make_shared<Mesh>(), group) == nullptr);
    MINI_CHECK(session.add_nurbscurve(std::make_shared<NurbsCurve>(), group) == nullptr);
    MINI_CHECK(session.add_nurbssurface(std::make_shared<NurbsSurface>(), group) == nullptr);
    MINI_CHECK(session.add_brep(std::make_shared<BRep>(), group) == nullptr);

    std::shared_ptr<Mesh> vertices_only = std::make_shared<Mesh>();
    vertices_only->add_vertex(Point(0, 0, 0), 0);

    MINI_CHECK(session.add_mesh(vertices_only, group) == nullptr);

    session.add(session.add_mesh(std::make_shared<Mesh>(), group), group);

    MINI_CHECK(session.lookup.empty());
    MINI_CHECK(session.order().empty());
    MINI_CHECK(group->children().empty());
}

MINI_TEST("Session", "Add Group") {

    Session session;
    std::shared_ptr<TreeNode> group = session.add_group("my_group");

    MINI_CHECK(group != nullptr);
    MINI_CHECK(group->name == "my_group");
}

MINI_TEST("Session", "Add Edge") {

    Session session;
    std::shared_ptr<Point> p1 = std::make_shared<Point>(1.0, 2.0, 3.0);
    std::shared_ptr<Point> p2 = std::make_shared<Point>(4.0, 5.0, 6.0);
    session.add_point(p1);
    session.add_point(p2);
    session.add_edge(p1->guid(), p2->guid(), "connection");

    MINI_CHECK(session.graph.has_edge({p1->guid(), p2->guid()}));
}

MINI_TEST("Session", "Add Hierarchy") {

    Session session;
    std::shared_ptr<Point> p1 = std::make_shared<Point>(0, 0, 0);
    std::shared_ptr<Point> p2 = std::make_shared<Point>(1, 0, 0);
    std::shared_ptr<TreeNode> n1 = session.add_point(p1);
    std::shared_ptr<TreeNode> n2 = session.add_point(p2);
    session.add(n1);
    session.add(n2);
    bool ok = session.add_hierarchy(n1->guid(), n2->guid());

    MINI_CHECK(ok);
}

MINI_TEST("Session", "Get Children") {

    Session session;
    std::shared_ptr<Point> p1 = std::make_shared<Point>(0, 0, 0);
    std::shared_ptr<Point> p2 = std::make_shared<Point>(1, 0, 0);
    std::shared_ptr<TreeNode> n1 = session.add_point(p1);
    std::shared_ptr<TreeNode> n2 = session.add_point(p2);
    session.add(n1);
    session.add(n2);
    session.add_hierarchy(n1->guid(), n2->guid());

    std::vector<std::string> children = session.get_children(n1->guid());

    MINI_CHECK(children.size() == 1);
    MINI_CHECK(children[0] == n2->guid());
}

MINI_TEST("Session", "Add Relationship") {

    Session session;
    std::shared_ptr<Point> p1 = std::make_shared<Point>(0, 0, 0);
    std::shared_ptr<Point> p2 = std::make_shared<Point>(1, 0, 0);
    session.add_point(p1);
    session.add_point(p2);
    session.add_relationship(p1->guid(), p2->guid(), "connects_to");

    MINI_CHECK(session.graph.has_edge({p1->guid(), p2->guid()}));
}

MINI_TEST("Session", "Get Neighbours") {

    Session session;
    std::shared_ptr<Point> p1 = std::make_shared<Point>(0, 0, 0);
    std::shared_ptr<Point> p2 = std::make_shared<Point>(1, 0, 0);
    session.add_point(p1);
    session.add_point(p2);
    session.add_edge(p1->guid(), p2->guid(), "connection");

    std::vector<std::string> neighbours = session.get_neighbours(p1->guid());

    MINI_CHECK(neighbours.size() == 1);
    MINI_CHECK(neighbours[0] == p2->guid());
}

MINI_TEST("Session", "Get Collisions") {

    Session session;
    std::shared_ptr<OBB> obb1 = std::make_shared<OBB>(
        Point(0.0, 0.0, 0.0),
        Vector(1.0, 0.0, 0.0),
        Vector(0.0, 1.0, 0.0),
        Vector(0.0, 0.0, 1.0),
        Vector(2.0, 2.0, 2.0)
    );
    std::shared_ptr<OBB> obb2 = std::make_shared<OBB>(
        Point(1.0, 0.0, 0.0),
        Vector(1.0, 0.0, 0.0),
        Vector(0.0, 1.0, 0.0),
        Vector(0.0, 0.0, 1.0),
        Vector(2.0, 2.0, 2.0)
    );
    session.add_obb(obb1);
    session.add_obb(obb2);
    std::vector<std::pair<std::string, std::string>> pairs = session.get_collisions();

    MINI_CHECK(pairs.size() >= 1);
}

MINI_TEST("Session", "Ray Cast") {

    Session session;
    std::shared_ptr<Mesh> mesh = std::make_shared<Mesh>();
    mesh->add_vertex(Point(-1.0, -1.0, 0.0), 0);
    mesh->add_vertex(Point(1.0, -1.0, 0.0), 1);
    mesh->add_vertex(Point(0.0, 1.0, 0.0), 2);
    mesh->add_face(std::vector<size_t>{0, 1, 2});
    session.add_mesh(mesh);
    std::vector<Session::RayHit> hits = session.ray_cast(Point(0.0, 0.0, 2.0), Vector(0.0, 0.0, -1.0));

    MINI_CHECK(hits.size() >= 1);

    std::shared_ptr<Mesh> placed = std::make_shared<Mesh>();
    placed->add_vertex(Point(-1.0, -1.0, 0.0), 0);
    placed->add_vertex(Point(1.0, -1.0, 0.0), 1);
    placed->add_vertex(Point(0.0, 1.0, 0.0), 2);
    placed->add_face(std::vector<size_t>{0, 1, 2});
    std::string placed_guid = placed->guid();
    session.add_mesh(placed);
    session.set_xform(placed_guid, Xform::translation(100.0, 0.0, 0.0));
    std::vector<Session::RayHit> hits2 = session.ray_cast(Point(100.0, 0.0, 2.0), Vector(0.0, 0.0, -1.0));

    MINI_CHECK(hits2.size() >= 1);
    MINI_CHECK(TOLERANCE.is_close(hits2[0].hit_point[0], 100.0));
}

MINI_TEST("Session", "Get Object") {

    Session session;
    std::shared_ptr<Point> point = std::make_shared<Point>(1.0, 2.0, 3.0);
    session.add_point(point);

    std::shared_ptr<Point> retrieved = session.get_object<Point>(point->guid());

    MINI_CHECK(retrieved != nullptr);
    MINI_CHECK(retrieved->guid() == point->guid());
}

MINI_TEST("Session", "Remove Object") {

    Session session;
    std::shared_ptr<Point> point = std::make_shared<Point>(1.0, 2.0, 3.0);
    session.add_point(point);
    bool removed = session.remove_object(point->guid());

    std::shared_ptr<Element> plate = std::make_shared<Element>("p1");
    std::string eguid = plate->guid();
    session.add_element(plate);
    bool eremoved = session.remove_object(eguid);

    std::string fname = "serialization/test_session_remove.bin";
    session.pb_dump(fname);
    Session loaded = Session::pb_load(fname);

    MINI_CHECK(removed);
    MINI_CHECK(session.lookup.count(point->guid()) == 0);
    MINI_CHECK(eremoved);
    MINI_CHECK(session.objects.elements->size() == 0);
    MINI_CHECK(loaded.lookup.count(eguid) == 0);
}

MINI_TEST("Session", "Get Geometry") {

    Session session;
    std::shared_ptr<Point> point = std::make_shared<Point>(1.0, 2.0, 3.0);
    session.add_point(point);

    Objects geom = session.get_geometry();

    MINI_CHECK(geom.points->size() == 1);
}

MINI_TEST("Session", "Get Geometry Is Pure") {

    Session session;
    std::shared_ptr<Point> point = std::make_shared<Point>(1.0, 2.0, 3.0);
    std::string guid = point->guid();
    session.add_point(point);
    session.set_xform(guid, Xform::translation(10.0, 0.0, 0.0));

    Point first = *session.get_geometry().points->at(0);
    Point second = *session.get_geometry().points->at(0);

    MINI_CHECK(TOLERANCE.is_close(first[0], 11.0));
    MINI_CHECK(TOLERANCE.is_close(second[0], 11.0));
    MINI_CHECK(TOLERANCE.is_close((*point)[0], 1.0));
    MINI_CHECK(TOLERANCE.is_close((*session.objects.points->at(0))[0], 1.0));
}

MINI_TEST("Session", "Json Roundtrip") {

    Session session;
    std::shared_ptr<Point> p1 = std::make_shared<Point>(1.0, 2.0, 3.0);
    std::shared_ptr<Point> p2 = std::make_shared<Point>(4.0, 5.0, 6.0);
    session.add_point(p1);
    session.add_point(p2);
    session.add_edge(p1->guid(), p2->guid(), "connection");

    std::string fname = "serialization/test_session.json";
    session.file_json_dump(fname);
    Session loaded = Session::file_json_load(fname);

    MINI_CHECK(loaded.name == session.name);
    MINI_CHECK(loaded.lookup.size() == session.lookup.size());
    MINI_CHECK(loaded.graph.number_of_vertices() == session.graph.number_of_vertices());
}

MINI_TEST("Session", "Protobuf Roundtrip") {

    Session session;
    std::shared_ptr<Point> p1 = std::make_shared<Point>(1.0, 2.0, 3.0);
    std::shared_ptr<Point> p2 = std::make_shared<Point>(4.0, 5.0, 6.0);
    session.add_point(p1);
    session.add_point(p2);
    session.add_edge(p1->guid(), p2->guid(), "connection");

    std::string fname = "serialization/test_session.bin";
    session.pb_dump(fname);
    Session loaded = Session::pb_load(fname);

    MINI_CHECK(loaded.name == session.name);
    MINI_CHECK(loaded.lookup.size() == session.lookup.size());
}

MINI_TEST("Session", "Lookup Mutation Roundtrip") {

    Session session;
    std::shared_ptr<Line> line = std::make_shared<Line>(0.0, 0.0, 0.0, 1.0, 0.0, 0.0);
    std::string guid = line->guid();
    session.add_line(line);

    std::get<std::shared_ptr<Line>>(session.lookup[guid])->width = 5.0;

    std::string fname = "serialization/test_session_lookup.bin";
    session.pb_dump(fname);
    Session loaded = Session::pb_load(fname);

    MINI_CHECK(loaded.objects.lines->at(0)->width == 5.0);
    MINI_CHECK(std::get<std::shared_ptr<Line>>(loaded.lookup[guid])->width == 5.0);
}

MINI_TEST("Session", "Order") {

    Session session;
    std::shared_ptr<Line> line = std::make_shared<Line>(0.0, 0.0, 0.0, 1.0, 0.0, 0.0);
    std::shared_ptr<Point> point = std::make_shared<Point>(1.0, 2.0, 3.0);
    std::string line_guid = line->guid();
    std::string point_guid = point->guid();
    session.add_line(line);
    session.add_point(point);

    std::vector<std::string> order = session.order();

    std::string fname = "serialization/test_session_order.bin";
    session.pb_dump(fname);
    Session loaded = Session::pb_load(fname);

    MINI_CHECK(order.size() == 2);
    MINI_CHECK(order[0] == point_guid);
    MINI_CHECK(order[1] == line_guid);
    MINI_CHECK(loaded.order() == order);
}

MINI_TEST("Session", "Set Xform") {

    Session session;
    std::shared_ptr<Point> point = std::make_shared<Point>(1.0, 2.0, 3.0);
    std::string guid = point->guid();
    session.add_point(point);

    Xform shift = Xform::translation(5.0, 0.0, 0.0);
    session.set_xform(guid, shift);

    MINI_CHECK(session.xform(guid) == shift);
    MINI_CHECK(session.world_xform(guid) == shift);
    MINI_CHECK(session.world_xforms()[guid] == shift);
    MINI_CHECK(session.xform("missing") == Xform::identity());
    MINI_CHECK(session.remove_xform(guid));
    MINI_CHECK(session.xform(guid) == Xform::identity());
}

MINI_TEST("Session", "World Xform Hierarchy") {

    Session session;
    std::shared_ptr<Point> a = std::make_shared<Point>(0.0, 0.0, 0.0);
    std::shared_ptr<Point> b = std::make_shared<Point>(0.0, 0.0, 0.0);
    std::shared_ptr<Point> c = std::make_shared<Point>(0.0, 0.0, 0.0);
    std::string a_guid = a->guid();
    std::string b_guid = b->guid();
    std::string c_guid = c->guid();
    std::shared_ptr<TreeNode> a_node = session.add_point(a);
    std::shared_ptr<TreeNode> b_node = session.add_point(b);
    std::shared_ptr<TreeNode> c_node = session.add_point(c);

    session.add(a_node);
    session.add(b_node, a_node);
    session.add(c_node, b_node);

    Xform a_xform = Xform::rotation_z(Tolerance::PI / 2.0);
    Xform b_xform = Xform::translation(2.0, 0.0, 0.0);
    Xform c_xform = Xform::rotation_z(Tolerance::PI / 2.0);
    session.set_xform(a_guid, a_xform);
    session.set_xform(b_guid, b_xform);
    session.set_xform(c_guid, c_xform);

    std::unordered_map<std::string, Xform> world = session.world_xforms();

    MINI_CHECK(session.world_xform(a_guid) == a_xform);
    MINI_CHECK(session.world_xform(b_guid) == a_xform * b_xform);
    MINI_CHECK(session.world_xform(c_guid) == a_xform * b_xform * c_xform);
    MINI_CHECK(world[c_guid] == session.world_xform(c_guid));
}

MINI_TEST("Session", "Xform Roundtrip") {

    Session session;
    std::shared_ptr<Point> point = std::make_shared<Point>(1.0, 2.0, 3.0);
    std::string guid = point->guid();
    session.add_point(point);
    session.set_xform(guid, Xform::translation(7.0, 8.0, 9.0));

    std::string fname = "serialization/test_session_xform.bin";
    session.pb_dump(fname);
    Session loaded = Session::pb_load(fname);
    Session json_loaded = Session::file_json_loads(session.file_json_dumps());

    MINI_CHECK(loaded.xform(guid) == session.xform(guid));
    MINI_CHECK(loaded.xforms.size() == 1);
    MINI_CHECK(json_loaded.xform(guid) == session.xform(guid));
    MINI_CHECK(json_loaded.xforms.size() == 1);
}

/// A cube mesh of the given size centred on center.
static std::shared_ptr<Mesh> create_box(const Point& center, double size) {

    std::shared_ptr<Mesh> mesh = std::make_shared<Mesh>();
    const double h = size * 0.5;
    const std::vector<Point> verts = {
        Point(center[0] - h, center[1] - h, center[2] - h),
        Point(center[0] + h, center[1] - h, center[2] - h),
        Point(center[0] + h, center[1] + h, center[2] - h),
        Point(center[0] - h, center[1] + h, center[2] - h),
        Point(center[0] - h, center[1] - h, center[2] + h),
        Point(center[0] + h, center[1] - h, center[2] + h),
        Point(center[0] + h, center[1] + h, center[2] + h),
        Point(center[0] - h, center[1] + h, center[2] + h)
    };

    for (size_t i = 0; i < verts.size(); ++i)
        mesh->add_vertex(verts[i], i);

    const std::vector<std::vector<size_t>> faces =
        {{0, 1, 2, 3}, {4, 7, 6, 5}, {0, 4, 5, 1}, {2, 6, 7, 3}, {0, 3, 7, 4}, {1, 5, 6, 2}};

    for (const std::vector<size_t>& f : faces)
        mesh->add_face(f);

    return mesh;
}

MINI_TEST("Session", "Tree Transformation Hierarchy") {

    Session scene("tree_transformation_test");

    std::shared_ptr<Mesh> box1 = create_box(Point(0, 0, 0), 2.0);
    std::string box1_guid = box1->guid();
    std::shared_ptr<TreeNode> box1_node = scene.add_mesh(box1);
    std::shared_ptr<Mesh> box2 = create_box(Point(0, 0, 0), 2.0);
    std::string box2_guid = box2->guid();
    std::shared_ptr<TreeNode> box2_node = scene.add_mesh(box2);
    std::shared_ptr<Mesh> box3 = create_box(Point(0, 0, 0), 2.0);
    std::string box3_guid = box3->guid();
    std::shared_ptr<TreeNode> box3_node = scene.add_mesh(box3);

    scene.add(box1_node);
    scene.add(box2_node, box1_node);
    scene.add(box3_node, box2_node);

    Plane plane_from(Point(0, 0, 0), Vector(1, 0, 0), Vector(0, 1, 0));
    Plane plane_to(Point(0, 0, 1.0), Vector(1, 0, 0), Vector(0, 1, 0));
    Xform xy_to_top = Xform::plane_to_plane(plane_from, plane_to);
    scene.set_xform(box1_guid, Xform::rotation_z(Tolerance::PI / 1.5) * xy_to_top);
    scene.set_xform(box2_guid, Xform::translation(2.0, 0, 0) * Xform::rotation_z(Tolerance::PI / 6.0));
    scene.set_xform(box3_guid, Xform::translation(2.0, 0, 0));

    Xform world3 = scene.world_xform(box3_guid);
    Point expected = world3.transform_point(Point(-1.0, -1.0, -1.0));
    Objects transformed = scene.get_geometry();
    Point baked = *(*transformed.meshes)[2]->vertex_point(0);

    MINI_CHECK(transformed.meshes->size() == 3);
    MINI_CHECK(TOLERANCE.is_close(baked[0], expected[0]));
    MINI_CHECK(TOLERANCE.is_close(baked[1], expected[1]));
    MINI_CHECK(TOLERANCE.is_close(baked[2], expected[2]));
}

MINI_TEST("Session", "Add Component") {

    Session session;

    Component c;
    c.type_name = "FloorBuilder";
    c.name = "floor_builder";
    c.extra = {{"size", 3000}, {"height", 650}};
    std::string guid = c.guid();

    session.add_component(c);

    MINI_CHECK(session.objects.components->size() == 1);
    MINI_CHECK(session.component_lookup.count(guid) == 1);
    MINI_CHECK(session.graph.has_node(guid));
}

MINI_TEST("Session", "Component Json Roundtrip") {

    Session original;
    Component c;
    c.type_name = "FloorBuilder";
    c.name = "floor_builder";
    c.extra = {{"size", 3000}, {"height", 650}, {"rise", 453}};
    std::string guid = c.guid();
    original.add_component(c);

    std::string filename = "serialization/test_session_component.json";
    file_encoders::file_json_dump(original, filename);
    Session loaded = file_encoders::file_json_load<Session>(filename);

    MINI_CHECK(loaded.objects.components->size() == 1);
    MINI_CHECK(loaded.objects.components->at(0).type_name == "FloorBuilder");
    MINI_CHECK(loaded.objects.components->at(0).extra["size"] == 3000);
    MINI_CHECK(loaded.objects.components->at(0).guid() == guid);
}

MINI_TEST("Session", "Document Workflow") {

    Session session;
    std::shared_ptr<Point> a = std::make_shared<Point>(1.0, 0.0, 0.0);
    std::shared_ptr<Point> b = std::make_shared<Point>(2.0, 0.0, 0.0);
    std::shared_ptr<Point> c = std::make_shared<Point>(3.0, 0.0, 0.0);
    std::string a_guid = a->guid();
    std::string b_guid = b->guid();
    std::string c_guid = c->guid();
    session.add_point(a);
    session.add_point(b);
    session.add_point(c);

    session.replace(b_guid, std::make_shared<Point>(20.0, 0.0, 0.0));
    session.remove_object(c_guid);
    Xform shift = Xform::translation(0.0, 5.0, 0.0);
    session.set_xform(a_guid, shift);

    std::string fname = "serialization/test_session_document.bin";
    session.pb_dump(fname);
    Session loaded = Session::pb_load(fname);

    MINI_CHECK(loaded.lookup.size() == 2);
    MINI_CHECK(loaded.lookup.count(a_guid) == 1);
    MINI_CHECK(loaded.lookup.count(b_guid) == 1);
    MINI_CHECK(loaded.lookup.count(c_guid) == 0);
    MINI_CHECK(TOLERANCE.is_close((*std::get<std::shared_ptr<Point>>(loaded.lookup[b_guid]))[0], 20.0));
    MINI_CHECK(loaded.xform(a_guid) == shift);
    MINI_CHECK(loaded.history.depth() == 0);
}

MINI_TEST("Session", "Undo Remove") {

    Session session;
    std::shared_ptr<TreeNode> group = session.add_group("g");
    std::shared_ptr<Point> a = std::make_shared<Point>(1.0, 0.0, 0.0);
    std::shared_ptr<Point> b = std::make_shared<Point>(2.0, 0.0, 0.0);
    std::shared_ptr<Point> c = std::make_shared<Point>(3.0, 0.0, 0.0);
    std::string a_guid = a->guid();
    std::string b_guid = b->guid();
    std::string c_guid = c->guid();
    session.add_point(a, group);
    std::shared_ptr<TreeNode> b_node = session.add_point(b, group);
    session.add_point(c, b_node);
    session.add_edge(a_guid, b_guid, "connection");
    Xform shift = Xform::translation(0.0, 5.0, 0.0);
    session.set_xform(b_guid, shift);

    session.begin("remove");
    session.remove_object(b_guid);
    session.commit();
    bool gone = session.lookup.count(b_guid) == 0 && group->children().size() == 1;
    session.undo();

    MINI_CHECK(gone);
    MINI_CHECK(session.lookup.count(b_guid) == 1);
    MINI_CHECK(session.objects.points->at(1)->guid() == b_guid);
    MINI_CHECK(group->children()[1]->name == b_guid);
    MINI_CHECK(group->children()[1]->children()[0]->name == c_guid);
    MINI_CHECK(session.graph.has_edge({a_guid, b_guid}));
    MINI_CHECK(session.graph.edge_attribute(a_guid, b_guid) == "connection");
    MINI_CHECK(session.xform(b_guid) == shift);

    session.redo();

    MINI_CHECK(session.lookup.count(b_guid) == 0);
    MINI_CHECK(session.objects.points->size() == 2);
    MINI_CHECK(group->children().size() == 1);
    MINI_CHECK(!session.graph.has_edge({a_guid, b_guid}));
    MINI_CHECK(session.xform(b_guid) == Xform::identity());
}

MINI_TEST("Session", "Undo Add") {

    Session session;
    std::shared_ptr<TreeNode> group = session.add_group("g");
    session.add_point(std::make_shared<Point>(0.0, 0.0, 0.0), group);
    std::shared_ptr<Point> point = std::make_shared<Point>(1.0, 2.0, 3.0);
    std::string guid = point->guid();

    session.begin("add");
    session.add_point(point, group);
    session.commit();
    session.undo();
    bool gone = session.lookup.count(guid) == 0 && session.objects.points->size() == 1;
    session.redo();

    MINI_CHECK(gone);
    MINI_CHECK(session.lookup.count(guid) == 1);
    MINI_CHECK(session.objects.points->at(1)->guid() == guid);
    MINI_CHECK(group->children()[1]->name == guid);
    MINI_CHECK(session.graph.has_node(guid));
    MINI_CHECK(TOLERANCE.is_close((*std::get<std::shared_ptr<Point>>(session.lookup[guid]))[2], 3.0));
}

MINI_TEST("Session", "Undo Replace") {

    Session session;
    std::shared_ptr<Point> point = std::make_shared<Point>(1.0, 2.0, 3.0);
    std::string guid = point->guid();
    session.add_point(point);

    session.begin("replace");
    session.replace(guid, std::make_shared<Point>(9.0, 9.0, 9.0));
    session.commit();
    double replaced = (*std::get<std::shared_ptr<Point>>(session.lookup[guid]))[0];
    session.undo();
    double restored = (*std::get<std::shared_ptr<Point>>(session.lookup[guid]))[0];
    session.redo();

    MINI_CHECK(TOLERANCE.is_close(replaced, 9.0));
    MINI_CHECK(TOLERANCE.is_close(restored, 1.0));
    MINI_CHECK(TOLERANCE.is_close((*std::get<std::shared_ptr<Point>>(session.lookup[guid]))[0], 9.0));
    MINI_CHECK(session.objects.points->at(0)->guid() == guid);
    MINI_CHECK(session.objects.points->size() == 1);
}

MINI_TEST("Session", "Undo Xform") {

    Session session;
    std::shared_ptr<Point> point = std::make_shared<Point>(1.0, 2.0, 3.0);
    std::string guid = point->guid();
    session.add_point(point);
    Xform shift = Xform::translation(5.0, 0.0, 0.0);

    session.begin("move");
    session.set_xform(guid, shift);
    session.commit();
    session.undo();
    bool cleared = session.xform(guid) == Xform::identity();
    session.redo();

    session.begin("reset");
    session.remove_xform(guid);
    session.commit();
    session.undo();

    MINI_CHECK(cleared);
    MINI_CHECK(session.xform(guid) == shift);
    MINI_CHECK(session.xforms.size() == 1);
}

MINI_TEST("Session", "History Purged On Save") {

    Session session;

    session.begin("add");
    session.add_point(std::make_shared<Point>(0.0, 0.0, 0.0));
    session.commit();
    int before_pb = session.history.depth();
    session.pb_dumps();
    int after_pb = session.history.depth();

    session.begin("add");
    session.add_point(std::make_shared<Point>(1.0, 0.0, 0.0));
    session.commit();
    int before_json = session.history.depth();
    session.file_json_dumps();

    MINI_CHECK(before_pb == 1);
    MINI_CHECK(after_pb == 0);
    MINI_CHECK(before_json == 1);
    MINI_CHECK(session.history.depth() == 0);
    MINI_CHECK(!session.undo());
    MINI_CHECK(session.objects.points->size() == 2);
}

MINI_TEST("Session", "History Capacity") {

    Session session;

    for (int i = 0; i < 70; ++i) {
        session.begin("add");
        session.add_point(std::make_shared<Point>(double(i), 0.0, 0.0));
        session.commit();
    }

    int depth = session.history.depth();

    while (session.undo()) {
    }

    MINI_CHECK(depth == 64);
    MINI_CHECK(!session.history.can_undo());
    MINI_CHECK(session.objects.points->size() == 6);
    MINI_CHECK(TOLERANCE.is_close((*session.objects.points->at(5))[0], 5.0));
}

} // namespace session_cpp
