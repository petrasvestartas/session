#include "vector.h"
#include "point.h"
#include "tolerance.h"
#include <algorithm>
#include <limits>
#include <cmath>
#include <fstream>

#include "vector.pb.h"

namespace session_cpp {

// ═══════════════════════════════════════════════════════════════════════════
// Operators
// ═══════════════════════════════════════════════════════════════════════════

/// Simple string form (like Python __str__): just coordinates
std::string Vector::str() const {
  int prec = static_cast<int>(Tolerance::ROUNDING);
  return fmt::format(
      "{}, {}, {}",
      TOLERANCE.format_number(_x, prec),
      TOLERANCE.format_number(_y, prec),
      TOLERANCE.format_number(_z, prec));
}

/// Detailed representation (like Python __repr__)
std::string Vector::repr() {
  int prec = static_cast<int>(Tolerance::ROUNDING);
  return fmt::format(
      "Vector({}, {}, {}, {}, {})",
      name,
      TOLERANCE.format_number(_x, prec),
      TOLERANCE.format_number(_y, prec),
      TOLERANCE.format_number(_z, prec),
      TOLERANCE.format_number(magnitude(), prec));
}

/// Equality operator (compares name and coordinates with tolerance, excludes guid())
bool Vector::operator==(const Vector &other) const {
  return name == other.name &&
         std::round(_x * 1000000.0) == std::round(other._x * 1000000.0) &&
         std::round(_y * 1000000.0) == std::round(other._y * 1000000.0) &&
         std::round(_z * 1000000.0) == std::round(other._z * 1000000.0);
}

/// Inequality operator
bool Vector::operator!=(const Vector &other) const { return !(*this == other); }

// ═══════════════════════════════════════════════════════════════════════════
// No-copy operators
// ═══════════════════════════════════════════════════════════════════════════

double &Vector::operator[](int index) {
  invalidate_magnitude_cache();
  if (index == 0)
    return _x;
  if (index == 1)
    return _y;
  return _z; // assume index == 2
}

const double &Vector::operator[](int index) const {
  if (index == 0)
    return _x;
  if (index == 1)
    return _y;
  return _z; // assume index == 2
}

Vector &Vector::operator*=(double factor) {
  (*this)[0] = _x * factor;
  (*this)[1] = _y * factor;
  (*this)[2] = _z * factor;
  return *this;
}

Vector &Vector::operator/=(double factor) {
  (*this)[0] = _x / factor;
  (*this)[1] = _y / factor;
  (*this)[2] = _z / factor;
  return *this;
}

Vector &Vector::operator+=(const Vector &other) {
  (*this)[0] = _x + other[0];
  (*this)[1] = _y + other[1];
  (*this)[2] = _z + other[2];
  return *this;
}

Vector &Vector::operator-=(const Vector &other) {
  (*this)[0] = _x - other[0];
  (*this)[1] = _y - other[1];
  (*this)[2] = _z - other[2];
  return *this;
}

// ═══════════════════════════════════════════════════════════════════════════
// Copy operators
// ═══════════════════════════════════════════════════════════════════════════

Vector Vector::operator*(double factor) const { return Vector(_x * factor, _y * factor, _z * factor); }

Vector Vector::operator/(double factor) const { return Vector(_x / factor, _y / factor, _z / factor); }

Vector Vector::operator+(const Vector &other) const {
  return Vector(_x + other._x, _y + other._y, _z + other._z);
}

Vector Vector::operator-(const Vector &other) const {
  return Vector(_x - other._x, _y - other._y, _z - other._z);
}

Vector Vector::operator-() const { return Vector(-_x, -_y, -_z); }

Vector operator*(double factor, const Vector &v) { return v * factor; }

// ═══════════════════════════════════════════════════════════════════════════
// JSON
// ═══════════════════════════════════════════════════════════════════════════

/// Convert to JSON-serializable object (alphabetical order to match Rust)
nlohmann::ordered_json Vector::jsondump() const {
  auto clean_float = [](double val) -> double { return std::round(val * 100.0) / 100.0; };
  nlohmann::ordered_json data;
  data["guid"] = guid();
  data["name"] = name;
  data["type"] = "Vector";
  data["x"] = clean_float(_x);
  data["y"] = clean_float(_y);
  data["z"] = clean_float(_z);
  return data;
}

/// Create vector from JSON data
Vector Vector::jsonload(const nlohmann::json &data) {
  Vector vector(data["x"], data["y"], data["z"]);
  vector.guid() = data["guid"];
  vector.name = data["name"];
  return vector;
}

std::string Vector::file_json_dumps() const {
    return jsondump().dump();
}

Vector Vector::file_json_loads(const std::string& json_string) {
    return jsonload(nlohmann::ordered_json::parse(json_string));
}

/// Serialize to JSON file
void Vector::file_json_dump(const std::string& filename) const {
  std::ofstream ofs(filename);
  ofs << jsondump().dump(4);
  ofs.close();
}

/// Deserialize from JSON file
Vector Vector::file_json_load(const std::string& filename) {
  std::ifstream ifs(filename);
  nlohmann::json data = nlohmann::json::parse(ifs);
  ifs.close();
  return jsonload(data);
}

// ═══════════════════════════════════════════════════════════════════════════
// Protobuf Serialization
// ═══════════════════════════════════════════════════════════════════════════

std::string Vector::pb_dumps() const {
  session_proto::Vector proto;
  proto.set_x(_x);
  proto.set_y(_y);
  proto.set_z(_z);
  proto.set_name(name);
  return proto.SerializeAsString();
}

Vector Vector::pb_loads(const std::string& data) {
  session_proto::Vector proto;
  proto.ParseFromString(data);
  Vector v(proto.x(), proto.y(), proto.z());
  v.name = proto.name();
  return v;
}

void Vector::pb_dump(const std::string& filename) const {
  std::ofstream ofs(filename, std::ios::binary);
  ofs << pb_dumps();
  ofs.close();
}

Vector Vector::pb_load(const std::string& filename) {
  std::ifstream ifs(filename, std::ios::binary);
  std::string data((std::istreambuf_iterator<char>(ifs)),
                    std::istreambuf_iterator<char>());
  ifs.close();
  return pb_loads(data);
}

// ═══════════════════════════════════════════════════════════════════════════
// Transform
// ═══════════════════════════════════════════════════════════════════════════

void Vector::transform(const Xform& xform) {
  double x = _x, y = _y, z = _z;
  _x = xform.m[0]*x + xform.m[4]*y + xform.m[8]*z;
  _y = xform.m[1]*x + xform.m[5]*y + xform.m[9]*z;
  _z = xform.m[2]*x + xform.m[6]*y + xform.m[10]*z;
}

Vector Vector::transformed(const Xform& xform) const {
  Vector result = *this;
  result.transform(xform);
  return result;
}

// ═══════════════════════════════════════════════════════════════════════════
// Static methods
// ═══════════════════════════════════════════════════════════════════════════

Vector Vector::zero() { return Vector(0.0, 0.0, 0.0); }
Vector Vector::x_axis() { return Vector(1.0, 0.0, 0.0); }
Vector Vector::y_axis() { return Vector(0.0, 1.0, 0.0); }
Vector Vector::z_axis() { return Vector(0.0, 0.0, 1.0); }

Vector Vector::from_points(const Point &p0, const Point &p1) {
  return Vector(p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]);
}

// ═══════════════════════════════════════════════════════════════════════════
// Details / Geometry
// ═══════════════════════════════════════════════════════════════════════════

void Vector::reverse() {
  _x = -_x;
  _y = -_y;
  _z = -_z;
  // Length magnitude stays the same, no need to invalidate cache
}

double Vector::compute_magnitude() const {
  double mag = 0.0;

  double ax = std::abs(_x);
  double ay = std::abs(_y);
  double az = std::abs(_z);

  const bool x_zero = ax < static_cast<double>(session_cpp::Tolerance::ZERO_TOLERANCE);
  const bool y_zero = ay < static_cast<double>(session_cpp::Tolerance::ZERO_TOLERANCE);
  const bool z_zero = az < static_cast<double>(session_cpp::Tolerance::ZERO_TOLERANCE);

  if (x_zero && y_zero && z_zero)
    return 0.0;
  else if (x_zero && y_zero)
    return az;
  else if (x_zero && z_zero)
    return ay;
  else if (y_zero && z_zero)
    return ax;

  // Ensure ax is the largest
  if (ay >= ax && ay >= az) {
    std::swap(ax, ay);
  } else if (az >= ax && az >= ay) {
    std::swap(ax, az);
  }

  if (ax > std::numeric_limits<double>::min()) {
    ay /= ax;
    az /= ax;
    mag = ax * std::sqrt(1.0 + ay * ay + az * az);
  } else if (ax > 0.0 && session_cpp::is_finite(ax)) {
    mag = ax;
  } else {
    mag = 0.0;
  }

  return mag;
}

double Vector::cached_magnitude() const {
  if (!_has_magnitude) {
    _magnitude = compute_magnitude();
    _has_magnitude = true;
  }
  return _magnitude;
}

double Vector::magnitude() const { return cached_magnitude(); }

double Vector::magnitude_squared() const {
  return _x * _x + _y * _y + _z * _z;
}

bool Vector::normalize_self() {
  double d = compute_magnitude();
  if (d > 0.0) {
    (*this)[0] = _x / d;
    (*this)[1] = _y / d;
    (*this)[2] = _z / d;
    _magnitude = 1.0;
    _has_magnitude = true;
    return true;
  }
  return false;
}

Vector Vector::normalized() const {
  Vector result(_x, _y, _z);
  result.normalize_self();
  return result;
}

std::tuple<Vector, double, Vector, double>
Vector::projection(Vector &projection_vector, double tolerance) {
  double projection_vector_length = projection_vector.magnitude();

  if (projection_vector_length < tolerance) {
    return {Vector(0, 0, 0), 0.0, Vector(0, 0, 0), 0.0};
  }

  Vector projection_vector_unit(
      projection_vector._x / projection_vector_length,
      projection_vector._y / projection_vector_length,
      projection_vector._z / projection_vector_length);

  double projected_vector_length = this->dot(projection_vector_unit);
  Vector out_projection_vector = projection_vector_unit * projected_vector_length;

  Vector out_perpendicular_projected_vector = *this - out_projection_vector;
  double out_perpendicular_projected_vector_length = out_perpendicular_projected_vector.magnitude();

  return {out_projection_vector,
          projected_vector_length,
          out_perpendicular_projected_vector,
          out_perpendicular_projected_vector_length};
}

int Vector::is_parallel_to(const Vector &other) {
  static const double cos_tol = std::cos(
      static_cast<double>(Tolerance::ANGLE_TOLERANCE_DEGREES) *
      static_cast<double>(Tolerance::TO_RADIANS));

  double ll = cached_magnitude() * other.cached_magnitude();
  if (ll <= 0.0) return 0;

  double cos_angle = ((*this)[0] * other[0] + (*this)[1] * other[1] + (*this)[2] * other[2]) / ll;
  if (cos_angle >= cos_tol) return 1;
  if (cos_angle <= -cos_tol) return -1;
  return 0;
}

double Vector::dot(const Vector &other) const {
  double result = 0.0;
  for (int i = 0; i < 3; ++i) {
    result += (*this)[i] * other[i];
  }
  return result;
}

Vector Vector::cross(const Vector &other) const {
  double cx = (*this)[1] * other[2] - (*this)[2] * other[1];
  double cy = (*this)[2] * other[0] - (*this)[0] * other[2];
  double cz = (*this)[0] * other[1] - (*this)[1] * other[0];
  return Vector(cx, cy, cz);
}

double Vector::angle(const Vector &other, bool sign_by_cross_product, bool degrees,
                     double tolerance) {
  double dotp = this->dot(other);
  double len0 = this->cached_magnitude();
  double len1 = other.cached_magnitude();
  double denom = len0 * len1;
  if (denom < tolerance) {
    return 0.0;
  }
  double cos_angle = dotp / denom;
  cos_angle = std::max(-1.0, std::min(1.0, cos_angle));
  double ang = std::acos(cos_angle);
  if (sign_by_cross_product) {
    Vector cp = this->cross(other);
    if (cp._z < 0)
      ang = -ang;
  }
  double to_degrees = degrees ? static_cast<double>(Tolerance::TO_DEGREES) : 1.0;
  return ang * to_degrees;
}

Vector Vector::get_leveled_vector(double &vertical_height) {
  Vector copy(_x, _y, _z);
  if (copy.normalize_self()) {
    Vector reference(0, 0, 1);
    double angle_deg = copy.angle(reference, false); // returns degrees (unsigned)
    double angle_rad = angle_deg * static_cast<double>(Tolerance::TO_RADIANS);
    double inclined_offset_by_vertical_distance = vertical_height / std::cos(angle_rad);
    copy *= inclined_offset_by_vertical_distance;
  }
  return copy;
}

double Vector::cosine_law(double &a, double &b, double &ang_between, bool degrees) {
  double to_rad = degrees ? static_cast<double>(Tolerance::TO_RADIANS) : 1.0;
  return std::sqrt(a * a + b * b - 2.0 * a * b * std::cos(ang_between * to_rad));
}

double Vector::sine_law_angle(double &a, double &A, double &b, bool degrees) {
  double to_rad = degrees ? static_cast<double>(Tolerance::TO_RADIANS) : 1.0;
  double to_deg = degrees ? static_cast<double>(Tolerance::TO_DEGREES) : 1.0;
  return std::asin((b * std::sin(A * to_rad)) / a) * to_deg;
}

double Vector::sine_law_length(double &a, double &A, double &B, bool degrees) {
  double to_rad = degrees ? static_cast<double>(Tolerance::TO_RADIANS) : 1.0;
  return (a * std::sin(B * to_rad)) / std::sin(A * to_rad);
}

double Vector::angle_from_cosine_law(double a, double b, double c, bool degrees) {
  // cos(C) = (a² + b² - c²) / (2ab)
  double cos_c = (a * a + b * b - c * c) / (2.0 * a * b);
  double angle_rad = std::acos(cos_c);
  if (degrees) {
    return angle_rad * static_cast<double>(Tolerance::TO_DEGREES);
  }
  return angle_rad;
}

double Vector::side_from_sine_law(double angle_in_front_of_result_side,
                                  double angle_in_front_of_known_side,
                                  double known_side_length,
                                  bool degrees) {
  double to_rad = degrees ? static_cast<double>(Tolerance::TO_RADIANS) : 1.0;
  double angle_a = angle_in_front_of_result_side * to_rad;
  double angle_b = angle_in_front_of_known_side * to_rad;
  // a = b·sin(A)/sin(B)
  return (known_side_length * std::sin(angle_a)) / std::sin(angle_b);
}

double Vector::angle_between_vector_xy_components(Vector &vector) {
  return std::atan2(vector[1], vector[0]) * static_cast<double>(Tolerance::TO_DEGREES);
}

Vector Vector::sum_of_vectors(std::vector<Vector> &vectors) {
  double sx = 0, sy = 0, sz = 0;
  for (const auto &v : vectors) {
    sx += v[0];
    sy += v[1];
    sz += v[2];
  }
  return Vector(sx, sy, sz);
}

Vector Vector::average(std::vector<Vector> &vectors) {
  if (vectors.empty()) {
    return Vector::zero();
  }
  Vector sum = sum_of_vectors(vectors);
  double count = static_cast<double>(vectors.size());
  return Vector(sum[0] / count, sum[1] / count, sum[2] / count);
}

bool Vector::is_perpendicular_to(const Vector &other) const {
  return std::fabs(dot(other)) < static_cast<double>(Tolerance::ZERO_TOLERANCE);
}

bool Vector::is_zero() const {
  return compute_magnitude() < static_cast<double>(Tolerance::ZERO_TOLERANCE);
}

std::array<double, 3> Vector::coordinate_direction_3angles(bool degrees) {
  double x_coord = _x;
  double y_coord = _y;
  double z_coord = _z;
  double r = std::sqrt(x_coord * x_coord + y_coord * y_coord + z_coord * z_coord);
  
  if (r == 0) {
    return {0, 0, 0};
  }
  
  // unit vector proportions
  double x_proportion = x_coord / r;
  double y_proportion = y_coord / r;
  double z_proportion = z_coord / r;
  
  // angles
  double alpha = std::acos(x_proportion);
  double beta = std::acos(y_proportion);
  double gamma = std::acos(z_proportion);
  
  if (degrees) {
    alpha = alpha * static_cast<double>(Tolerance::TO_DEGREES);
    beta = beta * static_cast<double>(Tolerance::TO_DEGREES);
    gamma = gamma * static_cast<double>(Tolerance::TO_DEGREES);
  }
  
  return {alpha, beta, gamma};
}

std::array<double, 2> Vector::coordinate_direction_2angles(bool degrees) {
  double x_coord = _x;
  double y_coord = _y;
  double z_coord = _z;
  double r = std::sqrt(x_coord * x_coord + y_coord * y_coord + z_coord * z_coord);
  
  if (r == 0) {
    return {0, 0};
  }
  
  // spherical coordinates
  double phi = std::acos(z_coord / r);
  double theta = std::atan2(y_coord, x_coord);
  
  if (degrees) {
    phi = phi * static_cast<double>(Tolerance::TO_DEGREES);
    theta = theta * static_cast<double>(Tolerance::TO_DEGREES);
  }
  
  return {phi, theta};
}

bool Vector::perpendicular_to(Vector &v) {
  int i, j, k;
  double a, b;
  k = 2;
  if (std::fabs(v[1]) > std::fabs(v[0])) {
    if (std::fabs(v[2]) > std::fabs(v[1])) {
      // |v[2]| > |v[1]| > |v[0]|
      i = 2; j = 1; k = 0; a = v[2]; b = -v[1];
    } else if (std::fabs(v[2]) >= std::fabs(v[0])) {
      // |v[1]| >= |v[2]| >= |v[0]|
      i = 1; j = 2; k = 0; a = v[1]; b = -v[2];
    } else {
      // |v[1]| > |v[0]| > |v[2]|
      i = 1; j = 0; k = 2; a = v[1]; b = -v[0];
    }
  } else if (std::fabs(v[2]) > std::fabs(v[0])) {
    // |v[2]| > |v[0]| >= |v[1]|
    i = 2; j = 0; k = 1; a = v[2]; b = -v[0];
  } else if (std::fabs(v[2]) > std::fabs(v[1])) {
    // |v[0]| >= |v[2]| > |v[1]|
    i = 0; j = 2; k = 1; a = v[0]; b = -v[2];
  } else {
    // |v[0]| >= |v[1]| >= |v[2]|
    i = 0; j = 1; k = 2; a = v[0]; b = -v[1];
  }

  double arr[3] = {_x, _y, _z};
  arr[i] = b;
  arr[j] = a;
  arr[k] = 0.0;
  (*this)[0] = arr[0];
  (*this)[1] = arr[1];
  (*this)[2] = arr[2];
  return (a != 0.0) ? true : false;
}

void Vector::scale(double factor) {
  (*this)[0] = _x * factor;
  (*this)[1] = _y * factor;
  (*this)[2] = _z * factor;
}

void Vector::scale_up() { scale(static_cast<double>(session_cpp::SCALE)); }

void Vector::scale_down() { scale(1.0 / static_cast<double>(session_cpp::SCALE)); }

Vector Vector::reflect(const Vector& plane_normal) const {
    double d = this->dot(plane_normal);
    return Vector(
        _x - 2.0 * d * plane_normal[0],
        _y - 2.0 * d * plane_normal[1],
        _z - 2.0 * d * plane_normal[2]
    );
}

Vector Vector::average_normal(const std::vector<Point>& points) {
    constexpr double DISTANCE_SQUARED = 1e-10;
    double dx = points.back()[0] - points.front()[0];
    double dy = points.back()[1] - points.front()[1];
    double dz = points.back()[2] - points.front()[2];
    size_t len = (dx*dx + dy*dy + dz*dz) < DISTANCE_SQUARED ? points.size()-1 : points.size();
    Vector out(0, 0, 0);
    for (size_t i = 0; i < len; i++) {
        size_t prev = ((int)i - 1 + len) % len;
        size_t next = (i + 1) % len;
        double ax = points[i][0]-points[prev][0], ay = points[i][1]-points[prev][1], az = points[i][2]-points[prev][2];
        double bx = points[next][0]-points[i][0],  by = points[next][1]-points[i][1],  bz = points[next][2]-points[i][2];
        out[0] += ay*bz - az*by;
        out[1] += az*bx - ax*bz;
        out[2] += ax*by - ay*bx;
    }
    out.normalize_self();
    return out;
}


// ═══════════════════════════════════════════════════════════════════════════
// Stream operator
// ═══════════════════════════════════════════════════════════════════════════

std::ostream &operator<<(std::ostream &os, const Vector &point) {
  return os << point.str();
}

} // namespace session_cpp