#include "nurbssurface.h"
#include "nurbssurface_trimmed.h"
#include "intersection.h"
#include "closest.h"
#include "line.h"
#include "brep.h"
#include <array>
#include "remesh_nurbssurface_grid.h"
#include "remesh_nurbssurface_adaptive.h"
#include "nurbsknot.h"
#include "fmt/core.h"
#include <cstring>
#include <fstream>
#include <limits>
#include <numeric>
#include <stdexcept>
#include "nurbssurface.pb.h"

namespace session_cpp {

// ═══════════════════════════════════════════════════════════════════════════
// Anonymous Namespace Helper Functions
// ═══════════════════════════════════════════════════════════════════════════

namespace {

// Check if nurbsknot vector is clamped
bool is_nurbsknot_vector_clamped(int order, int cv_count, const std::vector<double>& nurbsknot) {
    if (order < 2 || cv_count < order) return false;
    if (static_cast<int>(nurbsknot.size()) != order + cv_count - 2) return false;

    int degree = order - 1;

    // OpenNURBS convention: first (order-1) nurbsknots equal, last (order-1) nurbsknots equal
    // Check start: nurbsknot[0] == nurbsknot[1] == ... == nurbsknot[degree-1]
    for (int i = 1; i < degree; i++) {
        if (std::abs(nurbsknot[i] - nurbsknot[0]) > 1e-10) return false;
    }

    // Check end: nurbsknot[last] == nurbsknot[last-1] == ... == nurbsknot[last-degree+1]
    int last = static_cast<int>(nurbsknot.size()) - 1;
    for (int i = last - 1; i > last - degree; i--) {
        if (std::abs(nurbsknot[i] - nurbsknot[last]) > 1e-10) return false;
    }

    return true;
}

// Check if nurbsknot vector is periodic
bool is_nurbsknot_vector_periodic(int order, int cv_count, const std::vector<double>& nurbsknot) {
    if (order < 2 || cv_count < order) return false;
    if (static_cast<int>(nurbsknot.size()) != order + cv_count - 2) return false;

    int degree = order - 1;
    double delta = nurbsknot[cv_count - 1] - nurbsknot[degree];

    if (delta <= 0.0) return false;

    for (int i = 0; i < cv_count - 1; i++) {
        double expected = nurbsknot[i + degree] + delta;
        if (std::abs(nurbsknot[i + order - 1] - expected) > 1e-10 * (1.0 + std::abs(expected))) {
            return false;
        }
    }

    return true;
}

// Check if points are coincident
bool points_are_coincident(int dim, bool is_rat, const double* p, const double* q) {
    if (!p || !q) return false;

    const double tolerance = 1.0e-12;

    if (is_rat) {
        double pw = p[dim];
        double qw = q[dim];

        if (std::abs(pw) < tolerance && std::abs(qw) < tolerance) return true;
        if (std::abs(pw) < tolerance || std::abs(qw) < tolerance) return false;

        for (int i = 0; i < dim; i++) {
            double a = p[i] / pw;
            double b = q[i] / qw;
            if (std::abs(a - b) > tolerance) return false;
        }
        return true;
    } else {
        for (int i = 0; i < dim; i++) {
            if (std::abs(p[i] - q[i]) > tolerance) return false;
        }
        return true;
    }
}

// Check if multiple points are coincident
bool points_are_coincident(int dim, bool is_rat, int count, int stride, const double* points) {
    if (count < 2 || !points) return true;

    const double* p0 = points;
    for (int i = 1; i < count; i++) {
        const double* pi = points + i * stride;
        if (!points_are_coincident(dim, is_rat, p0, pi)) {
            return false;
        }
    }
    return true;
}

// Check if point grid is closed in a direction
bool is_point_grid_closed(int dim, bool is_rat,
                          int count_0, int count_1,
                          int stride_0, int stride_1,
                          const double* cv, int dir) {
    if (dir < 0 || dir > 1) return false;

    int perpendicular_count = (dir == 0) ? count_1 : count_0;
    int perpendicular_stride = (dir == 0) ? stride_1 : stride_0;
    int parallel_stride = (dir == 0) ? stride_0 : stride_1;
    int parallel_count = (dir == 0) ? count_0 : count_1;

    const double* start_row = cv;
    const double* end_row = cv + (parallel_count - 1) * parallel_stride;

    for (int i = 0; i < perpendicular_count; i++) {
        if (!points_are_coincident(dim, is_rat, start_row, end_row)) {
            return false;
        }
        start_row += perpendicular_stride;
        end_row += perpendicular_stride;
    }

    return true;
}

// Helper: Convert surface to curve (for editing operations)
NurbsCurve* to_curve_internal(const NurbsSurface& srf, int dir, NurbsCurve* crv) {
    if (dir < 0 || dir > 1) return nullptr;
    if (srf.m_cv.empty()) return nullptr;

    if (!crv) {
        crv = new NurbsCurve();
    }

    int srf_cv_size = srf.cv_size();

    // Create curve with high dimension (srf_cv_size * perpendicular CV count)
    if (!crv->create(srf_cv_size * srf.m_cv_count[1 - dir], false,
                     srf.m_order[dir], srf.m_cv_count[dir])) {
        return nullptr;
    }

    // Copy CVs from surface to curve
    for (int i = 0; i < srf.m_cv_count[dir]; i++) {
        double* pdst = crv->cv(i);
        const double* psrc = dir ? srf.cv(0, i) : srf.cv(i, 0);

        for (int j = 0; j < srf.m_cv_count[1 - dir]; j++) {
            std::memcpy(pdst, psrc, srf_cv_size * sizeof(double));
            psrc += srf.m_cv_stride[1 - dir];
            pdst += srf_cv_size;
        }
    }

    // Copy nurbsknot vector
    for (int i = 0; i < crv->nurbsknot_count(); i++) {
        crv->set_nurbsknot(i, srf.nurbsknot(dir, i));
    }

    return crv;
}

// Helper: Convert curve back to surface (after editing)
bool from_curve_internal(NurbsCurve& crv, NurbsSurface& srf, int dir) {
    if (dir < 0 || dir > 1) return false;
    if (crv.m_cv.empty()) return false;
    if (crv.m_is_rat) return false;

    int srf_cv_size = srf.cv_size();
    if (srf.m_cv_count[1 - dir] * srf_cv_size != crv.m_dim) {
        return false;
    }

    // Transfer CV array from curve to surface
    srf.m_cv = std::move(crv.m_cv);

    // Transfer nurbsknot vector from curve to surface
    srf.m_nurbsknot[dir] = std::move(crv.m_nurbsknot);

    // Update surface parameters
    srf.m_order[dir] = crv.m_order;
    srf.m_cv_count[dir] = crv.m_cv_count;
    srf.m_cv_stride[dir] = crv.m_cv_stride;
    srf.m_cv_stride[1 - dir] = srf_cv_size;

    return true;
}

} // anonymous namespace

// ═══════════════════════════════════════════════════════════════════════════
// Static Factory Method
// ═══════════════════════════════════════════════════════════════════════════

NurbsSurface NurbsSurface::create(bool periodic_u, bool periodic_v,
                                  int degree_u, int degree_v,
                                  int cv_count_u, int cv_count_v,
                                  const std::vector<Point>& points) {
    if (degree_u < 1 || degree_v < 1)
        throw std::invalid_argument(
            fmt::format("NurbsSurface::create: degree must be >= 1, got degree_u={}, degree_v={}",
                        degree_u, degree_v));
    if (cv_count_u < degree_u + 1)
        throw std::invalid_argument(
            fmt::format("NurbsSurface::create: cv_count_u ({}) must be >= degree_u+1 ({})",
                        cv_count_u, degree_u + 1));
    if (cv_count_v < degree_v + 1)
        throw std::invalid_argument(
            fmt::format("NurbsSurface::create: cv_count_v ({}) must be >= degree_v+1 ({})",
                        cv_count_v, degree_v + 1));
    int expected = cv_count_u * cv_count_v;
    if (static_cast<int>(points.size()) != expected)
        throw std::invalid_argument(
            fmt::format("NurbsSurface::create: expected {} points ({}x{}), got {}",
                        expected, cv_count_u, cv_count_v, static_cast<int>(points.size())));
    NurbsSurface surface;

    int order0 = degree_u + 1;
    int order1 = degree_v + 1;

    surface.create_raw(3, false, order0, order1, cv_count_u, cv_count_v,
                       periodic_u, periodic_v, 1.0, 1.0);

    for (int i = 0; i < cv_count_u; i++) {
        for (int j = 0; j < cv_count_v; j++) {
            surface.set_cv(i, j, points[i * cv_count_v + j]);
        }
    }

    return surface;
}

NurbsSurface NurbsSurface::create_from_parameters(
    const std::vector<std::vector<Point>>& points,
    const std::vector<std::vector<double>>& weights,
    const std::vector<double>& knots_u, const std::vector<double>& knots_v,
    const std::vector<int>& mults_u, const std::vector<int>& mults_v,
    int degree_u, int degree_v,
    bool periodic_u, bool periodic_v) {

    int nv = static_cast<int>(points.size());
    int nu = nv > 0 ? static_cast<int>(points[0].size()) : 0;
    int order_u = degree_u + 1;
    int order_v = degree_v + 1;
    if (nu < order_u || nv < order_v) return NurbsSurface();
    if (periodic_u || periodic_v) return NurbsSurface();  // not yet supported
    if (knots_u.size() != mults_u.size() || knots_v.size() != mults_v.size()) return NurbsSurface();

    bool rational = false;
    for (const auto& row : weights)
        for (double w : row)
            if (std::abs(w - 1.0) > Tolerance::ZERO_TOLERANCE) { rational = true; break; }

    auto expand = [](const std::vector<double>& knots, const std::vector<int>& mults) {
        std::vector<double> full;
        for (size_t i = 0; i < knots.size(); i++)
            for (int m = 0; m < mults[i]; m++) full.push_back(knots[i]);
        return full;
    };
    std::vector<double> full_u = expand(knots_u, mults_u);
    std::vector<double> full_v = expand(knots_v, mults_v);
    int kc_u = order_u + nu - 2;
    int kc_v = order_v + nv - 2;
    if (static_cast<int>(full_u.size()) != kc_u + 2) return NurbsSurface();
    if (static_cast<int>(full_v.size()) != kc_v + 2) return NurbsSurface();

    NurbsSurface surface;
    if (!surface.create_raw(3, rational, order_u, order_v, nu, nv)) return NurbsSurface();

    for (int i = 0; i < kc_u; i++) surface.set_nurbsknot(0, i, full_u[i + 1]);
    for (int i = 0; i < kc_v; i++) surface.set_nurbsknot(1, i, full_v[i + 1]);

    // i in u (0..nu-1), j in v (0..nv-1); compas grid is points[v][u].
    for (int i = 0; i < nu; i++) {
        for (int j = 0; j < nv; j++) {
            const Point& p = points[j][i];
            if (rational) {
                double w = weights[j][i];
                surface.set_cv_4d(i, j, p[0] * w, p[1] * w, p[2] * w, w);
            } else {
                surface.set_cv(i, j, p);
            }
        }
    }
    return surface;
}

// ═══════════════════════════════════════════════════════════════════════════
// Constructors & Destructor
// ═══════════════════════════════════════════════════════════════════════════

NurbsSurface::NurbsSurface() {
    initialize();
}

NurbsSurface::NurbsSurface(int dimension, bool is_rational,
                          int order0, int order1,
                          int cv_count0, int cv_count1) {
    initialize();
    create_raw(dimension, is_rational, order0, order1, cv_count0, cv_count1);
}

NurbsSurface::NurbsSurface(const NurbsSurface& other) {
    initialize();
    deep_copy_from(other);
}

NurbsSurface& NurbsSurface::operator=(const NurbsSurface& other) {
    if (this != &other) {
        deep_copy_from(other);
    }
    return *this;
}

bool NurbsSurface::operator==(const NurbsSurface& other) const {
    // Compare metadata (excluding guid())
    if (name != other.name) return false;
    if (width != other.width) return false;
    if (pointcolors != other.pointcolors) return false;
    if (facecolors != other.facecolors) return false;
    if (linecolors != other.linecolors) return false;

    // Compare NURBS structure
    if (m_dim != other.m_dim) return false;
    if (m_is_rat != other.m_is_rat) return false;
    if (m_order[0] != other.m_order[0]) return false;
    if (m_order[1] != other.m_order[1]) return false;
    if (m_cv_count[0] != other.m_cv_count[0]) return false;
    if (m_cv_count[1] != other.m_cv_count[1]) return false;
    if (m_cv_stride[0] != other.m_cv_stride[0]) return false;
    if (m_cv_stride[1] != other.m_cv_stride[1]) return false;

    // Compare nurbsknot vectors
    if (m_nurbsknot[0] != other.m_nurbsknot[0]) return false;
    if (m_nurbsknot[1] != other.m_nurbsknot[1]) return false;

    // Compare control vertices
    if (m_cv != other.m_cv) return false;

    return true;
}

bool NurbsSurface::operator!=(const NurbsSurface& other) const {
    return !(*this == other);
}

NurbsSurface::~NurbsSurface() {
    destroy();
}

// ═══════════════════════════════════════════════════════════════════════════
// Initialization
// ═══════════════════════════════════════════════════════════════════════════

void NurbsSurface::initialize() {
    _guid.clear();
    name = "my_nurbssurface";
    width = 1.0;
    pointcolors.clear();
    facecolors.clear();
    linecolors.clear();

    m_dim = 0;
    m_is_rat = 0;
    m_order[0] = 0;
    m_order[1] = 0;
    m_cv_count[0] = 0;
    m_cv_count[1] = 0;
    m_cv_stride[0] = 0;
    m_cv_stride[1] = 0;

    m_nurbsknot[0].clear();
    m_nurbsknot[1].clear();
    m_cv.clear();
}

bool NurbsSurface::create_raw(int dimension, bool is_rational,
                         int order0, int order1,
                         int cv_count0, int cv_count1,
                         bool is_periodic_u, bool is_periodic_v,
                         double nurbsknot_delta_u, double nurbsknot_delta_v) {
    if (dimension < 1 || order0 < 2 || order1 < 2 ||
        cv_count0 < order0 || cv_count1 < order1) {
        return false;
    }

    destroy();

    m_dim = dimension;
    m_is_rat = is_rational ? 1 : 0;
    m_order[0] = order0;
    m_order[1] = order1;
    m_cv_count[0] = cv_count0;
    m_cv_count[1] = cv_count1;

    // OpenNURBS stride pattern: [1] is CV size, [0] is row stride
    int cv_size_val = m_is_rat ? (m_dim + 1) : m_dim;
    m_cv_stride[1] = cv_size_val;
    m_cv_stride[0] = cv_size_val * m_cv_count[1];

    // Allocate nurbsknot vectors
    int nurbsknot_count0 = order0 + cv_count0 - 2;
    int nurbsknot_count1 = order1 + cv_count1 - 2;

    m_nurbsknot[0].resize(nurbsknot_count0, 0.0);
    m_nurbsknot[1].resize(nurbsknot_count1, 0.0);

    // Allocate CV array
    int total_cvs = cv_count0 * cv_count1;
    int cv_array_size = total_cvs * cv_size_val;
    m_cv.resize(cv_array_size, 0.0);

    // Initialize weights to 1 if rational
    if (m_is_rat) {
        for (int i = 0; i < cv_count0; i++) {
            for (int j = 0; j < cv_count1; j++) {
                set_weight(i, j, 1.0);
            }
        }
    }

    // Initialize nurbsknot vectors
    if (is_periodic_u) {
        make_periodic_uniform_nurbsknot_vector(0, nurbsknot_delta_u);
    } else {
        make_clamped_uniform_nurbsknot_vector(0, nurbsknot_delta_u);
    }

    if (is_periodic_v) {
        make_periodic_uniform_nurbsknot_vector(1, nurbsknot_delta_v);
    } else {
        make_clamped_uniform_nurbsknot_vector(1, nurbsknot_delta_v);
    }

    return true;
}

bool NurbsSurface::create_clamped_uniform(int dimension,
                                         int order0, int order1,
                                         int cv_count0, int cv_count1,
                                         double nurbsknot_delta0,
                                         double nurbsknot_delta1) {
    if (!create_raw(dimension, false, order0, order1, cv_count0, cv_count1)) {
        return false;
    }

    make_clamped_uniform_nurbsknot_vector(0, nurbsknot_delta0);
    make_clamped_uniform_nurbsknot_vector(1, nurbsknot_delta1);

    return true;
}

void NurbsSurface::destroy() {
    m_nurbsknot[0].clear();
    m_nurbsknot[1].clear();
    m_cv.clear();
    initialize();
}

// ═══════════════════════════════════════════════════════════════════════════
// Boolean Queries
// ═══════════════════════════════════════════════════════════════════════════

bool NurbsSurface::is_valid() const {
    if (m_dim < 1) return false;
    if (m_order[0] < 2 || m_order[1] < 2) return false;
    if (m_cv_count[0] < m_order[0] || m_cv_count[1] < m_order[1]) return false;

    int nurbsknot_count0 = m_order[0] + m_cv_count[0] - 2;
    int nurbsknot_count1 = m_order[1] + m_cv_count[1] - 2;

    if (static_cast<int>(m_nurbsknot[0].size()) != nurbsknot_count0) return false;
    if (static_cast<int>(m_nurbsknot[1].size()) != nurbsknot_count1) return false;

    if (!is_valid_nurbsknot_vector(0) || !is_valid_nurbsknot_vector(1)) return false;

    int cv_size_val = m_is_rat ? (m_dim + 1) : m_dim;
    int expected_cv_size = m_cv_count[0] * m_cv_count[1] * cv_size_val;
    if (static_cast<int>(m_cv.size()) < expected_cv_size) return false;

    return true;
}

bool NurbsSurface::is_valid_nurbsknot_vector(int dir) const {
    if (dir < 0 || dir >= 2) return false;
    int kc = nurbsknot_count(dir);
    if (static_cast<int>(m_nurbsknot[dir].size()) != kc) return false;

    for (int i = 1; i < kc; i++) {
        if (m_nurbsknot[dir][i] < m_nurbsknot[dir][i-1]) return false;
    }
    return true;
}

bool NurbsSurface::is_closed(int dir) const {
    bool bIsClosed = false;
    if (dir >= 0 && dir <= 1 && m_dim > 0) {
        if (is_nurbsknot_vector_clamped(m_order[dir], m_cv_count[dir], m_nurbsknot[dir])) {
            const double* corners[4];
            corners[0] = cv(0, 0);
            corners[(dir == 0) ? 1 : 2] = cv(m_cv_count[0] - 1, 0);
            corners[(dir == 0) ? 2 : 1] = cv(0, m_cv_count[1] - 1);
            corners[3] = cv(m_cv_count[0] - 1, m_cv_count[1] - 1);

            if (points_are_coincident(m_dim, m_is_rat, corners[0], corners[1]) &&
                points_are_coincident(m_dim, m_is_rat, corners[2], corners[3]) &&
                is_point_grid_closed(m_dim, m_is_rat, m_cv_count[0], m_cv_count[1],
                                    m_cv_stride[0], m_cv_stride[1], m_cv.data(), dir)) {
                bIsClosed = true;
            }
        } else if (is_periodic(dir)) {
            bIsClosed = true;
        }
    }
    return bIsClosed;
}

bool NurbsSurface::is_periodic(int dir) const {
    bool bIsPeriodic = false;
    if (dir >= 0 && dir <= 1) {
        bIsPeriodic = is_nurbsknot_vector_periodic(m_order[dir], m_cv_count[dir], m_nurbsknot[dir]);
        if (bIsPeriodic) {
            const double* cv0;
            const double* cv1;
            int i0 = m_order[dir] - 2;
            int i1 = m_cv_count[dir] - 1;

            for (int k = 0; k < m_cv_count[1 - dir]; k++) {
                int check_i0 = i0;
                int check_i1 = i1;
                cv0 = dir ? cv(k, check_i0) : cv(check_i0, k);
                cv1 = dir ? cv(k, check_i1) : cv(check_i1, k);

                while (check_i0 >= 0) {
                    if (!points_are_coincident(m_dim, m_is_rat, cv0, cv1)) {
                        return false;
                    }
                    check_i0--;
                    check_i1--;
                    if (check_i0 >= 0) {
                        cv0 -= m_cv_stride[dir];
                        cv1 -= m_cv_stride[dir];
                    }
                }
            }
        }
    }
    return bIsPeriodic;
}

bool NurbsSurface::is_planar(Plane* plane, double tolerance) const {
    if (!is_valid()) return false;

    if (m_cv_count[0] < 2 || m_cv_count[1] < 2) return false;

    // Find three non-colinear CVs to define the plane
    Point p0 = get_cv(0, 0);
    Vector normal;
    double len = 0.0;
    for (int i = 0; i < m_cv_count[0] && len < 1e-14; i++) {
        for (int j = 0; j < m_cv_count[1] && len < 1e-14; j++) {
            for (int ii = i; ii < m_cv_count[0] && len < 1e-14; ii++) {
                for (int jj = (ii == i ? j + 1 : 0); jj < m_cv_count[1] && len < 1e-14; jj++) {
                    Point pa = get_cv(i, j);
                    Point pb = get_cv(ii, jj);
                    Vector va(pa[0]-p0[0], pa[1]-p0[1], pa[2]-p0[2]);
                    Vector vb(pb[0]-p0[0], pb[1]-p0[1], pb[2]-p0[2]);
                    normal = va.cross(vb);
                    len = normal.magnitude();
                }
            }
        }
    }
    if (len < 1e-14) return true; // all CVs coincident or colinear

    normal = normal / len;

    // Check all CVs against this plane
    for (int i = 0; i < m_cv_count[0]; i++) {
        for (int j = 0; j < m_cv_count[1]; j++) {
            Point pt = get_cv(i, j);
            Vector v(pt[0] - p0[0], pt[1] - p0[1], pt[2] - p0[2]);
            double dist = std::abs(v.dot(normal));
            if (dist > tolerance) return false;
        }
    }

    if (plane) {
        *plane = Plane::from_point_normal(p0, normal);
    }

    return true;
}

bool NurbsSurface::is_singular(int side) const {
    bool rc = false;
    const double* points = nullptr;
    int point_count = 0;
    int point_stride = 0;

    switch (side) {
    case 0: // south
        rc = is_clamped(1, 0);
        if (rc) {
            points = cv(0, 0);
            point_count = m_cv_count[0];
            point_stride = m_cv_stride[0];
        }
        break;

    case 1: // east
        rc = is_clamped(0, 1);
        if (rc) {
            points = cv(m_cv_count[0] - 1, 0);
            point_count = m_cv_count[1];
            point_stride = m_cv_stride[1];
        }
        break;

    case 2: // north
        rc = is_clamped(1, 1);
        if (rc) {
            points = cv(0, m_cv_count[1] - 1);
            point_count = m_cv_count[0];
            point_stride = m_cv_stride[0];
        }
        break;

    case 3: // west
        rc = is_clamped(0, 0);
        if (rc) {
            points = cv(0, 0);
            point_count = m_cv_count[1];
            point_stride = m_cv_stride[1];
        }
        break;

    default:
        rc = false;
        break;
    }

    if (rc && points) {
        rc = points_are_coincident(m_dim, m_is_rat, point_count, point_stride, points);
    }

    return rc;
}

bool NurbsSurface::is_clamped(int dir, int end) const {
    if (dir < 0 || dir >= 2) return false;
    if (m_nurbsknot[dir].empty()) return false;

    // Use nurbsknot module function
    return nurbsknot::is_clamped(m_order[dir], m_cv_count[dir], m_nurbsknot[dir], end);
}

bool NurbsSurface::is_duplicate(const NurbsSurface& other,
                                 bool ignore_parameterization,
                                 double tolerance) const {
    if (!is_valid() || !other.is_valid()) return false;
    if (m_dim != other.m_dim) return false;
    if (m_is_rat != other.m_is_rat) return false;
    if (m_order[0] != other.m_order[0] || m_order[1] != other.m_order[1]) return false;
    if (m_cv_count[0] != other.m_cv_count[0] || m_cv_count[1] != other.m_cv_count[1]) return false;

    for (int i = 0; i < m_cv_count[0]; i++) {
        for (int j = 0; j < m_cv_count[1]; j++) {
            Point p1 = get_cv(i, j);
            Point p2 = other.get_cv(i, j);
            if (p1.distance(p2) > tolerance) return false;
            if (m_is_rat) {
                if (std::abs(weight(i, j) - other.weight(i, j)) > tolerance) return false;
            }
        }
    }

    if (!ignore_parameterization) {
        for (int dir = 0; dir < 2; dir++) {
            for (int i = 0; i < nurbsknot_count(dir); i++) {
                if (std::abs(nurbsknot(dir, i) - other.nurbsknot(dir, i)) > tolerance) return false;
            }
        }
    }

    return true;
}

// ═══════════════════════════════════════════════════════════════════════════
// Attributes
// ═══════════════════════════════════════════════════════════════════════════

int NurbsSurface::order(int dir) const {
    return (dir >= 0 && dir < 2) ? m_order[dir] : 0;
}

int NurbsSurface::degree(int dir) const {
    return (dir >= 0 && dir < 2) ? (m_order[dir] - 1) : 0;
}

int NurbsSurface::cv_count(int dir) const {
    return (dir >= 0 && dir < 2) ? m_cv_count[dir] : 0;
}

int NurbsSurface::cv_count() const {
    return m_cv_count[0] * m_cv_count[1];
}

int NurbsSurface::cv_size() const {
    return m_is_rat ? (m_dim + 1) : m_dim;
}

int NurbsSurface::nurbsknot_count(int dir) const {
    if (dir < 0 || dir >= 2) return 0;
    // OpenNURBS formula: nurbsknot_count = order + cv_count - 2
    return m_order[dir] + m_cv_count[dir] - 2;
}

int NurbsSurface::span_count(int dir) const {
    if (dir < 0 || dir >= 2) return 0;
    return m_cv_count[dir] - m_order[dir] + 1;
}

// ═══════════════════════════════════════════════════════════════════════════
// Control Vertex Access
// ═══════════════════════════════════════════════════════════════════════════

double* NurbsSurface::cv(int i, int j) {
    if (i < 0 || i >= m_cv_count[0] || j < 0 || j >= m_cv_count[1]) {
        return nullptr;
    }
    // OpenNURBS pattern: CV(i,j) = m_cv[i*m_cv_stride[0] + j*m_cv_stride[1]]
    int index = i * m_cv_stride[0] + j * m_cv_stride[1];
    return &m_cv[index];
}

const double* NurbsSurface::cv(int i, int j) const {
    if (i < 0 || i >= m_cv_count[0] || j < 0 || j >= m_cv_count[1]) {
        return nullptr;
    }
    // OpenNURBS pattern: CV(i,j) = m_cv[i*m_cv_stride[0] + j*m_cv_stride[1]]
    int index = i * m_cv_stride[0] + j * m_cv_stride[1];
    return &m_cv[index];
}

Point NurbsSurface::get_cv(int i, int j) const {
    const double* cv_ptr = cv(i, j);
    if (!cv_ptr) return Point(0, 0, 0);

    if (m_is_rat) {
        double w = cv_ptr[m_dim];
        if (std::abs(w) < 1e-14) return Point(0, 0, 0);
        return Point(cv_ptr[0]/w,
                    m_dim > 1 ? cv_ptr[1]/w : 0,
                    m_dim > 2 ? cv_ptr[2]/w : 0);
    }
    return Point(cv_ptr[0],
                m_dim > 1 ? cv_ptr[1] : 0,
                m_dim > 2 ? cv_ptr[2] : 0);
}

bool NurbsSurface::get_cv_4d(int i, int j, double& x, double& y, double& z, double& w) const {
    const double* cv_ptr = cv(i, j);
    if (!cv_ptr) return false;
    x = cv_ptr[0];
    y = m_dim > 1 ? cv_ptr[1] : 0;
    z = m_dim > 2 ? cv_ptr[2] : 0;
    w = m_is_rat ? cv_ptr[m_dim] : 1.0;
    return true;
}

bool NurbsSurface::set_cv(int i, int j, const Point& point) {
    double* cv_ptr = cv(i, j);
    if (!cv_ptr) return false;

    if (m_is_rat) {
        // For rational surfaces, store homogeneous coordinates (x*w, y*w, z*w, w)
        double w = cv_ptr[m_dim];  // Get current weight
        if (std::abs(w) < 1e-14) w = 1.0;
        cv_ptr[0] = point[0] * w;
        if (m_dim > 1) cv_ptr[1] = point[1] * w;
        if (m_dim > 2) cv_ptr[2] = point[2] * w;
    } else {
        cv_ptr[0] = point[0];
        if (m_dim > 1) cv_ptr[1] = point[1];
        if (m_dim > 2) cv_ptr[2] = point[2];
    }
    return true;
}

bool NurbsSurface::set_cv_4d(int i, int j, double x, double y, double z, double w) {
    double* cv_ptr = cv(i, j);
    if (!cv_ptr) return false;
    cv_ptr[0] = x;
    if (m_dim > 1) cv_ptr[1] = y;
    if (m_dim > 2) cv_ptr[2] = z;
    if (m_is_rat) cv_ptr[m_dim] = w;
    return true;
}

double NurbsSurface::weight(int i, int j) const {
    if (!m_is_rat) return 1.0;
    const double* cv_ptr = cv(i, j);
    return cv_ptr ? cv_ptr[m_dim] : 1.0;
}

bool NurbsSurface::set_weight(int i, int j, double w) {
    if (!m_is_rat) return false;
    double* cv_ptr = cv(i, j);
    if (!cv_ptr) return false;

    // Rescale homogeneous coordinates when changing weight
    double old_w = cv_ptr[m_dim];
    if (std::abs(old_w) < 1e-14) old_w = 1.0;
    if (std::abs(w) < 1e-14) w = 1.0;

    double scale = w / old_w;
    cv_ptr[0] *= scale;
    if (m_dim > 1) cv_ptr[1] *= scale;
    if (m_dim > 2) cv_ptr[2] *= scale;
    cv_ptr[m_dim] = w;
    return true;
}

// ═══════════════════════════════════════════════════════════════════════════
// NurbsKnot Access
// ═══════════════════════════════════════════════════════════════════════════

double NurbsSurface::nurbsknot(int dir, int nurbsknot_index) const {
    if (dir < 0 || dir >= 2 || nurbsknot_index < 0 ||
        nurbsknot_index >= static_cast<int>(m_nurbsknot[dir].size())) {
        return 0.0;
    }
    return m_nurbsknot[dir][nurbsknot_index];
}

bool NurbsSurface::set_nurbsknot(int dir, int nurbsknot_index, double nurbsknot_value) {
    if (dir < 0 || dir >= 2 || nurbsknot_index < 0 ||
        nurbsknot_index >= static_cast<int>(m_nurbsknot[dir].size())) {
        return false;
    }
    m_nurbsknot[dir][nurbsknot_index] = nurbsknot_value;
    return true;
}

int NurbsSurface::nurbsknot_multiplicity(int dir, int nurbsknot_index) const {
    if (dir < 0 || dir >= 2 || nurbsknot_index < 0 ||
        nurbsknot_index >= static_cast<int>(m_nurbsknot[dir].size())) {
        return 0;
    }

    int mult = 1;
    double kv = m_nurbsknot[dir][nurbsknot_index];

    // Count backward
    for (int i = nurbsknot_index - 1; i >= 0; i--) {
        if (std::abs(m_nurbsknot[dir][i] - kv) < 1e-10) {
            mult++;
        } else {
            break;
        }
    }

    // Count forward
    for (int i = nurbsknot_index + 1; i < static_cast<int>(m_nurbsknot[dir].size()); i++) {
        if (std::abs(m_nurbsknot[dir][i] - kv) < 1e-10) {
            mult++;
        } else {
            break;
        }
    }
    return mult;
}

std::vector<double> NurbsSurface::get_nurbsknots(int dir) const {
    if (dir >= 0 && dir < 2) {
        return m_nurbsknot[dir];
    }
    return std::vector<double>();
}

bool NurbsSurface::insert_nurbsknot(int dir, double nurbsknot_value, int nurbsknot_mult) {
    if ((dir != 0 && dir != 1) || !is_valid() || nurbsknot_mult <= 0) {
        return false;
    }

    if (nurbsknot_mult >= m_order[dir]) {
        return false; // Multiplicity must be less than order
    }

    // Check that nurbsknot_value is inside domain
    auto [t0, t1] = domain(dir);
    if (nurbsknot_value < t0 || nurbsknot_value > t1) {
        return false; // NurbsKnot value must be inside domain
    }

    // Convert surface to high-dimensional curve
    NurbsCurve* crv = to_curve_internal(*this, dir, nullptr);
    if (!crv) {
        return false;
    }

    // Insert nurbsknots into the curve using Boehm's algorithm
    bool success = crv->insert_nurbsknot(nurbsknot_value, nurbsknot_mult);

    if (success) {
        // Convert curve back to surface
        success = from_curve_internal(*crv, *this, dir);
    }

    delete crv;
    return success;
}

// ═══════════════════════════════════════════════════════════════════════════
// Domain
// ═══════════════════════════════════════════════════════════════════════════

std::pair<double, double> NurbsSurface::domain(int dir) const {
    if (!is_valid() || dir < 0 || dir >= 2) {
        return {0.0, 0.0};
    }
    return {m_nurbsknot[dir][m_order[dir] - 2],
            m_nurbsknot[dir][m_cv_count[dir] - 1]};
}

bool NurbsSurface::set_domain(int dir, double t0, double t1) {
    if (!is_valid() || dir < 0 || dir >= 2 || t0 >= t1) return false;

    auto [d0, d1] = domain(dir);
    if (std::abs(d1 - d0) < 1e-14) return false;

    double scale = (t1 - t0) / (d1 - d0);
    for (size_t i = 0; i < m_nurbsknot[dir].size(); i++) {
        m_nurbsknot[dir][i] = t0 + (m_nurbsknot[dir][i] - d0) * scale;
    }
    return true;
}

std::vector<double> NurbsSurface::get_span_vector(int dir) const {
    std::vector<double> spans;
    if (!is_valid() || dir < 0 || dir >= 2) return spans;

    spans.push_back(m_nurbsknot[dir][m_order[dir] - 2]);
    for (size_t i = m_order[dir] - 1; i < m_nurbsknot[dir].size() - m_order[dir] + 2; i++) {
        if (m_nurbsknot[dir][i] > spans.back()) {
            spans.push_back(m_nurbsknot[dir][i]);
        }
    }
    return spans;
}

// ═══════════════════════════════════════════════════════════════════════════
// Division
// ═══════════════════════════════════════════════════════════════════════════

std::tuple<std::vector<std::vector<Point>>, std::vector<std::vector<Vector>>, std::vector<std::vector<std::pair<double,double>>>>
NurbsSurface::divide_by_count_points(int nu, int nv) const {
    std::vector<std::vector<Point>> grid;
    std::vector<std::vector<Vector>> grid_vector;
    std::vector<std::vector<std::pair<double,double>>> params;

    if (!is_valid()) {
        return {grid, grid_vector, params};
    }

    auto domain_u = domain(0);
    auto domain_v = domain(1);
    double u0 = domain_u.first;
    double u1 = domain_u.second;
    double v0 = domain_v.first;
    double v1 = domain_v.second;

    grid.resize(nu + 1);
    grid_vector.resize(nu + 1);
    params.resize(nu + 1);

    for (int i = 0; i <= nu; i++) {
        grid[i].resize(nv + 1);
        grid_vector[i].resize(nv + 1);
        params[i].resize(nv + 1);

        double u = (nu > 0) ? (u0 + (u1 - u0) * (static_cast<double>(i) / nu)) : u0;

        for (int j = 0; j <= nv; j++) {
            double v = (nv > 0) ? (v0 + (v1 - v0) * (static_cast<double>(j) / nv)) : v0;
            grid[i][j] = point_at(u, v);
            grid_vector[i][j] = normal_at(u, v);
            params[i][j] = {u, v};
        }
    }

    return {grid, grid_vector, params};
}

std::pair<std::vector<std::vector<Plane>>, std::vector<std::vector<std::pair<double,double>>>>
NurbsSurface::divide_by_count_planes(int nu, int nv) const {
    std::vector<std::vector<Plane>> grid;
    std::vector<std::vector<std::pair<double,double>>> params;

    if (!is_valid()) {
        return {grid, params};
    }

    auto domain_u = domain(0);
    auto domain_v = domain(1);
    double u0 = domain_u.first;
    double u1 = domain_u.second;
    double v0 = domain_v.first;
    double v1 = domain_v.second;

    grid.resize(nu + 1);
    params.resize(nu + 1);

    for (int i = 0; i <= nu; i++) {
        grid[i].resize(nv + 1);
        params[i].resize(nv + 1);

        double u = (nu > 0) ? (u0 + (u1 - u0) * (static_cast<double>(i) / nu)) : u0;

        for (int j = 0; j <= nv; j++) {
            double v = (nv > 0) ? (v0 + (v1 - v0) * (static_cast<double>(j) / nv)) : v0;
            Point origin = point_at(u, v);

            // Get derivatives: [S, Su, Sv]
            auto derivs = evaluate(u, v, 1);
            Vector su = derivs[2];  // tangent in u direction
            Vector sv = derivs[1];  // tangent in v direction

            // Normalize for plane axes
            Vector x_axis = su;
            if (x_axis.magnitude() > 1e-14) x_axis = x_axis.normalized();
            Vector y_axis = sv;
            if (y_axis.magnitude() > 1e-14) y_axis = y_axis.normalized();

            Plane plane = Plane(origin, x_axis, y_axis, normal_at(u, v));
            grid[i][j] = plane;
            params[i][j] = {u, v};
        }
    }

    return {grid, params};
}

// ═══════════════════════════════════════════════════════════════════════════
// Evaluation
// ═══════════════════════════════════════════════════════════════════════════

Point NurbsSurface::point_at(double u, double v) const {
    if (!is_valid()) return Point(0, 0, 0);

    // Find spans - returns indices in range [0, cv_count-order]
    int span_u = find_span(0, u);
    int span_v = find_span(1, v);

    // Compute basis functions
    std::vector<double> Nu, Nv;
    basis_functions(0, span_u, u, Nu);
    basis_functions(1, span_v, v, Nv);

    // Evaluate surface point - OpenNURBS lines 1107-1117
    // CV index starts at span (since span is in range [0, cv_count-order])
    int cv_size_val = m_is_rat ? (m_dim + 1) : m_dim;
    std::vector<double> point(cv_size_val, 0.0);

    for (int j0 = 0; j0 < m_order[0]; j0++) {
        int cv_i = span_u + j0;
        for (int j1 = 0; j1 < m_order[1]; j1++) {
            int cv_j = span_v + j1;
            double c = Nu[j0] * Nv[j1];
            const double* cv_ptr = cv(cv_i, cv_j);
            if (cv_ptr) {
                for (int d = 0; d < cv_size_val; d++) {
                    point[d] += c * cv_ptr[d];
                }
            }
        }
    }

    if (m_is_rat && std::abs(point[m_dim]) > 1e-14) {
        double w = point[m_dim];
        return Point(point[0]/w,
                    m_dim > 1 ? point[1]/w : 0,
                    m_dim > 2 ? point[2]/w : 0);
    }

    return Point(point[0],
                m_dim > 1 ? point[1] : 0,
                m_dim > 2 ? point[2] : 0);
}

std::pair<double, double> NurbsSurface::closest_parameters(const Point& test_point) const {
    auto [u, v, dist] = Closest::surface_point(*this, test_point);
    (void)dist;
    return {u, v};
}

Point NurbsSurface::closest_point(const Point& test_point) const {
    auto [u, v] = closest_parameters(test_point);
    return point_at(u, v);
}

// Fundamental forms E,F,G (first) and L,M,N (second) at (u,v); returns false if degenerate.
static bool surface_fundamental_forms(const NurbsSurface& s, double u, double v,
                                      double& E, double& F, double& G,
                                      double& L, double& M, double& N) {
    std::vector<Vector> d = s.evaluate(u, v, 2);
    if (d.size() < 6) return false;
    // evaluate() result order is [S, Sv, Svv, Su, Suv, Suu] (the (k,l) loop order).
    const Vector& Sv = d[1];
    const Vector& Svv = d[2];
    const Vector& Su = d[3];
    const Vector& Suv = d[4];
    const Vector& Suu = d[5];
    Vector cr = Su.cross(Sv);
    if (cr.magnitude() < Tolerance::ZERO_TOLERANCE) return false;
    Vector n = cr.normalized();
    E = Su.dot(Su); F = Su.dot(Sv); G = Sv.dot(Sv);
    L = Suu.dot(n); M = Suv.dot(n); N = Svv.dot(n);
    return true;
}

double NurbsSurface::gaussian_curvature(double u, double v) const {
    double E, F, G, L, M, N;
    if (!surface_fundamental_forms(*this, u, v, E, F, G, L, M, N)) return 0.0;
    double denom = E * G - F * F;
    if (std::abs(denom) < Tolerance::ZERO_TOLERANCE) return 0.0;
    return (L * N - M * M) / denom;
}

double NurbsSurface::mean_curvature(double u, double v) const {
    double E, F, G, L, M, N;
    if (!surface_fundamental_forms(*this, u, v, E, F, G, L, M, N)) return 0.0;
    double denom = E * G - F * F;
    if (std::abs(denom) < Tolerance::ZERO_TOLERANCE) return 0.0;
    return (E * N - 2.0 * F * M + G * L) / (2.0 * denom);
}

Vector NurbsSurface::normal_at(double u, double v) const {
    auto derivs = evaluate(u, v, 1);
    if (derivs.size() < 3) return Vector(0, 0, 1);

    Vector du = derivs[1];
    Vector dv = derivs[2];
    Vector normal = dv.cross(du);

    double len = normal.magnitude();
    if (len < 1e-14) return Vector(0, 0, 1);

    return normal / len;
}

Plane NurbsSurface::frame_at(double u, double v) const {
    auto d = evaluate(u, v, 1);
    if (d.size() < 3) return Plane(Point(0, 0, 0), Vector(1, 0, 0), Vector(0, 1, 0));
    Point origin(d[0][0], d[0][1], d[0][2]);
    Vector su = d[2];  // dS/du
    Vector sv = d[1];  // dS/dv
    return Plane(origin, su, sv);
}

std::vector<Point> NurbsSurface::intersections_with_line(const Line& line) const {
    std::vector<Point> results;
    if (!is_valid()) return results;
    Point p0 = line.start();
    Point pe = line.end();
    Vector d(pe[0] - p0[0], pe[1] - p0[1], pe[2] - p0[2]);
    double dl = d.magnitude();
    if (dl < 1e-14) return results;
    d = d / dl;
    Vector helper = (std::abs(d[0]) < 0.9) ? Vector(1, 0, 0) : Vector(0, 1, 0);
    Vector n1 = d.cross(helper); n1 = n1 / n1.magnitude();
    Vector n2 = d.cross(n1);    n2 = n2 / n2.magnitude();

    auto [u0, u1] = domain(0);
    auto [v0, v1] = domain(1);
    int nu = std::max(12, cv_count(0) * 4);
    int nv = std::max(12, cv_count(1) * 4);

    std::vector<Point> seen;
    for (int a = 0; a <= nu; a++) {
        for (int b = 0; b <= nv; b++) {
            double u = u0 + (u1 - u0) * a / nu;
            double v = v0 + (v1 - v0) * b / nv;
            bool ok = true;
            for (int it = 0; it < 40; it++) {
                auto der = evaluate(u, v, 1);
                if (der.size() < 3) { ok = false; break; }
                const Vector& p = der[0]; const Vector& sv = der[1]; const Vector& su = der[2];
                double rx = p[0] - p0[0], ry = p[1] - p0[1], rz = p[2] - p0[2];
                double f1 = n1[0]*rx + n1[1]*ry + n1[2]*rz;
                double f2 = n2[0]*rx + n2[1]*ry + n2[2]*rz;
                if (std::abs(f1) < 1e-12 && std::abs(f2) < 1e-12) break;
                double j11 = n1[0]*su[0] + n1[1]*su[1] + n1[2]*su[2];
                double j12 = n1[0]*sv[0] + n1[1]*sv[1] + n1[2]*sv[2];
                double j21 = n2[0]*su[0] + n2[1]*su[1] + n2[2]*su[2];
                double j22 = n2[0]*sv[0] + n2[1]*sv[1] + n2[2]*sv[2];
                double det = j11*j22 - j12*j21;
                if (std::abs(det) < 1e-14) { ok = false; break; }
                double du = -(j22*f1 - j12*f2) / det;
                double dv = -(-j21*f1 + j11*f2) / det;
                u += du; v += dv;
                if (u < u0 || u > u1 || v < v0 || v > v1) { ok = false; break; }
                if (std::abs(du) < 1e-13 && std::abs(dv) < 1e-13) break;
            }
            if (!ok) continue;
            Point p = point_at(u, v);
            double rx = p[0] - p0[0], ry = p[1] - p0[1], rz = p[2] - p0[2];
            double f1 = n1[0]*rx + n1[1]*ry + n1[2]*rz;
            double f2 = n2[0]*rx + n2[1]*ry + n2[2]*rz;
            if (std::abs(f1) > 1e-7 || std::abs(f2) > 1e-7) continue;
            bool dup = false;
            for (const Point& q : seen) if (p.distance(q) < 1e-6) { dup = true; break; }
            if (dup) continue;
            seen.push_back(p);
            results.push_back(p);
        }
    }
    return results;
}

std::vector<Vector> NurbsSurface::evaluate(double u, double v, int num_derivs) const {
    std::vector<Vector> result;

    if (!is_valid() || num_derivs < 0) {
        return result;
    }

    // Limit to 2nd order derivatives
    int max_derivs = std::min(num_derivs, 2);

    // Find spans
    int span_u = find_span(0, u);
    int span_v = find_span(1, v);

    // Compute basis function derivatives
    std::vector<std::vector<double>> ders_u, ders_v;
    basis_functions_derivatives(0, span_u, u, max_derivs, ders_u);
    basis_functions_derivatives(1, span_v, v, max_derivs, ders_v);

    // Tensor product evaluation of derivatives.
    // Result order follows the (k,l) loop below: [S, Sv, Svv, Su, Suv, Suu]
    // (k = u-derivative order, l = v-derivative order).
    int cv_size_val = m_is_rat ? (m_dim + 1) : m_dim;

    // Compute all homogeneous derivatives
    struct SKL { int k; int l; std::vector<double> data; };
    std::vector<SKL> skl_all;
    for (int k = 0; k <= max_derivs; k++) {
        for (int l = 0; l <= max_derivs - k; l++) {
            std::vector<double> Skl(cv_size_val, 0.0);
            for (int i = 0; i < m_order[0]; i++) {
                int cv_i = span_u + i;
                for (int j = 0; j < m_order[1]; j++) {
                    int cv_j = span_v + j;
                    double coeff = ders_u[k][i] * ders_v[l][j];
                    const double* cv_ptr = cv(cv_i, cv_j);
                    if (cv_ptr) {
                        for (int d = 0; d < cv_size_val; d++) {
                            Skl[d] += coeff * cv_ptr[d];
                        }
                    }
                }
            }
            skl_all.push_back({k, l, Skl});
        }
    }

    if (!m_is_rat) {
        for (auto& s : skl_all) {
            result.push_back(Vector(s.data[0],
                                    m_dim > 1 ? s.data[1] : 0,
                                    m_dim > 2 ? s.data[2] : 0));
        }
        return result;
    }

    // Rational: proper quotient rule (NURBS Book A4.2)
    double w00 = skl_all[0].data[m_dim];
    if (std::abs(w00) < 1e-14) {
        for (size_t i = 0; i < skl_all.size(); i++)
            result.push_back(Vector(0, 0, 0));
        return result;
    }
    Vector pt(skl_all[0].data[0] / w00,
              m_dim > 1 ? skl_all[0].data[1] / w00 : 0,
              m_dim > 2 ? skl_all[0].data[2] / w00 : 0);
    result.push_back(pt);

    // Weight derivatives lookup
    std::map<std::pair<int,int>, double> wders;
    for (auto& s : skl_all) wders[{s.k, s.l}] = s.data[m_dim];

    // Cartesian derivatives
    std::map<std::pair<int,int>, Vector> aders;
    aders[{0, 0}] = pt;

    auto binom = [](int n, int k) -> double {
        if (k > n || k < 0) return 0.0;
        double r = 1.0;
        for (int i = 0; i < k; i++) r = r * (n - i) / (i + 1);
        return r;
    };

    for (size_t idx = 1; idx < skl_all.size(); idx++) {
        int k = skl_all[idx].k;
        int l = skl_all[idx].l;
        double a0 = skl_all[idx].data[0];
        double a1 = m_dim > 1 ? skl_all[idx].data[1] : 0;
        double a2 = m_dim > 2 ? skl_all[idx].data[2] : 0;
        for (int i = 1; i <= k; i++) {
            auto it = aders.find({k - i, l});
            if (it != aders.end()) {
                double c = binom(k, i) * wders[{i, 0}];
                a0 -= c * it->second[0];
                a1 -= c * it->second[1];
                a2 -= c * it->second[2];
            }
        }
        for (int j = 1; j <= l; j++) {
            auto it = aders.find({k, l - j});
            if (it != aders.end()) {
                double c = binom(l, j) * wders[{0, j}];
                a0 -= c * it->second[0];
                a1 -= c * it->second[1];
                a2 -= c * it->second[2];
            }
        }
        // Mixed terms (NURBS Book A4.4): -sum_{i=1}^{k} sum_{j=1}^{l} C(k,i) C(l,j) w[i][j] SKL[k-i][l-j].
        // Previously omitted -> rational mixed derivatives (e.g. Suv) were wrong.
        for (int i = 1; i <= k; i++) {
            for (int j = 1; j <= l; j++) {
                auto it = aders.find({k - i, l - j});
                if (it != aders.end()) {
                    double c = binom(k, i) * binom(l, j) * wders[{i, j}];
                    a0 -= c * it->second[0];
                    a1 -= c * it->second[1];
                    a2 -= c * it->second[2];
                }
            }
        }
        Vector dv(a0 / w00, a1 / w00, a2 / w00);
        aders[{k, l}] = dv;
        result.push_back(dv);
    }

    return result;
}

Point NurbsSurface::point_at_corner(int u_end, int v_end) const {
    int i = (u_end == 0) ? 0 : m_cv_count[0] - 1;
    int j = (v_end == 0) ? 0 : m_cv_count[1] - 1;
    return get_cv(i, j);
}

// ═══════════════════════════════════════════════════════════════════════════
// Modification
// ═══════════════════════════════════════════════════════════════════════════

bool NurbsSurface::reverse(int dir) {
    if (dir < 0 || dir >= 2) return false;

    // Reverse nurbsknot vector using nurbsknot module function
    nurbsknot::reverse(m_order[dir], m_cv_count[dir], m_nurbsknot[dir]);

    // Reverse CVs in direction
    if (dir == 0) {
        for (int j = 0; j < m_cv_count[1]; j++) {
            for (int i = 0; i < m_cv_count[0] / 2; i++) {
                int i2 = m_cv_count[0] - 1 - i;
                Point temp = get_cv(i, j);
                set_cv(i, j, get_cv(i2, j));
                set_cv(i2, j, temp);
            }
        }
    } else {
        for (int i = 0; i < m_cv_count[0]; i++) {
            for (int j = 0; j < m_cv_count[1] / 2; j++) {
                int j2 = m_cv_count[1] - 1 - j;
                Point temp = get_cv(i, j);
                set_cv(i, j, get_cv(i, j2));
                set_cv(i, j2, temp);
            }
        }
    }
    return true;
}

bool NurbsSurface::transpose() {
    // Transpose CV grid and swap parameters
    std::swap(m_order[0], m_order[1]);
    std::swap(m_cv_count[0], m_cv_count[1]);
    std::swap(m_cv_stride[0], m_cv_stride[1]);

    // Swap nurbsknot vectors
    std::swap(m_nurbsknot[0], m_nurbsknot[1]);

    return true;
}

bool NurbsSurface::swap_coordinates(int axis_i, int axis_j) {
    if (axis_i < 0 || axis_i >= m_dim || axis_j < 0 || axis_j >= m_dim) {
        return false;
    }

    for (int i = 0; i < m_cv_count[0]; i++) {
        for (int j = 0; j < m_cv_count[1]; j++) {
            double* cv_ptr = cv(i, j);
            if (cv_ptr) {
                std::swap(cv_ptr[axis_i], cv_ptr[axis_j]);
            }
        }
    }
    return true;
}

bool NurbsSurface::trim(int dir, const std::pair<double, double>& domain_pair) {
    if (dir < 0 || dir > 1 || !is_valid()) return false;

    NurbsCurve* crv = to_curve_internal(*this, dir, nullptr);
    if (!crv) return false;

    bool ok = crv->trim(domain_pair.first, domain_pair.second);
    if (ok) ok = from_curve_internal(*crv, *this, dir);

    delete crv;
    return ok;
}

std::pair<NurbsSurface, NurbsSurface> NurbsSurface::split(int dir, double c) const {
    NurbsSurface lo, hi;
    if (dir < 0 || dir > 1 || !is_valid()) return {lo, hi};

    auto [t0, t1] = domain(dir);
    if (c <= t0 || c >= t1) return {lo, hi};

    lo = *this;
    hi = *this;

    if (!lo.trim(dir, {t0, c}) || !hi.trim(dir, {c, t1})) {
        return {NurbsSurface(), NurbsSurface()};
    }
    return {lo, hi};
}

bool NurbsSurface::make_rational() {
    if (m_is_rat) return true;

    int new_stride_1 = m_dim + 1;
    int new_stride_0 = new_stride_1 * m_cv_count[1];
    std::vector<double> new_cv(m_cv_count[0] * m_cv_count[1] * new_stride_1);

    for (int i = 0; i < m_cv_count[0]; i++) {
        for (int j = 0; j < m_cv_count[1]; j++) {
            const double* old_ptr = cv(i, j);
            double* new_ptr = &new_cv[i * new_stride_0 + j * new_stride_1];

            for (int d = 0; d < m_dim; d++) {
                new_ptr[d] = old_ptr[d];
            }
            new_ptr[m_dim] = 1.0; // weight
        }
    }

    m_cv = new_cv;
    m_is_rat = 1;
    m_cv_stride[1] = new_stride_1;
    m_cv_stride[0] = new_stride_0;

    return true;
}

bool NurbsSurface::make_non_rational() {
    if (!m_is_rat) return true;

    int new_stride_1 = m_dim;
    int new_stride_0 = new_stride_1 * m_cv_count[1];
    std::vector<double> new_cv(m_cv_count[0] * m_cv_count[1] * m_dim);

    for (int i = 0; i < m_cv_count[0]; i++) {
        for (int j = 0; j < m_cv_count[1]; j++) {
            const double* old_ptr = cv(i, j);
            double* new_ptr = &new_cv[i * new_stride_0 + j * new_stride_1];
            double w = old_ptr[m_dim];
            double inv_w = (std::abs(w) > 1e-14) ? 1.0 / w : 1.0;
            for (int d = 0; d < m_dim; d++) {
                new_ptr[d] = old_ptr[d] * inv_w;
            }
        }
    }

    m_cv = new_cv;
    m_is_rat = 0;
    m_cv_stride[1] = new_stride_1;
    m_cv_stride[0] = new_stride_0;

    return true;
}

bool NurbsSurface::increase_degree(int dir, int desired_degree) {
    if (dir < 0 || dir > 1 || !is_valid()) return false;
    if (desired_degree < degree(dir)) return false;
    if (desired_degree == degree(dir)) return true;

    NurbsCurve* crv = to_curve_internal(*this, dir, nullptr);
    if (!crv) return false;

    bool success = crv->increase_degree(desired_degree);
    if (success) {
        success = from_curve_internal(*crv, *this, dir);
    }

    delete crv;
    return success;
}

// ═══════════════════════════════════════════════════════════════════════════
// Transformation
// ═══════════════════════════════════════════════════════════════════════════

bool NurbsSurface::transform(const Xform& xf) {
    for (int i = 0; i < m_cv_count[0]; i++) {
        for (int j = 0; j < m_cv_count[1]; j++) {
            Point pt = get_cv(i, j);
            pt.transform(xf);
            set_cv(i, j, pt);
        }
    }
    return true;
}

NurbsSurface NurbsSurface::transformed(const Xform& xf) const {
    NurbsSurface result = *this;
    result.transform(xf);
    return result;
}

// ═══════════════════════════════════════════════════════════════════════════
// Geometric Operations (Additional)
// ═══════════════════════════════════════════════════════════════════════════

std::vector<NurbsSurfaceTrimmed> NurbsSurface::split_by_plane(const Plane& plane, double tolerance) const {
    auto pairs = Intersection::surface_plane_uv(*this, plane, tolerance);
    std::vector<NurbsCurve> pcurves;
    for (const auto& pair : pairs)
        pcurves.push_back(pair.second);
    return NurbsSurfaceTrimmed::split_by_uv_curves(*this, pcurves, tolerance);
}

std::vector<NurbsSurfaceTrimmed> NurbsSurface::split_by_curves(const std::vector<NurbsCurve>& curves, double tolerance) const {
    std::vector<NurbsCurve> pcurves;
    for (const auto& crv : curves) {
        for (const auto& pcurve : Closest::surface_curve(*this, crv, 0.0, 0.0, tolerance))
            pcurves.push_back(pcurve);
    }
    return NurbsSurfaceTrimmed::split_by_uv_curves(*this, pcurves, tolerance);
}

std::vector<NurbsSurfaceTrimmed> NurbsSurface::split_by_line(const Line& line, double tolerance) const {
    std::vector<Point> pts = {line.start(), line.end()};
    NurbsCurve crv = NurbsCurve::create(false, 1, pts);
    return split_by_curves({crv}, tolerance);
}

std::vector<NurbsSurfaceTrimmed> NurbsSurface::split_by_surface(const NurbsSurface& cutter, double tolerance) const {
    auto triples = Intersection::surface_surface(*this, cutter, tolerance);
    std::vector<NurbsCurve> pcurves;
    for (const auto& triple : triples)
        pcurves.push_back(std::get<1>(triple));
    return NurbsSurfaceTrimmed::split_by_uv_curves(*this, pcurves, tolerance);
}

namespace {
std::pair<std::array<double, 3>, std::array<double, 3>> ns_surface_aabb(const NurbsSurface& srf) {
    const int n = 6;
    auto du = srf.domain(0);
    auto dv = srf.domain(1);
    std::array<double, 3> lo = {1e30, 1e30, 1e30};
    std::array<double, 3> hi = {-1e30, -1e30, -1e30};
    for (int i = 0; i <= n; ++i)
        for (int j = 0; j <= n; ++j) {
            Point p = srf.point_at(du.first + (du.second - du.first) * i / n,
                                   dv.first + (dv.second - dv.first) * j / n);
            for (int k = 0; k < 3; ++k) {
                if (p[k] < lo[k]) lo[k] = p[k];
                if (p[k] > hi[k]) hi[k] = p[k];
            }
        }
    return {lo, hi};
}
bool ns_aabb_overlap_pad(const std::pair<std::array<double, 3>, std::array<double, 3>>& a,
                         const std::pair<std::array<double, 3>, std::array<double, 3>>& b) {
    double m = std::max({a.second[0] - a.first[0], a.second[1] - a.first[1], a.second[2] - a.first[2]}) * 1e-3;
    for (int k = 0; k < 3; ++k)
        if (a.first[k] - m > b.second[k] || b.first[k] - m > a.second[k]) return false;
    return true;
}
}  // namespace

std::vector<NurbsSurfaceTrimmed> NurbsSurface::split_by_brep(const BRep& brep, double tolerance) const {
    auto target_bb = ns_surface_aabb(*this);
    std::vector<NurbsCurve> pcurves;
    for (const auto& cutter : brep.m_surfaces) {
        if (!ns_aabb_overlap_pad(target_bb, ns_surface_aabb(cutter))) continue;
        for (auto& pc : Intersection::cut_curves_on_surface(*this, cutter, tolerance)) pcurves.push_back(pc);
    }
    return NurbsSurfaceTrimmed::split_by_uv_curves(*this, pcurves, tolerance);
}

// ═══════════════════════════════════════════════════════════════════════════
// Geometric Operations
// ═══════════════════════════════════════════════════════════════════════════

NurbsCurve NurbsSurface::iso_curve(int dir, double c) const {
    if ((dir != 0 && dir != 1) || !is_valid()) {
        return NurbsCurve();
    }

    NurbsCurve nurbs_crv(m_dim, m_is_rat != 0, m_order[dir], m_cv_count[dir]);

    // Copy nurbsknot vector for the varying direction
    for (int i = 0; i < nurbs_crv.nurbsknot_count(); i++) {
        nurbs_crv.set_nurbsknot(i, nurbsknot(dir, i));
    }

    // Find span index in the constant direction
    int span_index = find_span(1 - dir, c);
    if (span_index < 0) {
        span_index = 0;
    } else if (span_index > m_cv_count[1 - dir] - m_order[1 - dir]) {
        span_index = m_cv_count[1 - dir] - m_order[1 - dir];
    }

    // Each iso-curve CV is the blend of the constant direction at c in HOMOGENEOUS coordinates:
    // a non-rational helper curve through (wx, wy, wz) and one through (w, 0, 0) evaluate that
    // blend exactly, so a rational surface (sphere, torus) yields its exact rational iso-curve.
    for (int cv_idx = 0; cv_idx < nurbs_crv.m_cv_count; cv_idx++) {
        NurbsCurve N(3, false, m_order[1 - dir], m_cv_count[1 - dir]);
        NurbsCurve W(3, false, m_order[1 - dir], m_cv_count[1 - dir]);
        for (int i = 0; i < N.nurbsknot_count(); i++) {
            N.set_nurbsknot(i, nurbsknot(1 - dir, i));
            W.set_nurbsknot(i, nurbsknot(1 - dir, i));
        }
        for (int i = 0; i < m_cv_count[1 - dir]; i++) {
            const double* Scv = dir ? cv(i, cv_idx) : cv(cv_idx, i);
            N.set_cv(i, Point(Scv[0], (m_dim > 1) ? Scv[1] : 0, (m_dim > 2) ? Scv[2] : 0));
            W.set_cv(i, Point(m_is_rat ? Scv[m_dim] : 1.0, 0, 0));
        }
        Point q = N.point_at(c);
        if (m_is_rat) nurbs_crv.set_cv_4d(cv_idx, q[0], q[1], q[2], W.point_at(c)[0]);
        else nurbs_crv.set_cv(cv_idx, q);
    }

    return nurbs_crv;
}

// ═══════════════════════════════════════════════════════════════════════════
// Meshing
// ═══════════════════════════════════════════════════════════════════════════

Mesh NurbsSurface::mesh_grid() const {
    if (m_mesh.number_of_vertices() == 0 && is_valid()) {
        m_mesh = RemeshNurbsSurfaceGrid::from_u_v(*this, 0, 0);
    }
    return m_mesh;
}

Mesh NurbsSurface::mesh_adaptive(double max_angle, double max_edge_length,
                                  double min_edge_length, double max_chord_height) const {
    if (m_mesh.number_of_vertices() == 0 && is_valid()) {
        RemeshNurbsSurfaceAdaptive mesher(*this);
        mesher.set_max_angle(max_angle)
              .set_max_edge_length(max_edge_length)
              .set_min_edge_length(min_edge_length)
              .set_max_chord_height(max_chord_height);
        m_mesh = mesher.mesh();
    }
    return m_mesh;
}

Mesh NurbsSurface::mesh() const {
    if (m_mesh.number_of_vertices() == 0 && is_valid() && is_planar(nullptr, 1e-6)) {
        Mesh result;
        Point p00 = point_at_corner(0, 0);
        Point p10 = point_at_corner(1, 0);
        Point p11 = point_at_corner(1, 1);
        Point p01 = point_at_corner(0, 1);
        double d2 = (p00[0]-p01[0])*(p00[0]-p01[0]) + (p00[1]-p01[1])*(p00[1]-p01[1]) + (p00[2]-p01[2])*(p00[2]-p01[2]);
        Vector normal;
        if (d2 < 1e-20) {
            auto v0 = result.add_vertex(p00);
            auto v1 = result.add_vertex(p10);
            auto v2 = result.add_vertex(p11);
            result.add_face({v0, v1, v2});
            Vector e1(p10[0]-p00[0], p10[1]-p00[1], p10[2]-p00[2]);
            Vector e2(p11[0]-p00[0], p11[1]-p00[1], p11[2]-p00[2]);
            normal = e1.cross(e2);
        } else {
            auto v0 = result.add_vertex(p00);
            auto v1 = result.add_vertex(p10);
            auto v2 = result.add_vertex(p11);
            auto v3 = result.add_vertex(p01);
            result.add_face({v0, v1, v2});
            result.add_face({v0, v2, v3});
            auto derivs = evaluate(0.5, 0.5, 1);
            if (derivs.size() >= 3) normal = derivs[1].cross(derivs[2]);
        }
        double nlen = normal.magnitude();
        if (nlen > 1e-15) normal = normal * (1.0 / nlen);
        for (auto& [vi, pt] : result.vertex)
            pt.set_normal(normal[0], normal[1], normal[2]);
        m_mesh = result;
        return m_mesh;
    }
    return mesh_grid();
}

// ═══════════════════════════════════════════════════════════════════════════
// Serialization
// ═══════════════════════════════════════════════════════════════════════════

nlohmann::ordered_json NurbsSurface::jsondump() const {
    nlohmann::ordered_json j;

    // control_points
    {
        int cv_sz = m_is_rat ? (m_dim + 1) : m_dim;
        std::vector<double> row_major_cvs;
        row_major_cvs.reserve(m_cv_count[0] * m_cv_count[1] * cv_sz);
        for (int ci = 0; ci < m_cv_count[0]; ci++)
            for (int cj = 0; cj < m_cv_count[1]; cj++) {
                const double* cvp = cv(ci, cj);
                for (int d = 0; d < cv_sz; d++) row_major_cvs.push_back(cvp[d]);
            }
        j["control_points"] = row_major_cvs;
    }
    j["cv_count_u"] = m_cv_count[0];
    j["cv_count_v"] = m_cv_count[1];
    j["dimension"] = m_dim;

    nlohmann::ordered_json facecolors_arr = nlohmann::ordered_json::array();
    for (const auto& c : facecolors) {
        facecolors_arr.push_back(c.r); facecolors_arr.push_back(c.g);
        facecolors_arr.push_back(c.b); facecolors_arr.push_back(c.a);
    }
    j["facecolors"] = facecolors_arr;

    j["guid"] = guid();
    j["is_rational"] = m_is_rat != 0;
    j["nurbsknots_u"] = m_nurbsknot[0];
    j["nurbsknots_v"] = m_nurbsknot[1];

    nlohmann::ordered_json linecolors_arr = nlohmann::ordered_json::array();
    for (const auto& c : linecolors) {
        linecolors_arr.push_back(c.r); linecolors_arr.push_back(c.g);
        linecolors_arr.push_back(c.b); linecolors_arr.push_back(c.a);
    }
    j["linecolors"] = linecolors_arr;

    if (m_mesh.number_of_vertices() > 0) {
        j["mesh"] = m_mesh.jsondump();
    }
    j["name"] = name;
    j["order_u"] = m_order[0];
    j["order_v"] = m_order[1];

    nlohmann::ordered_json pointcolors_arr = nlohmann::ordered_json::array();
    for (const auto& c : pointcolors) {
        pointcolors_arr.push_back(c.r); pointcolors_arr.push_back(c.g);
        pointcolors_arr.push_back(c.b); pointcolors_arr.push_back(c.a);
    }
    j["pointcolors"] = pointcolors_arr;

    j["type"] = "NurbsSurface";
    j["width"] = width;
    return j;
}

NurbsSurface NurbsSurface::jsonload(const nlohmann::json& data) {
    NurbsSurface surface;

    if (data.contains("dimension") && data.contains("order_u") && data.contains("order_v") &&
        data.contains("cv_count_u") && data.contains("cv_count_v")) {
        int dim = data["dimension"];
        bool is_rat = data.value("is_rational", false);
        int order_u = data["order_u"];
        int order_v = data["order_v"];
        int cv_count_u = data["cv_count_u"];
        int cv_count_v = data["cv_count_v"];

        surface.create_raw(dim, is_rat, order_u, order_v, cv_count_u, cv_count_v);

        if (data.contains("nurbsknots_u")) {
            surface.m_nurbsknot[0] = data["nurbsknots_u"].get<std::vector<double>>();
        }
        if (data.contains("nurbsknots_v")) {
            surface.m_nurbsknot[1] = data["nurbsknots_v"].get<std::vector<double>>();
        }
        if (data.contains("control_points")) {
            surface.m_cv = data["control_points"].get<std::vector<double>>();
        }

        surface.guid() = data.value("guid", ::guid());
        surface.name = data.value("name", "my_nurbssurface");
        surface.width = data.value("width", 1.0);

        if (data.contains("pointcolors") && data["pointcolors"].is_array()) {
            const auto& arr = data["pointcolors"];
            for (size_t i = 0; i + 3 < arr.size(); i += 4) {
                surface.pointcolors.push_back(Color(arr[i].get<int>(), arr[i+1].get<int>(),
                    arr[i+2].get<int>(), arr[i+3].get<int>()));
            }
        }
        if (data.contains("facecolors") && data["facecolors"].is_array()) {
            const auto& arr = data["facecolors"];
            for (size_t i = 0; i + 3 < arr.size(); i += 4) {
                surface.facecolors.push_back(Color(arr[i].get<int>(), arr[i+1].get<int>(),
                    arr[i+2].get<int>(), arr[i+3].get<int>()));
            }
        }
        if (data.contains("linecolors") && data["linecolors"].is_array()) {
            const auto& arr = data["linecolors"];
            for (size_t i = 0; i + 3 < arr.size(); i += 4) {
                surface.linecolors.push_back(Color(arr[i].get<int>(), arr[i+1].get<int>(),
                    arr[i+2].get<int>(), arr[i+3].get<int>()));
            }
        }
        if (data.contains("mesh") && !data["mesh"].is_null()) {
            surface.m_mesh = Mesh::jsonload(data["mesh"]);
        }
    }

    return surface;
}

void NurbsSurface::file_json_dump(const std::string& filename) const {
    std::ofstream file(filename);
    file << jsondump().dump(4);
}

NurbsSurface NurbsSurface::file_json_load(const std::string& filename) {
    std::ifstream file(filename);
    nlohmann::json data;
    file >> data;
    return jsonload(data);
}

std::string NurbsSurface::file_json_dumps() const {
    return jsondump().dump();
}

NurbsSurface NurbsSurface::file_json_loads(const std::string& json_string) {
    return jsonload(nlohmann::ordered_json::parse(json_string));
}

std::string NurbsSurface::pb_dumps() const {
    session_proto::NurbsSurface proto;

    // Basic metadata
    if (has_guid()) { proto.set_guid(guid()); }
    proto.set_name(name);
    proto.set_dimension(m_dim);
    proto.set_is_rational(m_is_rat != 0);
    proto.set_order_u(m_order[0]);
    proto.set_order_v(m_order[1]);
    proto.set_cv_count_u(m_cv_count[0]);
    proto.set_cv_count_v(m_cv_count[1]);
    proto.set_cv_stride_u(m_cv_stride[0]);
    proto.set_cv_stride_v(m_cv_stride[1]);

    // NurbsKnot vectors
    for (size_t i = 0; i < m_nurbsknot[0].size(); i++) {
        proto.add_nurbsknots_u(m_nurbsknot[0][i]);
    }
    for (size_t i = 0; i < m_nurbsknot[1].size(); i++) {
        proto.add_nurbsknots_v(m_nurbsknot[1][i]);
    }

    // Control vertices (always row-major: stride[0]=cv_size*cv_count[1], stride[1]=cv_size)
    int cv_sz = m_is_rat ? (m_dim + 1) : m_dim;
    for (int ci = 0; ci < m_cv_count[0]; ci++) {
        for (int cj = 0; cj < m_cv_count[1]; cj++) {
            const double* cvp = cv(ci, cj);
            for (int d = 0; d < cv_sz; d++) proto.add_cvs(cvp[d]);
        }
    }

    // Visual properties
    proto.set_width(width);

    for (const auto& c : pointcolors) {
        auto* cp = proto.add_pointcolors();
        cp->set_r(c.r); cp->set_g(c.g); cp->set_b(c.b); cp->set_a(c.a);
    }
    for (const auto& c : facecolors) {
        auto* cp = proto.add_facecolors();
        cp->set_r(c.r); cp->set_g(c.g); cp->set_b(c.b); cp->set_a(c.a);
    }
    for (const auto& c : linecolors) {
        auto* cp = proto.add_linecolors();
        cp->set_r(c.r); cp->set_g(c.g); cp->set_b(c.b); cp->set_a(c.a);
    }

    // Cached mesh
    if (m_mesh.number_of_vertices() > 0) {
        std::string mesh_data = m_mesh.pb_dumps();
        proto.mutable_cached_mesh()->ParseFromString(mesh_data);
    }

    return proto.SerializeAsString();
}

NurbsSurface NurbsSurface::pb_loads(const std::string& data) {
    session_proto::NurbsSurface proto;
    proto.ParseFromString(data);

    // Create surface with correct dimensions
    NurbsSurface surface;
    surface.create_raw(proto.dimension(), proto.is_rational(),
                   proto.order_u(), proto.order_v(),
                   proto.cv_count_u(), proto.cv_count_v());

    // Load metadata
    if (!proto.guid().empty()) { surface.guid() = proto.guid(); }
    surface.name = proto.name();

    // Load nurbsknot vectors
    for (int i = 0; i < proto.nurbsknots_u_size(); i++) {
        if (i < (int)surface.m_nurbsknot[0].size()) {
            surface.m_nurbsknot[0][i] = proto.nurbsknots_u(i);
        }
    }
    for (int i = 0; i < proto.nurbsknots_v_size(); i++) {
        if (i < (int)surface.m_nurbsknot[1].size()) {
            surface.m_nurbsknot[1][i] = proto.nurbsknots_v(i);
        }
    }

    // Load control vertices - the wire is row-major (see to_proto); honor its strides
    int cv_sz = surface.cv_size();
    int stride_u = proto.cv_stride_u() > 0 ? proto.cv_stride_u() : cv_sz * surface.m_cv_count[1];
    int stride_v = proto.cv_stride_v() > 0 ? proto.cv_stride_v() : cv_sz;
    for (int i = 0; i < surface.m_cv_count[0]; i++) {
        for (int j = 0; j < surface.m_cv_count[1]; j++) {
            int src = i * stride_u + j * stride_v;
            int dst = i * surface.m_cv_stride[0] + j * surface.m_cv_stride[1];
            for (int d = 0; d < cv_sz; d++) {
                if (src + d < proto.cvs_size()) surface.m_cv[dst + d] = proto.cvs(src + d);
            }
        }
    }

    // Load visual properties
    surface.width = proto.width();

    for (int i = 0; i < proto.pointcolors_size(); ++i) {
        const auto& c = proto.pointcolors(i);
        surface.pointcolors.push_back(Color(c.r(), c.g(), c.b(), c.a()));
    }
    for (int i = 0; i < proto.facecolors_size(); ++i) {
        const auto& c = proto.facecolors(i);
        surface.facecolors.push_back(Color(c.r(), c.g(), c.b(), c.a()));
    }
    for (int i = 0; i < proto.linecolors_size(); ++i) {
        const auto& c = proto.linecolors(i);
        surface.linecolors.push_back(Color(c.r(), c.g(), c.b(), c.a()));
    }

    // Load cached mesh
    if (proto.has_cached_mesh() && proto.cached_mesh().vertices_size() > 0) {
        std::string mesh_data = proto.cached_mesh().SerializeAsString();
        surface.m_mesh = Mesh::pb_loads(mesh_data);
    }

    return surface;
}

void NurbsSurface::pb_dump(const std::string& filename) const {
    std::string data = pb_dumps();
    std::ofstream file(filename, std::ios::binary);
    file.write(data.data(), data.size());
}

NurbsSurface NurbsSurface::pb_load(const std::string& filename) {
    std::ifstream file(filename, std::ios::binary);
    std::string data((std::istreambuf_iterator<char>(file)),
                     std::istreambuf_iterator<char>());
    return pb_loads(data);
}

// ═══════════════════════════════════════════════════════════════════════════
// String Representation
// ═══════════════════════════════════════════════════════════════════════════

std::string NurbsSurface::str() const {
    return fmt::format("NurbsSurface(name={}, degree=({},{}), cvs=({},{}))",
                      name,
                      degree(0), degree(1),
                      m_cv_count[0], m_cv_count[1]);
}

std::string NurbsSurface::repr() const {
    std::string result = fmt::format("NurbsSurface(\n  name={},\n  degree=({},{}),\n  cvs=({},{}),\n  rational={},\n  control_points=[\n",
                                     name, degree(0), degree(1), m_cv_count[0], m_cv_count[1], m_is_rat ? "true" : "false");
    for (int i = 0; i < m_cv_count[0]; ++i) {
        for (int j = 0; j < m_cv_count[1]; ++j) {
            Point p = get_cv(i, j);
            result += fmt::format("    {}, {}, {}\n", p[0], p[1], p[2]);
        }
    }
    result += "  ]\n)";
    return result;
}

std::ostream& operator<<(std::ostream& os, const NurbsSurface& surface) {
    os << surface.str();
    return os;
}

// ═══════════════════════════════════════════════════════════════════════════
// Advanced
// ═══════════════════════════════════════════════════════════════════════════

bool NurbsSurface::zero_cvs() {
    for (int i = 0; i < m_cv_count[0]; i++) {
        for (int j = 0; j < m_cv_count[1]; j++) {
            set_cv(i, j, Point(0, 0, 0));
            if (m_is_rat) {
                set_weight(i, j, 1.0);
            }
        }
    }
    return true;
}

bool NurbsSurface::make_clamped_uniform_nurbsknot_vector(int dir, double delta) {
    if (dir < 0 || dir >= 2 || delta <= 0.0) return false;

    // Use nurbsknot module function
    m_nurbsknot[dir] = nurbsknot::make_clamped_uniform(m_order[dir], m_cv_count[dir], delta);
    return !m_nurbsknot[dir].empty();
}

// ═══════════════════════════════════════════════════════════════════════════
// Private
// ═══════════════════════════════════════════════════════════════════════════

bool NurbsSurface::make_periodic_uniform_nurbsknot_vector(int dir, double delta) {
    if (dir < 0 || dir >= 2 || delta <= 0.0) return false;

    // Use nurbsknot module function
    m_nurbsknot[dir] = nurbsknot::make_periodic_uniform(m_order[dir], m_cv_count[dir], delta);
    return !m_nurbsknot[dir].empty();
}

void NurbsSurface::deep_copy_from(const NurbsSurface& src) {
    _guid.clear();
    name = src.name;
    width = src.width;
    pointcolors = src.pointcolors;
    facecolors = src.facecolors;
    linecolors = src.linecolors;

    m_dim = src.m_dim;
    m_is_rat = src.m_is_rat;
    m_order[0] = src.m_order[0];
    m_order[1] = src.m_order[1];
    m_cv_count[0] = src.m_cv_count[0];
    m_cv_count[1] = src.m_cv_count[1];
    m_cv_stride[0] = src.m_cv_stride[0];
    m_cv_stride[1] = src.m_cv_stride[1];

    m_nurbsknot[0] = src.m_nurbsknot[0];
    m_nurbsknot[1] = src.m_nurbsknot[1];
    m_cv = src.m_cv;
    m_mesh = src.m_mesh;
}

int NurbsSurface::find_span(int dir, double t) const {
    if (dir < 0 || dir >= 2) return -1;

    // Implements ON_NurbsSpanIndex from OpenNURBS
    int order = m_order[dir];
    int cv_count = m_cv_count[dir];
    const std::vector<double>& nurbsknot = m_nurbsknot[dir];

    // Shift nurbsknot pointer by (order-2) - OpenNURBS line 227
    int nurbsknot_offset = order - 2;
    int span_len = cv_count - order + 2;

    // Binary search in shifted range
    if (t <= nurbsknot[nurbsknot_offset]) return 0;
    if (t >= nurbsknot[nurbsknot_offset + span_len - 1]) return span_len - 2;

    // Binary search
    int low = 0;
    int high = span_len - 1;

    while (high > low + 1) {
        int mid = (low + high) / 2;
        if (t < nurbsknot[nurbsknot_offset + mid]) {
            high = mid;
        } else {
            low = mid;
        }
    }

    return low;
}

void NurbsSurface::basis_functions(int dir, int span, double t,
                                   std::vector<double>& basis) const {
    if (dir < 0 || dir >= 2) return;

    // Implements ON_EvaluateNurbsBasis from OpenNURBS
    int order = m_order[dir];
    int d = order - 1;  // degree

    // OpenNURBS shifts nurbsknot by (order-2) + span, then by d inside basis
    int nurbsknot_base = span + d;
    const std::vector<double>& nurbsknot = m_nurbsknot[dir];

    // Check for degenerate span
    if (nurbsknot[nurbsknot_base - 1] == nurbsknot[nurbsknot_base]) {
        basis.resize(order);
        std::fill(basis.begin(), basis.end(), 0.0);
        return;
    }

    std::vector<double> N(order * order, 0.0);
    N[order * order - 1] = 1.0;

    std::vector<double> left(d);
    std::vector<double> right(d);

    // Cox-de Boor recursion - OpenNURBS lines 702-718
    int N_idx = order * order - 1;
    int k_right = nurbsknot_base;
    int k_left = nurbsknot_base - 1;

    for (int j = 0; j < d; j++) {
        int N0_idx = N_idx;
        N_idx -= (order + 1);
        left[j] = t - nurbsknot[k_left];
        right[j] = nurbsknot[k_right] - t;
        k_left--;
        k_right++;

        double x = 0.0;
        for (int r = 0; r <= j; r++) {
            double a0 = left[j - r];
            double a1 = right[r];
            double y = N[N0_idx + r] / (a0 + a1);
            N[N_idx + r] = x + a1 * y;
            x = a0 * y;
        }
        N[N_idx + j + 1] = x;
    }

    // Return just the final row of basis functions
    basis.resize(order);
    for (int i = 0; i < order; i++) {
        basis[i] = N[i];
    }
}

void NurbsSurface::basis_functions_derivatives(int dir, int span, double t, int deriv_order,
                                              std::vector<std::vector<double>>& ders) const {
    if (dir < 0 || dir >= 2) return;

    int order = m_order[dir];
    int degree = order - 1;
    const std::vector<double>& nurbsknot = m_nurbsknot[dir];

    // NurbsKnot base index (shifted by degree like in basis_functions)
    int nurbsknot_base = span + degree;

    // Initialize derivatives matrix: ders[k][j] = k-th derivative of N_{span-degree+j,degree}
    ders.resize(deriv_order + 1);
    for (int k = 0; k <= deriv_order; k++) {
        ders[k].resize(order, 0.0);
    }

    // Check for degenerate span
    if (nurbsknot[nurbsknot_base - 1] == nurbsknot[nurbsknot_base]) {
        return; // All derivatives are zero
    }

    // Compute basis functions using triangular table
    // ndu[j][r] = basis function N_{span-degree+r,j}
    std::vector<std::vector<double>> ndu(order, std::vector<double>(order, 0.0));
    ndu[0][0] = 1.0;

    std::vector<double> left(degree + 1);
    std::vector<double> right(degree + 1);

    // Compute basis functions (0-th derivatives)
    for (int j = 1; j <= degree; j++) {
        left[j] = t - nurbsknot[nurbsknot_base - j];
        right[j] = nurbsknot[nurbsknot_base + j - 1] - t;
        double saved = 0.0;

        for (int r = 0; r < j; r++) {
            // Lower triangle (nurbsknot differences)
            ndu[j][r] = right[r + 1] + left[j - r];
            double temp = ndu[r][j - 1] / ndu[j][r];

            // Upper triangle (basis values)
            ndu[r][j] = saved + right[r + 1] * temp;
            saved = left[j - r] * temp;
        }
        ndu[j][j] = saved;
    }

    // Copy 0-th derivatives (basis functions)
    for (int j = 0; j <= degree; j++) {
        ders[0][j] = ndu[j][degree];
    }

    // Compute derivatives using two-row array approach
    std::vector<std::vector<double>> a(2, std::vector<double>(order, 0.0));

    // Loop over basis functions
    for (int r = 0; r <= degree; r++) {
        int s1 = 0;
        int s2 = 1;
        a[0][0] = 1.0;

        // Loop over derivatives
        for (int k = 1; k <= deriv_order; k++) {
            double d = 0.0;
            int rk = r - k;
            int pk = degree - k;

            if (r >= k) {
                a[s2][0] = a[s1][0] / ndu[pk + 1][rk];
                d = a[s2][0] * ndu[rk][pk];
            }

            int j1 = (rk >= -1) ? 1 : -rk;
            int j2 = (r - 1 <= pk) ? k - 1 : degree - r;

            for (int j = j1; j <= j2; j++) {
                a[s2][j] = (a[s1][j] - a[s1][j - 1]) / ndu[pk + 1][rk + j];
                d += a[s2][j] * ndu[rk + j][pk];
            }

            if (r <= pk) {
                a[s2][k] = -a[s1][k - 1] / ndu[pk + 1][r];
                d += a[s2][k] * ndu[r][pk];
            }

            ders[k][r] = d;

            // Swap rows
            std::swap(s1, s2);
        }
    }

    // Multiply by factorial of derivative order / nurbsknot differences
    int factorial = degree;
    for (int k = 1; k <= deriv_order; k++) {
        for (int j = 0; j <= degree; j++) {
            ders[k][j] *= factorial;
        }
        factorial *= (degree - k);
    }
}

// Factory methods (create_ruled, create_extrusion, create_planar, create_loft, create_revolve,
// create_sweep1, create_sweep2, create_edge) moved to Primitives class in primitives.cpp

} // namespace session_cpp
