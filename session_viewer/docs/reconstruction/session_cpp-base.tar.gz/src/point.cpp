#include "point.h"
#include "tolerance.h"

#include "point.pb.h"
#include "color.pb.h"

namespace session_cpp {

/// Copy constructor (creates a new guid() while copying data)
Point::Point(const Point &other)
    :
      name(other.name),
      width(other.width),
      pointcolor(other.pointcolor),
      _x(other._x),
      _y(other._y),
      _z(other._z) {}

/// Copy assignment (creates a new guid() while copying data)
Point &Point::operator=(const Point &other) {
  if (this != &other) {
    _guid.clear();
    name = other.name;
    width = other.width;
    pointcolor = other.pointcolor;
    _x = other._x;
    _y = other._y;
    _z = other._z;
  }
  return *this;
}

// ═══════════════════════════════════════════════════════════════════════════
// Transformation
// ═══════════════════════════════════════════════════════════════════════════

void Point::transform(const Xform& xform) {
  double x = _x, y = _y, z = _z;
  double w = xform.m[3]*x + xform.m[7]*y + xform.m[11]*z + xform.m[15];
  double w_inv = (std::abs(w) > 1e-10) ? 1.0 / w : 1.0;
  _x = (xform.m[0]*x + xform.m[4]*y + xform.m[8]*z + xform.m[12]) * w_inv;
  _y = (xform.m[1]*x + xform.m[5]*y + xform.m[9]*z + xform.m[13]) * w_inv;
  _z = (xform.m[2]*x + xform.m[6]*y + xform.m[10]*z + xform.m[14]) * w_inv;
}

Point Point::transformed(const Xform& xform) const {
  Point result = *this;
  result.transform(xform);
  return result;
}

// ═══════════════════════════════════════════════════════════════════════════
// JSON
// ═══════════════════════════════════════════════════════════════════════════

/// Convert to JSON-serializable object (alphabetical order to match Rust)
nlohmann::ordered_json Point::jsondump() const {
  nlohmann::ordered_json data;
  data["guid"] = guid();
  data["name"] = name;
  data["pointcolor"] = pointcolor.jsondump();
  data["type"] = "Point";
  data["width"] = width;
  data["x"] = _x;
  data["y"] = _y;
  data["z"] = _z;
  return data;
}

/// Create point from JSON data
Point Point::jsonload(const nlohmann::json &data) {
  Point point(data["x"], data["y"], data["z"]);
  point.guid() = data["guid"];
  point.name = data["name"];
  point.pointcolor = Color::jsonload(data["pointcolor"]);
  point.width = data["width"];
  return point;
}

std::string Point::file_json_dumps() const {
    return jsondump().dump();
}

Point Point::file_json_loads(const std::string& json_string) {
    return jsonload(nlohmann::ordered_json::parse(json_string));
}

/// Write JSON to file
void Point::file_json_dump(const std::string& filename) const {
  std::ofstream file(filename);
  file << jsondump().dump(4);
}

/// Read JSON from file
Point Point::file_json_load(const std::string& filename) {
  std::ifstream file(filename);
  nlohmann::json data = nlohmann::json::parse(file);
  return jsonload(data);
}

// ═══════════════════════════════════════════════════════════════════════════
// Protobuf
// ═══════════════════════════════════════════════════════════════════════════

std::string Point::pb_dumps() const {
  session_proto::Point proto;
  if (has_guid()) { proto.set_guid(guid()); }
  proto.set_name(name);
  proto.set_x(_x);
  proto.set_y(_y);
  proto.set_z(_z);
  proto.set_width(width);
  
  // Set color (no guid() in proto schema)
  auto* color_proto = proto.mutable_pointcolor();
  color_proto->set_name(pointcolor.name);
  color_proto->set_r(pointcolor.r);
  color_proto->set_g(pointcolor.g);
  color_proto->set_b(pointcolor.b);
  color_proto->set_a(pointcolor.a);
  
  return proto.SerializeAsString();
}

Point Point::pb_loads(const std::string& data) {
  session_proto::Point proto;
  proto.ParseFromString(data);
  
  Point point(proto.x(), proto.y(), proto.z());
  if (!proto.guid().empty()) { point.guid() = proto.guid(); }
  point.name = proto.name();
  point.width = proto.width();
  
  // Load color (no guid() in proto schema)
  const auto& color_proto = proto.pointcolor();
  point.pointcolor.name = color_proto.name();
  point.pointcolor.r = color_proto.r();
  point.pointcolor.g = color_proto.g();
  point.pointcolor.b = color_proto.b();
  point.pointcolor.a = color_proto.a();
  
  return point;
}

void Point::pb_dump(const std::string& filename) const {
  std::string data = pb_dumps();
  std::ofstream file(filename, std::ios::binary);
  file.write(data.data(), data.size());
}

Point Point::pb_load(const std::string& filename) {
  std::ifstream file(filename, std::ios::binary);
  std::string data((std::istreambuf_iterator<char>(file)),
                    std::istreambuf_iterator<char>());
  return pb_loads(data);
}

/// Simple string form (like Python __str__): just coordinates
std::string Point::str() const {
  int prec = static_cast<int>(Tolerance::ROUNDING);
  return fmt::format(
      "{}, {}, {}",
      TOLERANCE.format_number(_x, prec),
      TOLERANCE.format_number(_y, prec),
      TOLERANCE.format_number(_z, prec));
}

/// Detailed representation (like Python __repr__)
std::string Point::repr() const {
  int prec = static_cast<int>(Tolerance::ROUNDING);
  return fmt::format(
      "Point({}, {}, {}, {}, Color({}, {}, {}, {}), {})",
      name,
      TOLERANCE.format_number(_x, prec),
      TOLERANCE.format_number(_y, prec),
      TOLERANCE.format_number(_z, prec),
      pointcolor.r, pointcolor.g, pointcolor.b, pointcolor.a,
      TOLERANCE.format_number(width, prec));
}

/// Equality operator
bool Point::operator==(const Point &other) const {
  return _x == other._x && _y == other._y && _z == other._z;
}

/// Inequality operator
bool Point::operator!=(const Point &other) const { return !(*this == other); }

// ═══════════════════════════════════════════════════════════════════════════
// No-copy Operators
// ═══════════════════════════════════════════════════════════════════════════

double& Point::operator[](int index) {
  if (index == 0) {
    return _x;
  } else if (index == 1) {
    return _y;
  } else if (index == 2) {
    return _z;
  } else {
    throw std::out_of_range("Index out of range");
  }
}

const double &Point::operator[](int index) const{
  if (index == 0) {
    return _x;
  } else if (index == 1) {
    return _y;
  } else if (index == 2) {
    return _z;
  } else {
    throw std::out_of_range("Index out of range");
  }
}

Point &Point::operator*=(double factor) {
  _x *= factor;
  _y *= factor;
  _z *= factor;
  return *this;
}

Point &Point::operator/=(double factor) {
  _x /= factor;
  _y /= factor;
  _z /= factor;
  return *this;
}

Point& Point::operator+=(const Vector& other) {
  _x += other[0];
  _y += other[1];
  _z += other[2];
  return *this;
}

Point& Point::operator-=(const Vector& other) {
  _x -= other[0];
  _y -= other[1];
  _z -= other[2];
  return *this;
}

// ═══════════════════════════════════════════════════════════════════════════
// Copy Operators
// ═══════════════════════════════════════════════════════════════════════════

Point Point::operator*(double factor) const {
  Point result = *this;
  result *= factor;
  return result;
}

Point Point::operator/(double factor) const {
  Point result = *this;
  result /= factor;
  return result;
}

Point Point::operator+(const Vector& other) const {
  Point result(_x + other[0], _y + other[1], _z + other[2]);
  return result;
}

Point Point::operator-(const Vector& other) const {
  Point result(_x - other[0], _y - other[1], _z - other[2]);
  return result;
}

Vector Point::operator-(const Point& other) const {
  Vector result(_x - other._x, _y - other._y, _z - other._z);
  return result;
}

Point Point::sum(const Point& p0, const Point& p1) {
  return Point(p0._x + p1._x, p0._y + p1._y, p0._z + p1._z);
}

Point Point::sub(const Point& p0, const Point& p1) {
  return Point(p0._x - p1._x, p0._y - p1._y, p0._z - p1._z);
}

// ═══════════════════════════════════════════════════════════════════════════
// Details
// ═══════════════════════════════════════════════════════════════════════════

bool Point::ccw(const Point& a, const Point& b, const Point& c) {
    return (c._y - a._y) * (b._x - a._x) > (b._y - a._y) * (c._x - a._x);
}

bool Point::is_ccw(const Point& a, const Point& b, const Point& c) {
    return ccw(a, b, c);
}

Point Point::mid_point(const Point& p) const {
    return Point((_x + p._x) / 2, (_y + p._y) / 2, (_z + p._z) / 2);
}

Point Point::mid_point(const Point& a, const Point& b) {
    return a.mid_point(b);
}

double Point::distance(const Point& p, double float_min) const {
    double dx = std::abs((*this)[0] - p[0]);
    double dy = std::abs((*this)[1] - p[1]);
    double dz = std::abs((*this)[2] - p[2]);
    double length = 0.0;

    // Reorder coordinates to put largest in dx
    if (dy >= dx && dy >= dz) {
        std::swap(dx, dy);
    } else if (dz >= dx && dz >= dy) {
        std::swap(dx, dz);
    }

    if (dx > float_min) {
        dy /= dx;
        dz /= dx;
        length = dx * std::sqrt(1.0 + dy * dy + dz * dz);
    } else if (dx > 0.0 && std::isfinite(dx)) {
        length = dx;
    } else {
        length = 0.0;
    }

    return length;
}

double Point::squared_distance(const Point& p, double float_min) const {
    double dx = std::abs((*this)[0] - p[0]);
    double dy = std::abs((*this)[1] - p[1]);
    double dz = std::abs((*this)[2] - p[2]);
    double length2 = 0.0;

    if (dy >= dx && dy >= dz) {
        std::swap(dx, dy);
    } else if (dz >= dx && dz >= dy) {
        std::swap(dx, dz);
    }

    if (dx > float_min) {
        dy /= dx;
        dz /= dx;
        length2 = dx * dx * (1.0 + dy * dy + dz * dz);
    } else if (dx > 0.0 && std::isfinite(dx)) {
        length2 = dx * dx;
    } else {
        length2 = 0.0;
    }

    return length2;
}

double Point::distance(const Point& a, const Point& b, double float_min) {
    return a.distance(b, float_min);
}

double Point::squared_distance(const Point& a, const Point& b, double float_min) {
    return a.squared_distance(b, float_min);
}

Point Point::lerp(const Point& a, const Point& b, double t) {
    return Point(a[0] + t * (b[0] - a[0]),
                 a[1] + t * (b[1] - a[1]),
                 a[2] + t * (b[2] - a[2]));
}

std::vector<Point> Point::interpolate(const Point& from, const Point& to, int steps, int kind) {
    std::vector<Point> pts;
    if (kind == 1 || kind == 2)
        pts.push_back(from);
    for (int i = 1; i <= steps; ++i) {
        double t = static_cast<double>(i) / static_cast<double>(steps + 1);
        pts.emplace_back(
            from[0] + t * (to[0] - from[0]),
            from[1] + t * (to[1] - from[1]),
            from[2] + t * (to[2] - from[2]));
    }
    if (kind == 1)
        pts.push_back(to);
    return pts;
}

double Point::area(const std::vector<Point>& points) {
    size_t n = points.size();
    double area = 0.0;
    
    for (size_t i = 0; i < n; ++i) {
        size_t j = (i + 1) % n;
        area += points[i][0] * points[j][1];
        area -= points[j][0] * points[i][1];
    }
    return std::abs(area) / 2.0;
}

Point Point::centroid_quad(const std::vector<Point>& vertices) {
    if (vertices.size() != 4) {
        throw std::invalid_argument("Polygon must have exactly 4 vertices.");
    }
    
    double total_area = 0.0;
    Vector centroid_sum(0, 0, 0);
    
    for (int i = 0; i < 4; ++i) {
        const Point& p0 = vertices[i];
        const Point& p1 = vertices[(i + 1) % 4];
        const Point& p2 = vertices[(i + 2) % 4];
        
        double tri_area = std::abs(p0[0] * (p1[1] - p2[1]) + 
                                  p1[0] * (p2[1] - p0[1]) + 
                                  p2[0] * (p0[1] - p1[1])) / 2.0;
        total_area += tri_area;
        
        Vector tri_centroid((p0[0] + p1[0] + p2[0]) / 3.0,
                          (p0[1] + p1[1] + p2[1]) / 3.0,
                          (p0[2] + p1[2] + p2[2]) / 3.0);
        centroid_sum += tri_centroid * tri_area;
    }
    
    Vector result = centroid_sum / total_area;
    return Point(result[0], result[1], result[2]);
}

Point Point::centroid(const std::vector<Point>& points) {
    if (points.empty()) return Point(0, 0, 0);
    double cx = 0.0, cy = 0.0, cz = 0.0;
    for (const Point& p : points) { cx += p[0]; cy += p[1]; cz += p[2]; }
    double n = static_cast<double>(points.size());
    return Point(cx / n, cy / n, cz / n);
}

double Point::dihedral_angle_deg(const Point& p, const Point& q,
                                  const Point& r, const Point& s) {
    // Build half-plane normals via shared edge pq.
    Vector pq(q[0]-p[0], q[1]-p[1], q[2]-p[2]);
    Vector pr(r[0]-p[0], r[1]-p[1], r[2]-p[2]);
    Vector ps(s[0]-p[0], s[1]-p[1], s[2]-p[2]);
    Vector n1 = pq.cross(pr);
    Vector n2 = pq.cross(ps);
    double m1 = n1.magnitude();
    double m2 = n2.magnitude();
    if (m1 < Tolerance::ZERO_TOLERANCE || m2 < Tolerance::ZERO_TOLERANCE) {
        return 0.0;
    }
    double cos_t = n1.dot(n2) / (m1 * m2);
    if (cos_t > 1.0) cos_t = 1.0;
    if (cos_t < -1.0) cos_t = -1.0;
    return std::acos(cos_t) * (180.0 / 3.141592653589793);
}

// ═══════════════════════════════════════════════════════════════════════════
// Not class methods
// ═══════════════════════════════════════════════════════════════════════════

std::ostream &operator<<(std::ostream &os, const Point &point) {
  // Delegate to to_str() for human-readable output
  return os << point.str();
}
} // namespace session_cpp